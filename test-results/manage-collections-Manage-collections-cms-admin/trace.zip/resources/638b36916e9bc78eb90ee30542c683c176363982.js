(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-INBEEENE.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>F
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lexical@0.35.0/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
;
var F = (t, i)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(24), [s] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), [c, B] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [n, D] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), { closeModal: u, modalState: l, toggleModal: O } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useModal"])(), r;
    e[0] !== s ? (r = ()=>{
        s.read(()=>{
            let M = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])() ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getPreviousSelection"])();
            B(M);
        });
    }, e[0] = s, e[1] = r) : r = e[1];
    let w = r, a;
    e[2] !== s || e[3] !== c ? (a = ()=>{
        c && s.update(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$setSelection"])(c.clone());
        }, {
            discrete: !0,
            skipTransforms: !0
        });
    }, e[2] = s, e[3] = c, e[4] = a) : a = e[4];
    let o = a, f;
    e[5] !== u || e[6] !== t ? (f = ()=>{
        u(t);
    }, e[5] = u, e[6] = t, e[7] = f) : f = e[7];
    let x = f, $ = l?.[t]?.isOpen, m;
    e[8] !== $ || e[9] !== o || e[10] !== t || e[11] !== w || e[12] !== O ? (m = ()=>{
        $ ? o() : w(), D(!0), O(t);
    }, e[8] = $, e[9] = o, e[10] = t, e[11] = w, e[12] = O, e[13] = m) : m = e[13];
    let C = m, p, d;
    e[14] !== l || e[15] !== i || e[16] !== o || e[17] !== t || e[18] !== n ? (p = ()=>{
        if (!n) return;
        let M = l[t];
        M && !M?.isOpen && (D(!1), i ? setTimeout(()=>{
            o();
        }, 0) : o());
    }, d = [
        l,
        t,
        o,
        n,
        i
    ], e[14] = l, e[15] = i, e[16] = o, e[17] = t, e[18] = n, e[19] = p, e[20] = d) : (p = e[19], d = e[20]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(p, d);
    let S;
    return e[21] !== x || e[22] !== C ? (S = {
        closeDrawer: x,
        toggleDrawer: C
    }, e[21] = x, e[22] = C, e[23] = S) : S = e[23], S;
};
;
 //# sourceMappingURL=chunk-INBEEENE.js.map
}),
"[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-BZZVLW4U.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>H,
    "b",
    ()=>I
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
;
function B() {
    return Math.random().toString(36).substring(2, 12) + Math.random().toString(36).substring(2, 12);
}
var w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    editorConfig: null,
    fieldProps: null,
    uuid: null
}), H = ({ children: o, editorConfig: c, editorContainerRef: d, fieldProps: a, parentContext: n })=>{
    let [f] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), [l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(()=>B()), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map), [m, C] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Set), [E, p] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(), h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEditDepth"])(), M = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            blurEditor: (t)=>{
                u.current.clear();
            },
            childrenEditors: r,
            createdInlineBlock: E,
            editDepth: h,
            editor: f,
            editorConfig: c,
            editorContainerRef: d,
            fieldProps: a,
            focusedEditor: m,
            focusEditor: (t)=>{
                let e = t.uuid;
                u.current.has(e) || (u.current.add(e), C(t), n?.uuid && n.focusEditor(t), r.current.forEach((i)=>{
                    i.focusEditor(t);
                }), u.current.clear());
            },
            parentEditor: n,
            registerChild: (t, e)=>{
                if (!r.current.has(t)) {
                    let i = new Map(r.current);
                    i.set(t, e), r.current = i;
                }
            },
            setCreatedInlineBlock: p,
            unregisterChild: (t)=>{
                if (r.current.has(t)) {
                    let e = new Map(r.current);
                    e.delete(t), r.current = e;
                }
            },
            uuid: l
        }), [
        E,
        p,
        f,
        r,
        c,
        d,
        h,
        a,
        m,
        n,
        l
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(w, {
        value: M,
        children: o
    });
}, I = ()=>{
    let o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["use"])(w);
    if (o === void 0) throw new Error("useEditorConfigContext must be used within an EditorConfigProvider");
    return o;
};
;
 //# sourceMappingURL=chunk-BZZVLW4U.js.map
}),
"[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-TRHFMZ3F.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>gt,
    "b",
    ()=>_t,
    "c",
    ()=>I,
    "d",
    ()=>Ne,
    "e",
    ()=>M
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$INBEEENE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-INBEEENE.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-BZZVLW4U.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/useLexicalEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+translations@3.70.0/node_modules/@payloadcms/translations/dist/utilities/getTranslation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__f__as__ShimmerEffect$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/chunk-53XJ3K67.js [app-client] (ecmascript) <export f as ShimmerEffect>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c__as__useConfig$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/chunk-53XJ3K67.js [app-client] (ecmascript) <export c as useConfig>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/chunk-7V3NHDV6.js [app-client] (ecmascript) <export d as useTranslation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/shared/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lexical@0.35.0/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/payload@3.70.0_graphql@16.12.0_typescript@5.7.3/node_modules/payload/dist/utilities/deepCopyObject.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$reduceFieldsToValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/payload@3.70.0_graphql@16.12.0_typescript@5.7.3/node_modules/payload/dist/utilities/reduceFieldsToValues.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/uuid@10.0.0/node_modules/uuid/dist/esm-browser/v4.js [app-client] (ecmascript) <export default as v4>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/bson-objectid@2.0.4/node_modules/bson-objectid/objectid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+utils@0.35.0/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var _ = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __cacheBuster;
    __fields;
    constructor({ cacheBuster: e, fields: n, key: t }){
        super(t), this.__fields = n, this.__cacheBuster = e || 0;
    }
    static clone(e) {
        return new this({
            cacheBuster: e.__cacheBuster,
            fields: e.__fields,
            key: e.__key
        });
    }
    static getType() {
        return "inlineBlock";
    }
    static importDOM() {
        return {};
    }
    static importJSON(e) {
        return Se(e.fields);
    }
    static isInline() {
        return !1;
    }
    canIndent() {
        return !0;
    }
    createDOM(e) {
        let n = document.createElement("span");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addClassNamesToElement"])(n, e?.theme?.inlineBlock), n;
    }
    decorate(e, n) {
        return null;
    }
    exportDOM() {
        let e = document.createElement("span");
        e.classList.add("inline-block-container");
        let n = document.createTextNode(this.getTextContent());
        return e.append(n), {
            element: e
        };
    }
    exportJSON() {
        return {
            type: "inlineBlock",
            fields: this.getFields(),
            version: 1
        };
    }
    getCacheBuster() {
        return this.getLatest().__cacheBuster;
    }
    getFields() {
        return this.getLatest().__fields;
    }
    getTextContent() {
        return "Block Field";
    }
    isInline() {
        return !0;
    }
    setFields(e, n) {
        let t = this.getWritable();
        t.__fields = e, n || t.__cacheBuster++;
    }
    updateDOM() {
        return !1;
    }
};
function Se(i) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new _({
        fields: {
            ...i,
            id: i?.id || new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString()
        }
    }));
}
var Ie = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].lazy(()=>__turbopack_context__.A("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/componentInline-5OVPQNQH.js [app-client] (ecmascript, async loader)").then((i)=>({
            default: i.InlineBlockComponent
        }))), I = class extends _ {
    static clone(e) {
        return super.clone(e);
    }
    static getType() {
        return super.getType();
    }
    static importJSON(e) {
        return Ne(e.fields);
    }
    decorate(e, n) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ie, {
            cacheBuster: this.getCacheBuster(),
            className: n.theme.inlineBlock ?? "LexicalEditorTheme__inlineBlock",
            formData: this.getFields(),
            nodeKey: this.getKey()
        });
    }
    exportJSON() {
        return super.exportJSON();
    }
};
function Ne(i) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new I({
        fields: {
            ...i,
            id: i?.id || new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString()
        }
    }));
}
function M(i) {
    return i instanceof I;
}
var ue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    initialState: !1
}), gt = ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].use(ue), _t = (i)=>{
    let { cacheBuster: e, className: n, formData: t, nodeKey: d } = i, [f] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), { i18n: $, t: p } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__["useTranslation"])(), { createdInlineBlock: V, fieldProps: { featureClientSchemaMap: me, initialLexicalFormState: de, schemaPath: H }, setCreatedInlineBlock: W, uuid: pe } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), { fields: C } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDocumentForm"])(), { getFormState: S } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useServerFunctions"])(), fe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEditDepth"])(), q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1), [a, T] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        "_t.useState": ()=>{
            let o = de?.[t.id]?.formState;
            return o ? Object.fromEntries(Object.entries(o).map({
                "_t.useState": ([l, r])=>[
                        l,
                        l in t ? {
                            ...r,
                            initialValue: t[l],
                            value: t[l]
                        } : r
                    ]
            }["_t.useState"])) : !1;
        }
    }["_t.useState"]), G = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1), Q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(e);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        G.current ? (Q.current !== e && T(!1), Q.current = e) : G.current = !0;
    }, [
        e
    ]);
    let [E, U] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(a?._components?.customComponents?.BlockLabel), [X, Y] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(a?._components?.customComponents?.Block), Z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["formatDrawerSlug"])({
        slug: `lexical-inlineBlocks-create-${pe}-${t.id}`,
        depth: fe
    }), { toggleDrawer: h } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$INBEEENE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(Z, !0), be = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), { id: y, collectionSlug: F, getDocPreferences: D, globalSlug: w } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDocumentInfo"])(), { config: he } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c__as__useConfig$3e$__["useConfig"])(), ke = `${H}.lexical_internal_feature.blocks.lexical_inline_blocks.${t.blockType}`, k = me.blocks?.[ke]?.[0], u = k.blockReferences ? typeof k?.blockReferences?.[0] == "string" ? he.blocksMap[k?.blockReferences?.[0]] : k?.blockReferences?.[0] : k?.blocks?.[0], ee = u?.fields ?? [];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        !q.current && V?.getKey() === d && (ee.length > 2 && h(), W?.(void 0), q.current = !0);
    }, [
        ee.length,
        V,
        d,
        W,
        h
    ]);
    let te = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        f.update(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(d)?.remove();
        });
    }, [
        f,
        d
    ]), B = u?.labels?.singular ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslation"])(u?.labels.singular, $) : u?.slug, R = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new AbortController), g = `${H}.lexical_internal_feature.blocks.lexical_inline_blocks.${u?.slug}.fields`;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let o = new AbortController;
        return t && !a && (async ()=>{
            let { state: r } = await S({
                id: y,
                collectionSlug: F,
                data: t,
                docPermissions: {
                    fields: !0
                },
                docPreferences: await D(),
                documentFormState: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepCopyObjectSimpleWithoutReactComponents"])(C),
                globalSlug: w,
                initialBlockData: t,
                initialBlockFormState: t,
                operation: "update",
                readOnly: !c,
                renderAllFields: !0,
                schemaPath: g,
                signal: o.signal
            });
            if (r) {
                let m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$reduceFieldsToValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduceFieldsToValues"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepCopyObjectSimpleWithoutReactComponents"])(r), !0);
                f.update(()=>{
                    let j = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(d);
                    if (j && M(j)) {
                        let le = m;
                        le.blockType = t.blockType, j.setFields(le, !0);
                    }
                }), T(r), U(r._components?.customComponents?.BlockLabel), Y(r._components?.customComponents?.Block);
            }
        })(), ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["abortAndIgnore"])(o);
        };
    }, [
        S,
        f,
        d,
        c,
        g,
        y,
        t,
        a,
        F,
        w,
        D,
        C
    ]);
    let ne = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(async ({ formState: o, submit: l })=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["abortAndIgnore"])(R.current);
        let r = new AbortController;
        R.current = r;
        let { state: m } = await S({
            id: y,
            collectionSlug: F,
            docPermissions: {
                fields: !0
            },
            docPreferences: await D(),
            documentFormState: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepCopyObjectSimpleWithoutReactComponents"])(C),
            formState: o,
            globalSlug: w,
            initialBlockFormState: o,
            operation: "update",
            readOnly: !c,
            renderAllFields: !!l,
            schemaPath: g,
            signal: r.signal
        });
        return m ? (l && (U(m._components?.customComponents?.BlockLabel), Y(m._components?.customComponents?.Block)), m) : o;
    }, [
        S,
        y,
        F,
        D,
        C,
        w,
        c,
        g
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let o = (l, r)=>Object.keys(r).some((m)=>r[m] && l[m] !== r[m].value);
        return ()=>{
            a && o(t, a) && T(!1), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["abortAndIgnore"])(R.current);
        };
    }, [
        t,
        a
    ]);
    let Be = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((o, l)=>{
        l.blockType = t.blockType, f.update(()=>{
            let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(d);
            r && M(r) && r.setFields(l, !0);
        });
    }, [
        f,
        d,
        t
    ]), P = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Button"], {
                buttonStyle: "icon-label",
                className: `${n}__removeButton`,
                disabled: !c,
                icon: "x",
                onClick: (o)=>{
                    o.preventDefault(), te();
                },
                round: !0,
                size: "small",
                tooltip: p("lexical:blocks:inlineBlocks:remove", {
                    label: B
                })
            }), [
        n,
        B,
        c,
        te,
        p
    ]), oe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Button"], {
                buttonStyle: "icon-label",
                className: `${n}__editButton`,
                disabled: !c,
                el: "button",
                icon: "edit",
                onClick: ()=>{
                    h();
                },
                round: !0,
                size: "small",
                tooltip: p("lexical:blocks:inlineBlocks:edit", {
                    label: B
                })
            }), [
        n,
        B,
        c,
        p,
        h
    ]), L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({ children: o, className: l })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: [
                    `${n}__container`,
                    n + "-" + t.blockType,
                    l
                ].filter(Boolean).join(" "),
                ref: be,
                children: o
            }), [
        n,
        t.blockType
    ]), re = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>E ? ()=>E : ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                children: u?.labels ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslation"])(u?.labels.singular, $) : ""
            }), [
        E,
        u?.labels,
        $
    ]);
    return u ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Form"], {
        beforeSubmit: [
            async ({ formState: o })=>await ne({
                    formState: o,
                    submit: !0
                })
        ],
        disableValidationOnSubmit: !0,
        el: "div",
        fields: u?.fields,
        initialState: a || {},
        onChange: [
            ne
        ],
        onSubmit: (o, l)=>{
            Be(o, l), h();
        },
        uuid: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])(),
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["EditDepthProvider"], {
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Drawer"], {
                    className: "",
                    slug: Z,
                    title: p(`lexical:blocks:inlineBlocks:${t?.id ? "edit" : "create"}`, {
                        label: B ?? p("lexical:blocks:inlineBlocks:label")
                    }),
                    children: a ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RenderFields"], {
                                fields: u?.fields,
                                forceRender: !0,
                                parentIndexPath: "",
                                parentPath: "",
                                parentSchemaPath: g,
                                permissions: !0,
                                readOnly: !c
                            }),
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FormSubmit"], {
                                programmaticSubmit: !0,
                                children: p("fields:saveChanges")
                            })
                        ]
                    }) : null
                })
            }),
            X ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ue, {
                value: {
                    EditButton: oe,
                    initialState: a,
                    InlineBlockContainer: L,
                    Label: re,
                    nodeKey: d,
                    RemoveButton: P
                },
                children: X
            }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(L, {
                children: [
                    a ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(re, {}) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__f__as__ShimmerEffect$3e$__["ShimmerEffect"], {
                        height: "15px",
                        width: "40px"
                    }),
                    c ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                        className: `${n}__actions`,
                        children: [
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(oe, {}),
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(P, {})
                        ]
                    }) : null
                ]
            })
        ]
    }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(L, {
        className: `${n}-not-found`,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", {
                children: [
                    "Error: Block '",
                    t.blockType,
                    "' not found"
                ]
            }),
            c ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: `${n}__actions`,
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(P, {})
            }) : null
        ]
    });
};
;
 //# sourceMappingURL=chunk-TRHFMZ3F.js.map
}),
"[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-DBWINSQN.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>_
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lexical@0.35.0/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
;
var _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("INSERT_RELATIONSHIP_WITH_DRAWER_COMMAND");
;
 //# sourceMappingURL=chunk-DBWINSQN.js.map
}),
"[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-O6XRT2H3.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>de,
    "b",
    ()=>he
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-BZZVLW4U.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/useLexicalEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/chunk-7V3NHDV6.js [app-client] (ecmascript) <export d as useTranslation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/shared/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/payload@3.70.0_graphql@16.12.0_typescript@5.7.3/node_modules/payload/dist/utilities/deepCopyObject.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/uuid@10.0.0/node_modules/uuid/dist/esm-browser/v4.js [app-client] (ecmascript) <export default as v4>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lexical@0.35.0/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
var E = ({ data: f, featureKey: e, fieldMapOverride: p, handleDrawerSubmit: h, schemaFieldsPathOverride: o, schemaPath: g, schemaPathSuffix: m })=>{
    let { t: S } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__["useTranslation"])(), { id: a, collectionSlug: n, getDocPreferences: i, globalSlug: s } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDocumentInfo"])(), { fields: l } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDocumentForm"])(), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new AbortController), [c, w] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), { fieldProps: { featureClientSchemaMap: P } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), { getFormState: C } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useServerFunctions"])(), u = o ?? `${g}.lexical_internal_feature.${e}${m ? `.${m}` : ""}`, b = p ?? P[e]?.[u];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let d = new AbortController;
        return (async ()=>{
            let { state: D } = await C({
                id: a,
                collectionSlug: n,
                data: f ?? {},
                docPermissions: {
                    fields: !0
                },
                docPreferences: await i(),
                documentFormState: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepCopyObjectSimpleWithoutReactComponents"])(l),
                globalSlug: s,
                initialBlockData: f,
                operation: "update",
                readOnly: !r,
                renderAllFields: !0,
                schemaPath: u,
                signal: d.signal
            });
            w(D);
        })(), ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["abortAndIgnore"])(d);
        };
    }, [
        u,
        a,
        f,
        C,
        n,
        r,
        s,
        i,
        l
    ]);
    let R = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(async ({ formState: d })=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["abortAndIgnore"])(t.current);
        let A = new AbortController;
        t.current = A;
        let { state: D } = await C({
            id: a,
            collectionSlug: n,
            docPermissions: {
                fields: !0
            },
            docPreferences: await i(),
            documentFormState: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepCopyObjectSimpleWithoutReactComponents"])(l),
            formState: d,
            globalSlug: s,
            initialBlockFormState: d,
            operation: "update",
            readOnly: !r,
            schemaPath: u,
            signal: A.signal
        });
        return D || d;
    }, [
        C,
        a,
        r,
        n,
        i,
        l,
        s,
        u
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["abortAndIgnore"])(t.current);
        }, []), c === !1 ? null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Form"], {
        beforeSubmit: [
            R
        ],
        disableValidationOnSubmit: !0,
        fields: Array.isArray(b) ? b : [],
        initialState: c,
        onChange: [
            R
        ],
        onSubmit: h,
        uuid: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])(),
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RenderFields"], {
                fields: Array.isArray(b) ? b : [],
                forceRender: !0,
                parentIndexPath: "",
                parentPath: "",
                parentSchemaPath: u,
                permissions: !0,
                readOnly: !r
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FormSubmit"], {
                children: S("fields:saveChanges")
            })
        ]
    });
};
var de = (f)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15), { className: p, data: h, drawerSlug: o, drawerTitle: g, featureKey: m, fieldMapOverride: S, handleDrawerSubmit: a, schemaFieldsPathOverride: n, schemaPath: i, schemaPathSuffix: s } = f, { closeModal: l } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useModal"])(), r = g ?? "", t;
    e[0] !== l || e[1] !== o || e[2] !== a ? (t = (w, P)=>{
        l(o), setTimeout(()=>{
            a(w, P);
        }, 1);
    }, e[0] = l, e[1] = o, e[2] = a, e[3] = t) : t = e[3];
    let c;
    return e[4] !== p || e[5] !== h || e[6] !== o || e[7] !== m || e[8] !== S || e[9] !== n || e[10] !== i || e[11] !== s || e[12] !== r || e[13] !== t ? (c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["EditDepthProvider"], {
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Drawer"], {
            className: p,
            slug: o,
            title: r,
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(E, {
                data: h,
                featureKey: m,
                fieldMapOverride: S,
                handleDrawerSubmit: t,
                schemaFieldsPathOverride: n,
                schemaPath: i,
                schemaPathSuffix: s
            })
        })
    }), e[4] = p, e[5] = h, e[6] = o, e[7] = m, e[8] = S, e[9] = n, e[10] = i, e[11] = s, e[12] = r, e[13] = t, e[14] = c) : c = e[14], c;
};
;
var he = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("INSERT_UPLOAD_WITH_DRAWER_COMMAND");
;
 //# sourceMappingURL=chunk-O6XRT2H3.js.map
}),
"[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-F26IQ5RE.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>G
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lexical@0.35.0/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
var G = ($)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21), [o] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), [l, k] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [c, C] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [S, w, O] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDocumentDrawer"])($), { closeDrawer: d, drawerSlug: t } = O, { modalState: n } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useModal"])(), i;
    e[0] !== o ? (i = ()=>{
        o.read(()=>{
            let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])() ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getPreviousSelection"])();
            k(r);
        }), C(!0);
    }, e[0] = o, e[1] = i) : i = e[1];
    let g = i, a;
    e[2] !== o || e[3] !== l ? (a = ()=>{
        l && o.update(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$setSelection"])(l.clone());
        }, {
            discrete: !0,
            skipTransforms: !0
        });
    }, e[2] = o, e[3] = l, e[4] = a) : a = e[4];
    let u = a, m;
    e[5] !== d ? (m = ()=>{
        d();
    }, e[5] = d, e[6] = m) : m = e[6];
    let x = m, f, D;
    e[7] !== t || e[8] !== n || e[9] !== u || e[10] !== c ? (f = ()=>{
        if (!c) return;
        let r = n[t];
        r && !r?.isOpen && (C(!1), setTimeout(()=>{
            u();
        }, 1));
    }, D = [
        n,
        t,
        u,
        c
    ], e[7] = t, e[8] = n, e[9] = u, e[10] = c, e[11] = f, e[12] = D) : (f = e[11], D = e[12]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(f, D);
    let s;
    e[13] !== w || e[14] !== g ? (s = (r)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(w, {
            ...r,
            onClick: g
        }), e[13] = w, e[14] = g, e[15] = s) : s = e[15];
    let p;
    return e[16] !== S || e[17] !== x || e[18] !== t || e[19] !== s ? (p = {
        closeDocumentDrawer: x,
        DocumentDrawer: S,
        documentDrawerSlug: t,
        DocumentDrawerToggler: s
    }, e[16] = S, e[17] = x, e[18] = t, e[19] = s, e[20] = p) : p = e[20], p;
};
;
 //# sourceMappingURL=chunk-F26IQ5RE.js.map
}),
"[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-AFXLIYGL.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "a",
    ()=>ur,
    "b",
    ()=>Tr,
    "c",
    ()=>Sr,
    "d",
    ()=>rt,
    "e",
    ()=>Wn,
    "f",
    ()=>z,
    "g",
    ()=>it,
    "h",
    ()=>lo,
    "i",
    ()=>Ge,
    "j",
    ()=>fo,
    "k",
    ()=>St,
    "l",
    ()=>po
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+utils@0.35.0/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lexical@0.35.0/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+list@0.35.0/node_modules/@lexical/list/LexicalList.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+rich-text@0.35.0/node_modules/@lexical/rich-text/LexicalRichText.dev.mjs [app-client] (ecmascript)");
var rt = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u";
;
;
function Wn(n) {
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), e = n === void 0 ? 500 : n, o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(void 0), r;
    return t[0] !== e ? (r = (s)=>new Promise((i)=>{
            let a = ()=>{
                s(), i();
            };
            "requestIdleCallback" in window ? ("cancelIdleCallback" in window && o.current !== void 0 && cancelIdleCallback(o.current), o.current = requestIdleCallback(a, {
                timeout: e
            })) : ge().then(a);
        }), t[0] = e, t[1] = r) : r = t[1], r;
}
function ge() {
    return new Promise((n)=>{
        setTimeout(n, 100), requestAnimationFrame(()=>{
            setTimeout(n, 0);
        });
    });
}
var z = class {
    _x;
    _y;
    constructor(t, e){
        this._x = t, this._y = e;
    }
    calcDeltaXTo({ x: t }) {
        return this.x - t;
    }
    calcDeltaYTo({ y: t }) {
        return this.y - t;
    }
    calcDistanceTo(t) {
        return Math.sqrt(Math.pow(this.calcDeltaXTo(t), 2) + Math.pow(this.calcDeltaYTo(t), 2));
    }
    calcHorizontalDistanceTo(t) {
        return Math.abs(this.calcDeltaXTo(t));
    }
    calcVerticalDistance(t) {
        return Math.abs(this.calcDeltaYTo(t));
    }
    equals({ x: t, y: e }) {
        return this.x === t && this.y === e;
    }
    get x() {
        return this._x;
    }
    get y() {
        return this._y;
    }
};
function it(n) {
    return n instanceof z;
}
;
;
;
;
;
;
;
;
;
;
;
var Ne = "slash-menu-popup", at = (n)=>{
    let t = document.getElementById("slash-menu");
    if (!t) return;
    let e = t.getBoundingClientRect();
    e.top + e.height > window.innerHeight && t.scrollIntoView({
        block: "center"
    }), e.top < 0 && t.scrollIntoView({
        block: "center"
    }), n.scrollIntoView({
        block: "nearest"
    });
};
function ye(n, t, e) {
    let o = e;
    for(let r = o; r <= t.length; r++)n.substring(n.length - r) === t.substring(0, r) && (o = r);
    return o;
}
function be(n) {
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) || !t.isCollapsed()) return;
    let e = t.anchor;
    if (e.type !== "text") return;
    let o = e.getNode();
    if (!o.isSimpleText()) return;
    let r = e.offset, c = o.getTextContent().slice(0, r), s = n.replaceableString.length, i = ye(c, n.matchingString, s), a = r - i;
    if (a < 0) return;
    let l;
    return a === 0 ? [l] = o.splitText(r) : [, l] = o.splitText(a, r), l;
}
function Ae(n, t) {
    let e = getComputedStyle(n), o = e.position === "absolute", r = t ? /(auto|scroll|hidden)/ : /(auto|scroll)/;
    if (e.position === "fixed") return document.body;
    for(let c = n; c = c.parentElement;)if (e = getComputedStyle(c), !(o && e.position === "static") && r.test(e.overflow + e.overflowY + e.overflowX)) return c;
    return document.body;
}
function lt(n, t) {
    let e = n.getBoundingClientRect(), o = t.getBoundingClientRect();
    return e.top > o.top && e.top < o.bottom;
}
function Oe(n, t, e, o) {
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7), [c] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), s, i;
    r[0] !== c || r[1] !== e || r[2] !== o || r[3] !== n || r[4] !== t ? (s = ()=>{
        let a = t.current;
        if (a != null && n != null) {
            let l = c.getRootElement(), u = l != null ? Ae(l, !1) : document.body, g = !1, m = lt(a, u), p = function() {
                g || (window.requestAnimationFrame(function() {
                    e(), g = !1;
                }), g = !0);
                let d = lt(a, u);
                d !== m && (m = d, o?.(d));
            }, f = new ResizeObserver(e);
            return window.addEventListener("resize", e), document.addEventListener("scroll", p, {
                capture: !0,
                passive: !0
            }), f.observe(a), ()=>{
                f.disconnect(), window.removeEventListener("resize", e), document.removeEventListener("scroll", p, !0);
            };
        }
    }, i = [
        c,
        o,
        e,
        n,
        t
    ], r[0] = c, r[1] = e, r[2] = o, r[3] = n, r[4] = t, r[5] = s, r[6] = i) : (s = r[5], i = r[6]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(s, i);
}
var ft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("SCROLL_TYPEAHEAD_OPTION_INTO_VIEW_COMMAND");
function gt({ anchorElementRef: n, close: t, editor: e, groups: o, menuRenderFn: r, resolution: c, shouldSplitNodeWithQuery: s = !1 }) {
    let [i, a] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), l = c.match && c.match.matchingString || "", u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((f)=>{
        let d = e.getRootElement();
        d !== null && (d.setAttribute("aria-activedescendant", `${Ne}__item-${f.key}`), a(f.key));
    }, [
        e
    ]), g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if (o !== null && l != null) {
            let f = o.flatMap((d)=>d.items);
            if (f.length) {
                let d = f[0];
                u(d);
            }
        }
    }, [
        o,
        u,
        l
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        g();
    }, [
        l,
        g
    ]);
    let m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((f)=>{
        t(), e.update(()=>{
            let d = c.match != null && s ? be(c.match) : null;
            d && d.remove();
        }), setTimeout(()=>{
            let d;
            e.read(()=>{
                d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])()?.clone();
            }), e.update(()=>{
                d && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$setSelection"])(d);
            }), f.onSelect({
                editor: e,
                queryString: c.match ? c.match.matchingString : ""
            });
        }, 0);
    }, [
        e,
        s,
        c.match,
        t
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>()=>{
            let f = e.getRootElement();
            f !== null && f.removeAttribute("aria-activedescendant");
        }, [
        e
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])(()=>{
        o === null ? a(null) : i === null && g();
    }, [
        o,
        i,
        u,
        g
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(e.registerCommand(ft, ({ item: f })=>f.ref && f.ref.current != null ? (at(f.ref.current), !0) : !1, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"])), [
        e,
        u
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ARROW_DOWN_COMMAND"], (f)=>{
            let d = f;
            if (o !== null && o.length && i !== null) {
                let h = o.flatMap((T)=>T.items), x = h.findIndex((T)=>T.key === i), E = x !== h.length - 1 ? x + 1 : 0, _ = h[E];
                if (!_) return !1;
                u(_), _.ref != null && _.ref.current && e.dispatchCommand(ft, {
                    index: E,
                    item: _
                }), d.preventDefault(), d.stopImmediatePropagation();
            }
            return !0;
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_NORMAL"]), e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ARROW_UP_COMMAND"], (f)=>{
            let d = f;
            if (o !== null && o.length && i !== null) {
                let h = o.flatMap((T)=>T.items), x = h.findIndex((T)=>T.key === i), E = x !== 0 ? x - 1 : h.length - 1, _ = h[E];
                if (!_) return !1;
                u(_), _.ref != null && _.ref.current && at(_.ref.current), d.preventDefault(), d.stopImmediatePropagation();
            }
            return !0;
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_NORMAL"]), e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ESCAPE_COMMAND"], (f)=>{
            let d = f;
            return d.preventDefault(), d.stopImmediatePropagation(), t(), !0;
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_TAB_COMMAND"], (f)=>{
            let d = f;
            if (o === null || i === null) return !1;
            let x = o.flatMap((E)=>E.items).find((E)=>E.key === i);
            return x ? (d.preventDefault(), d.stopImmediatePropagation(), m(x), !0) : !1;
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_NORMAL"]), e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ENTER_COMMAND"], (f)=>{
            if (o === null || i === null) return !1;
            let h = o.flatMap((x)=>x.items).find((x)=>x.key === i);
            return h ? (f !== null && (f.preventDefault(), f.stopImmediatePropagation()), m(h), !0) : !1;
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_NORMAL"])), [
        m,
        t,
        e,
        o,
        i,
        u
    ]);
    let p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            groups: o,
            selectedItemKey: i,
            selectItemAndCleanUp: m,
            setSelectedItemKey: a
        }), [
        m,
        i,
        o
    ]);
    return r(n, p, c.match ? c.match.matchingString : "");
}
function ke(n, t) {
    t != null && (n.className = t), n.setAttribute("aria-label", "Slash menu"), n.setAttribute("role", "listbox"), n.style.display = "block", n.style.position = "absolute";
}
function pt(n, t, e, o) {
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14), [c] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), s;
    r[0] === Symbol.for("react.memo_cache_sentinel") ? (s = rt ? document.createElement("div") : null, r[0] = s) : s = r[0];
    let i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(s), a;
    r[1] !== n || r[2] !== o || r[3] !== c || r[4] !== t ? (a = ()=>{
        if (i.current === null || parent === void 0) return;
        let f = c.getRootElement(), d = i.current, h = d.firstChild;
        if (f !== null && t !== null) {
            let { height: x, width: E } = t.getRect(), { left: _, top: T } = t.getRect(), I = T;
            if (T = T - (n.getBoundingClientRect().top + window.scrollY), _ = _ - (n.getBoundingClientRect().left + window.scrollX), d.style.left = `${_ + window.scrollX}px`, d.style.height = `${x}px`, d.style.width = `${E}px`, h !== null) {
                let S = h.getBoundingClientRect(), L = S.height, R = S.width, G = f.getBoundingClientRect(), nt = document.dir === "rtl" || document.documentElement.dir === "rtl", ae = n.getBoundingClientRect(), ot = Math.max(0, G.left);
                if (!nt && _ + R > G.right) d.style.left = `${G.right - R + window.scrollX}px`;
                else if (nt && S.left < ot) {
                    let ue = ot + R - ae.left;
                    d.style.left = `${ue + window.scrollX}px`;
                }
                let le = I + L + 32 > window.innerHeight, fe = I < 0;
                le && !fe ? d.style.top = `${T + 32 - L + window.scrollY - (x + 24)}px` : d.style.top = `${T + window.scrollY + 32}px`;
            }
            d.isConnected || (ke(d, o), n.append(d)), d.setAttribute("id", "slash-menu"), i.current = d, f.setAttribute("aria-controls", "slash-menu");
        }
    }, r[1] = n, r[2] = o, r[3] = c, r[4] = t, r[5] = a) : a = r[5];
    let l = a, u, g;
    r[6] !== c || r[7] !== l || r[8] !== t ? (u = ()=>{
        let f = c.getRootElement();
        if (t !== null) return l(), ()=>{
            f !== null && f.removeAttribute("aria-controls");
            let d = i.current;
            d !== null && d.isConnected && (d.remove(), d.removeAttribute("id"));
        };
    }, g = [
        c,
        l,
        t
    ], r[6] = c, r[7] = l, r[8] = t, r[9] = u, r[10] = g) : (u = r[9], g = r[10]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(u, g);
    let m;
    return r[11] !== t || r[12] !== e ? (m = (f)=>{
        t !== null && (f || e(null));
    }, r[11] = t, r[12] = e, r[13] = m) : m = r[13], Oe(t, i, l, m), i;
}
var lo = `\\.,\\+\\*\\?\\$\\@\\|#{}\\(\\)\\^\\-\\[\\]\\\\/!%'"~=<>_:;`;
function Ke(n) {
    let t = n.anchor;
    if (t.type !== "text") return null;
    let e = t.getNode();
    if (!e.isSimpleText()) return null;
    let o = t.offset;
    return e.getTextContent().slice(0, o);
}
function Et(n, t, e) {
    let o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDOMSelection"])(e);
    if (o === null || !o.isCollapsed) return !1;
    let r = o.anchorNode, c = n, s = o.anchorOffset;
    if (r == null || s == null) return !1;
    try {
        t.setStart(r, c), t.setEnd(r, s > 1 ? s : 1);
    } catch  {
        return !1;
    }
    return !0;
}
function Ue(n) {
    let t;
    return n.getEditorState().read(()=>{
        let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(e) && (t = Ke(e));
    }), t;
}
function _t(n, t) {
    return t !== 0 ? !1 : n.getEditorState().read(()=>{
        let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(e)) {
            let c = e.anchor.getNode().getPreviousSibling();
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(c) && c.isTextEntity();
        }
        return !1;
    });
}
function Tt(n) {
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startTransition"] ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startTransition"](n) : n();
}
var Ge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("ENABLE_SLASH_MENU_COMMAND");
function fo({ anchorClassName: n, anchorElem: t, groups: e, menuRenderFn: o, onClose: r, onOpen: c, onQueryChange: s, triggerFn: i }) {
    let [a] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), [l, u] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), g = pt(t, l, u, n), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        u(null), r != null && l !== null && r();
    }, [
        r,
        l
    ]), p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((f)=>{
        u(f), c != null && l === null && c(f);
    }, [
        c,
        l
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(a.registerCommand(Ge, ({ node: f })=>(a.getEditorState().read(()=>{
                let d = {
                    leadOffset: 0,
                    matchingString: "",
                    replaceableString: ""
                };
                if (!_t(a, d.leadOffset) && f !== null) {
                    let h = a._window ?? window, x = h.document.createRange();
                    Et(d.leadOffset, x, h) !== null && Tt(()=>p({
                            getRect: ()=>x.getBoundingClientRect(),
                            match: d
                        }));
                    return;
                }
            }), !0), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"])), [
        a,
        p
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let f = ()=>{
            a.getEditorState().read(()=>{
                let h = a._window ?? window, x = h.document.createRange(), E = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])(), _ = Ue(a);
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(E) || !E.isCollapsed() || _ === void 0 || x === null) {
                    m();
                    return;
                }
                let T = i({
                    editor: a,
                    query: _
                });
                if (s(T ? T.matchingString : null), T !== null && !_t(a, T.leadOffset) && Et(T.leadOffset, x, h) !== null) {
                    Tt(()=>p({
                            getRect: ()=>x.getBoundingClientRect(),
                            match: T
                        }));
                    return;
                }
                m();
            });
        }, d = a.registerUpdateListener(f);
        return ()=>{
            d();
        };
    }, [
        a,
        i,
        s,
        l,
        m,
        p
    ]), g.current === null || l === null || a === null ? null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(gt, {
        anchorElementRef: g,
        close: m,
        editor: a,
        groups: e,
        menuRenderFn: o,
        resolution: l,
        shouldSplitNodeWithQuery: !0
    });
}
var St = class n {
    _bottom;
    _left;
    _right;
    _top;
    constructor(t, e, o, r){
        let [c, s] = e <= r ? [
            e,
            r
        ] : [
            r,
            e
        ], [i, a] = t <= o ? [
            t,
            o
        ] : [
            o,
            t
        ];
        this._top = c, this._right = a, this._left = i, this._bottom = s;
    }
    static fromDOM(t) {
        let { height: e, left: o, top: r, width: c } = t.getBoundingClientRect();
        return n.fromLWTH(o, c, r, e);
    }
    static fromDOMRect(t) {
        let { height: e, left: o, top: r, width: c } = t;
        return n.fromLWTH(o, c, r, e);
    }
    static fromLTRB(t, e, o, r) {
        return new n(t, e, o, r);
    }
    static fromLWTH(t, e, o, r) {
        return new n(t, o, t + e, o + r);
    }
    static fromPoints(t, e) {
        let { x: o, y: r } = t, { x: c, y: s } = e;
        return n.fromLTRB(o, r, c, s);
    }
    contains(t) {
        if (it(t)) {
            let { x: s, y: i } = t, a = i < this._top, l = i > this._bottom, u = s < this._left, g = s > this._right;
            return {
                reason: {
                    isOnBottomSide: l,
                    isOnLeftSide: u,
                    isOnRightSide: g,
                    isOnTopSide: a
                },
                result: !a && !l && !u && !g
            };
        }
        let { bottom: e, left: o, right: r, top: c } = t;
        return c >= this._top && c <= this._bottom && e >= this._top && e <= this._bottom && o >= this._left && o <= this._right && r >= this._left && r <= this._right;
    }
    distanceFromPoint(t) {
        let e = this.contains(t);
        if (e.result) return {
            distance: 0,
            isOnBottomSide: e.reason.isOnBottomSide,
            isOnLeftSide: e.reason.isOnLeftSide,
            isOnRightSide: e.reason.isOnRightSide,
            isOnTopSide: e.reason.isOnTopSide
        };
        let o = 0, r = 0;
        return t.x < this._left ? o = this._left - t.x : t.x > this._right && (o = t.x - this._right), t.y < this._top ? r = this._top - t.y : t.y > this._bottom && (r = t.y - this._bottom), {
            distance: Math.sqrt(o * o + r * r),
            isOnBottomSide: t.y > this._bottom,
            isOnLeftSide: t.x < this._left,
            isOnRightSide: t.x > this._right,
            isOnTopSide: t.y < this._top
        };
    }
    equals({ bottom: t, left: e, right: o, top: r }) {
        return r === this._top && t === this._bottom && e === this._left && o === this._right;
    }
    generateNewRect({ bottom: t = this.bottom, left: e = this.left, right: o = this.right, top: r = this.top }) {
        return new n(e, r, o, t);
    }
    intersectsWith(t) {
        let { height: e, left: o, top: r, width: c } = t, { height: s, left: i, top: a, width: l } = this, u = o + c >= i + l ? o + c : i + l, g = r + e >= a + s ? r + e : a + s, m = o <= i ? o : i, p = r <= a ? r : a;
        return u - m <= c + l && g - p <= e + s;
    }
    get bottom() {
        return this._bottom;
    }
    get height() {
        return Math.abs(this._bottom - this._top);
    }
    get left() {
        return this._left;
    }
    get right() {
        return this._right;
    }
    get top() {
        return this._top;
    }
    get width() {
        return Math.abs(this._left - this._right);
    }
};
function po({ editorConfig: n }) {
    return ze({
        nodes: n.features.nodes
    });
}
function ze({ nodes: n }) {
    return n.map((t)=>"node" in t ? t.node : t);
}
;
;
;
;
var w = {
    markdownFormatKind: null,
    regEx: /(?:)/,
    regExForAutoFormatting: /(?:)/,
    requiresParagraphStart: !1
}, C = {
    ...w,
    requiresParagraphStart: !0
}, To = {
    ...C,
    export: y(1),
    markdownFormatKind: "paragraphH1",
    regEx: /^# /,
    regExForAutoFormatting: /^# /
}, So = {
    ...C,
    export: y(2),
    markdownFormatKind: "paragraphH2",
    regEx: /^## /,
    regExForAutoFormatting: /^## /
}, wo = {
    ...C,
    export: y(3),
    markdownFormatKind: "paragraphH3",
    regEx: /^### /,
    regExForAutoFormatting: /^### /
}, Ro = {
    ...C,
    export: y(4),
    markdownFormatKind: "paragraphH4",
    regEx: /^#### /,
    regExForAutoFormatting: /^#### /
}, Co = {
    ...C,
    export: y(5),
    markdownFormatKind: "paragraphH5",
    regEx: /^##### /,
    regExForAutoFormatting: /^##### /
}, Fo = {
    ...C,
    export: y(6),
    markdownFormatKind: "paragraphH6",
    regEx: /^###### /,
    regExForAutoFormatting: /^###### /
}, Io = {
    ...C,
    export: Ve,
    markdownFormatKind: "paragraphBlockQuote",
    regEx: /^> /,
    regExForAutoFormatting: /^> /
}, No = {
    ...C,
    export: Q,
    markdownFormatKind: "paragraphUnorderedList",
    regEx: /^(\s{0,10})- /,
    regExForAutoFormatting: /^(\s{0,10})- /
}, yo = {
    ...C,
    export: Q,
    markdownFormatKind: "paragraphUnorderedList",
    regEx: /^(\s{0,10})\* /,
    regExForAutoFormatting: /^(\s{0,10})\* /
}, bo = {
    ...C,
    export: Q,
    markdownFormatKind: "paragraphOrderedList",
    regEx: /^(\s{0,10})(\d+)\.\s/,
    regExForAutoFormatting: /^(\s{0,10})(\d+)\.\s/
}, Ao = {
    ...C,
    markdownFormatKind: "horizontalRule",
    regEx: /^\*\*\*$/,
    regExForAutoFormatting: /^\*\*\* /
}, Oo = {
    ...C,
    markdownFormatKind: "horizontalRule",
    regEx: /^---$/,
    regExForAutoFormatting: /^--- /
}, ko = {
    ...w,
    exportFormat: "code",
    exportTag: "`",
    markdownFormatKind: "code",
    regEx: /(`)(\s*)([^`]*)(\s*)(`)()/,
    regExForAutoFormatting: /(`)(\s*\b)([^`]*)(\b\s*)(`)(\s)$/
}, Mo = {
    ...w,
    exportFormat: "bold",
    exportTag: "**",
    markdownFormatKind: "bold",
    regEx: /(\*\*)(\s*)([^*]*)(\s*)(\*\*)()/,
    regExForAutoFormatting: /(\*\*)(\s*\b)([^*]*)(\b\s*)(\*\*)(\s)$/
}, Lo = {
    ...w,
    exportFormat: "italic",
    exportTag: "*",
    markdownFormatKind: "italic",
    regEx: /(\*)(\s*)([^*]*)(\s*)(\*)()/,
    regExForAutoFormatting: /(\*)(\s*\b)([^*]*)(\b\s*)(\*)(\s)$/
}, $o = {
    ...w,
    exportFormat: "bold",
    exportTag: "_",
    markdownFormatKind: "bold",
    regEx: /(__)(\s*)([^_]*)(\s*)(__)()/,
    regExForAutoFormatting: /(__)(\s*)([^_]*)(\s*)(__)(\s)$/
}, Do = {
    ...w,
    exportFormat: "italic",
    exportTag: "_",
    markdownFormatKind: "italic",
    regEx: /(_)()([^_]*)()(_)()/,
    regExForAutoFormatting: /(_)()([^_]*)()(_)(\s)$/
}, Bo = {
    ...w,
    exportFormat: "underline",
    exportTag: "<u>",
    exportTagClose: "</u>",
    markdownFormatKind: "underline",
    regEx: /(<u>)(\s*)([^<]*)(\s*)(<\/u>)()/,
    regExForAutoFormatting: /(<u>)(\s*\b)([^<]*)(\b\s*)(<\/u>)(\s)$/
}, Po = {
    ...w,
    exportFormat: "strikethrough",
    exportTag: "~~",
    markdownFormatKind: "strikethrough",
    regEx: /(~~)(\s*)([^~]*)(\s*)(~~)()/,
    regExForAutoFormatting: /(~~)(\s*\b)([^~]*)(\b\s*)(~~)(\s)$/
}, vo = {
    ...w,
    markdownFormatKind: "strikethrough_italic_bold",
    regEx: /(~~_\*\*)(\s*\b)([^*_~]+)(\b\s*)(\*\*_~~)()/,
    regExForAutoFormatting: /(~~_\*\*)(\s*\b)([^*_~]+)(\b\s*)(\*\*_~~)(\s)$/
}, Ho = {
    ...w,
    markdownFormatKind: "italic_bold",
    regEx: /(_\*\*)(\s*\b)([^*_]+)(\b\s*)(\*\*_)/,
    regExForAutoFormatting: /(_\*\*)(\s*\b)([^*_]+)(\b\s*)(\*\*_)(\s)$/
}, Ko = {
    ...w,
    markdownFormatKind: "strikethrough_italic",
    regEx: /(~~_)(\s*)([^_~]+)(\s*)(_~~)/,
    regExForAutoFormatting: /(~~_)(\s*)([^_~]+)(\s*)(_~~)(\s)$/
}, Uo = {
    ...w,
    markdownFormatKind: "strikethrough_bold",
    regEx: /(~~\*\*)(\s*\b)([^*~]+)(\b\s*)(\*\*~~)/,
    regExForAutoFormatting: /(~~\*\*)(\s*\b)([^*~]+)(\b\s*)(\*\*~~)(\s)$/
}, Go = {
    ...w,
    markdownFormatKind: "link",
    regEx: /(\[)([^\]]*)(\]\()([^)]*)(\)*)()/,
    regExForAutoFormatting: /(\[)([^\]]*)(\]\()([^)]*)(\)*)(\s)$/
};
function y(n) {
    return (t, e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isHeadingNode"])(t) && t.getTag() === "h" + n ? "#".repeat(n) + " " + e(t) : null;
}
function Q(n, t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(n) ? Rt(n, t, 0) : null;
}
var je = 4;
function Rt(n, t, e) {
    let o = [], r = n.getChildren(), c = 0;
    for (let s of r)if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListItemNode"])(s)) {
        if (s.getChildrenSize() === 1) {
            let l = s.getFirstChild();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(l)) {
                o.push(Rt(l, t, e + 1));
                continue;
            }
        }
        let i = " ".repeat(e * je), a = n.getListType() === "bullet" ? "- " : `${n.getStart() + c}. `;
        o.push(i + a + t(s)), c++;
    }
    return o.join(`
`);
}
function Ve(n, t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isQuoteNode"])(n) ? "> " + t(n) : null;
}
function D(n, t) {
    let e = {};
    for (let o of n){
        let r = t(o);
        r && (e[r] ? e[r].push(o) : e[r] = [
            o
        ]);
    }
    return e;
}
function b(n) {
    let t = D(n, (e)=>e.type);
    return {
        element: t.element || [],
        multilineElement: t["multiline-element"] || [],
        textFormat: t["text-format"] || [],
        textMatch: t["text-match"] || []
    };
}
var A = /[!-/:-@[-`{-~\s]/, Ze = /^\s{0,3}$/;
function M(n) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isParagraphNode"])(n)) return !1;
    let t = n.getFirstChild();
    return t == null || n.getChildrenSize() === 1 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(t) && Ze.test(t.getTextContent());
}
function Nt(n, t = !1) {
    let e = b(n), o = [
        ...e.multilineElement,
        ...e.element
    ], r = !t, c = e.textFormat.filter((s)=>s.format.length === 1).sort((s, i)=>s.format.includes("code") && !i.format.includes("code") ? 1 : !s.format.includes("code") && i.format.includes("code") ? -1 : 0);
    return (s)=>{
        let i = [], a = (s || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])()).getChildren();
        return a.forEach((l, u)=>{
            let g = en(l, o, c, e.textMatch);
            g != null && i.push(r && u > 0 && !M(l) && !M(a[u - 1]) ? `
`.concat(g) : g);
        }), i.join(`
`);
    };
}
function en(n, t, e, o) {
    for (let r of t){
        if (!r.export) continue;
        let c = r.export(n, (s)=>H(s, e, o));
        if (c != null) return c;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(n) ? H(n, e, o) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorNode"])(n) ? n.getTextContent() : null;
}
function H(n, t, e, o, r) {
    let c = [], s = n.getChildren();
    o || (o = []), r || (r = []);
    t: for (let i of s){
        for (let a of e){
            if (!a.export) continue;
            let l = a.export(i, (u)=>H(u, t, e, o, [
                    ...r,
                    ...o
                ]), (u, g)=>Ct(u, g, t, o, r));
            if (l != null) {
                c.push(l);
                continue t;
            }
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isLineBreakNode"])(i) ? c.push(`
`) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(i) ? c.push(Ct(i, i.getTextContent(), t, o, r)) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(i) ? c.push(H(i, t, e, o, r)) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorNode"])(i) && c.push(i.getTextContent());
    }
    return c.join("");
}
function Ct(n, t, e, o, r) {
    let c = t.trim(), s = c;
    n.hasFormat("code") || (s = s.replace(/([*_`~\\])/g, "\\$1"));
    let i = "", a = "", l = "", u = Ft(n, !0), g = Ft(n, !1), m = new Set;
    for (let p of e){
        let f = p.format[0], d = p.tag;
        B(n, f) && !m.has(f) && (m.add(f), (!B(u, f) || !o.find((h)=>h.tag === d)) && (o.push({
            format: f,
            tag: d
        }), i += d));
    }
    for(let p = 0; p < o.length; p++){
        let f = o[p], d = B(n, f.format), h = B(g, f.format);
        if (d && h) continue;
        let x = [
            ...o
        ];
        for(; x.length > p;){
            let E = x.pop();
            r && E && r.find((_)=>_.tag === E.tag) || (E && typeof E.tag == "string" && (d ? h || (l += E.tag) : a += E.tag), o.pop());
        }
        break;
    }
    return s = i + s + l, a + t.replace(c, ()=>s);
}
function Ft(n, t) {
    let e = t ? n.getPreviousSibling() : n.getNextSibling();
    if (!e) {
        let o = n.getParentOrThrow();
        o.isInline() && (e = t ? o.getPreviousSibling() : o.getNextSibling());
    }
    for(; e;){
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(e)) {
            if (!e.isInline()) break;
            let o = t ? e.getLastDescendant() : e.getFirstDescendant();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(o)) return o;
            e = t ? e.getPreviousSibling() : e.getNextSibling();
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(e)) return e;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(e)) return null;
    }
    return null;
}
function B(n, t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(n) && n.hasFormat(t);
}
;
;
;
;
;
function yt(n, t) {
    let e = n.getTextContent(), o = nn(e, t);
    if (!o) return null;
    let r = o.index || 0, c = r + o[0].length, s = t.transformersByTag[o[1]];
    return {
        endIndex: c,
        match: o,
        startIndex: r,
        transformer: s
    };
}
function nn(n, t) {
    let e = n.match(t.openTagsRegExp);
    if (e == null) return null;
    for (let o of e){
        let r = o.replace(/^\s/, ""), c = t.fullMatchRegExpByTag[r];
        if (c == null) continue;
        let s = n.match(c), i = t.transformersByTag[r];
        if (s != null && i != null) {
            if (i.intraword !== !1) return s;
            let { index: a = 0 } = s, l = n[a - 1], u = n[a + s[0].length];
            if ((!l || A.test(l)) && (!u || A.test(u))) return s;
        }
    }
    return null;
}
function bt(n, t, e, o, r) {
    let c = n.getTextContent(), s, i, a;
    if (r[0] === c ? a = n : t === 0 ? [a, s] = n.splitText(e) : [i, a, s] = n.splitText(t, e), a.setTextContent(r[2]), o) for (let l of o.format)a.hasFormat(l) || a.toggleFormat(l);
    return {
        nodeAfter: s,
        nodeBefore: i,
        transformedNode: a
    };
}
function At(n, t) {
    let e = n, o, r, c, s;
    for (let i of t){
        if (!i.replace || !i.importRegExp) continue;
        let a = e.getTextContent().match(i.importRegExp);
        if (!a) continue;
        let l = a.index || 0, u = i.getEndIndex ? i.getEndIndex(e, a) : l + a[0].length;
        u !== !1 && (o === void 0 || r === void 0 || l < o && u > r) && (o = l, r = u, c = i, s = a);
    }
    return o === void 0 || r === void 0 || c === void 0 || s === void 0 ? null : {
        endIndex: r,
        match: s,
        startIndex: o,
        transformer: c
    };
}
function Ot(n, t, e, o, r) {
    let c, s, i;
    if (t === 0 ? [i, c] = n.splitText(e) : [s, i, c] = n.splitText(t, e), !o.replace) return null;
    let a = i ? o.replace(i, r) : void 0;
    return {
        nodeAfter: c,
        nodeBefore: s,
        transformedNode: a || void 0
    };
}
function F(n, t, e) {
    let o = yt(n, t), r = At(n, e);
    if (o && r && (o.startIndex <= r.startIndex && o.endIndex >= r.endIndex ? r = null : o = null), o) {
        let i = bt(n, o.startIndex, o.endIndex, o.transformer, o.match);
        i.nodeAfter && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(i.nodeAfter) && !i.nodeAfter.hasFormat("code") && F(i.nodeAfter, t, e), i.nodeBefore && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(i.nodeBefore) && !i.nodeBefore.hasFormat("code") && F(i.nodeBefore, t, e), i.transformedNode && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(i.transformedNode) && !i.transformedNode.hasFormat("code") && F(i.transformedNode, t, e);
    } else if (r) {
        let i = Ot(n, r.startIndex, r.endIndex, r.transformer, r.match);
        if (!i) return;
        i.nodeAfter && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(i.nodeAfter) && !i.nodeAfter.hasFormat("code") && F(i.nodeAfter, t, e), i.nodeBefore && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(i.nodeBefore) && !i.nodeBefore.hasFormat("code") && F(i.nodeBefore, t, e), i.transformedNode && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(i.transformedNode) && !i.transformedNode.hasFormat("code") && F(i.transformedNode, t, e);
    }
    let s = n.getTextContent().replace(/\\([*_`~])/g, "$1");
    n.setTextContent(s);
}
function Mt(n, t = !1) {
    let e = b(n), o = pn(e.textFormat);
    return (r, c)=>{
        let s = r.split(`
`), i = s.length, a = c || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
        a.clear();
        for(let u = 0; u < i; u++){
            let g = s[u], [m, p] = mn(s, u, e.multilineElement, a);
            if (m) {
                u = p;
                continue;
            }
            gn(g, a, e.element, o, e.textMatch);
        }
        let l = a.getChildren();
        for (let u of l)!t && M(u) && a.getChildrenSize() > 1 && u.remove();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])() !== null && a.selectStart();
    };
}
function mn(n, t, e, o) {
    for (let r of e){
        let { handleImportAfterStartMatch: c, regExpEnd: s, regExpStart: i, replace: a } = r, l = n[t]?.match(i);
        if (!l) continue;
        if (c) {
            let f = c({
                lines: n,
                rootNode: o,
                startLineIndex: t,
                startMatch: l,
                transformer: r
            });
            if (f === null) continue;
            if (f) return f;
        }
        let u = typeof s == "object" && "regExp" in s ? s.regExp : s, g = s && typeof s == "object" && "optional" in s ? s.optional : !s, m = t, p = n.length;
        for(; m < p;){
            let f = u ? n[m]?.match(u) : null;
            if (!f && (!g || g && m < p - 1)) {
                m++;
                continue;
            }
            if (f && t === m && f.index === l.index) {
                m++;
                continue;
            }
            let d = [];
            if (f && t === m) d.push(n[t].slice(l[0].length, -f[0].length));
            else for(let h = t; h <= m; h++){
                let x = n[h];
                if (h === t) {
                    let E = x.slice(l[0].length);
                    d.push(E);
                } else if (h === m && f) {
                    let E = x.slice(0, -f[0].length);
                    d.push(E);
                } else d.push(x);
            }
            if (a(o, null, l, f, d, !0) !== !1) return [
                !0,
                m
            ];
            break;
        }
    }
    return [
        !1,
        t
    ];
}
function gn(n, t, e, o, r) {
    let c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(n), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])();
    s.append(c), t.append(s);
    for (let { regExp: i, replace: a } of e){
        let l = n.match(i);
        if (l && (c.setTextContent(n.slice(l[0].length)), a(s, [
            c
        ], l, !0) !== !1)) break;
    }
    if (F(c, o, r), s.isAttached() && n.length > 0) {
        let i = s.getPreviousSibling();
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isParagraphNode"])(i) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isQuoteNode"])(i) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(i)) {
            let a = i;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(i)) {
                let l = i.getLastDescendant();
                l == null ? a = null : a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$findMatchingParent"])(l, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListItemNode"]);
            }
            a != null && a.getTextContentSize() > 0 && (a.splice(a.getChildrenSize(), 0, [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createLineBreakNode"])(),
                ...s.getChildren()
            ]), s.remove());
        }
    }
}
function pn(n) {
    let t = {}, e = {}, o = [], r = "(?<![\\\\])";
    for (let c of n){
        let { tag: s } = c;
        t[s] = c;
        let i = s.replace(/([*^+])/g, "\\$1");
        o.push(i), s.length === 1 ? e[s] = new RegExp(`(?<![\\\\${i}])(${i})((\\\\${i})?.*?[^${i}\\s](\\\\${i})?)((?<!\\\\)|(?<=\\\\\\\\))(${i})(?![\\\\${i}])`) : e[s] = new RegExp(`(?<!\\\\)(${i})((\\\\${i})?.*?[^\\s](\\\\${i})?)((?<!\\\\)|(?<=\\\\\\\\))(${i})(?!\\\\)`);
    }
    return {
        fullMatchRegExpByTag: e,
        openTagsRegExp: new RegExp(`${r}(${o.join("|")})`, "g"),
        transformersByTag: t
    };
}
;
function _n(n, t, e, o) {
    let r = n.getParent();
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRootOrShadowRoot"])(r) || n.getFirstChild() !== t) return !1;
    let c = t.getTextContent();
    if (c[e - 1] !== " ") return !1;
    for (let { regExp: s, replace: i } of o){
        let a = c.match(s);
        if (a && a[0].length === (a[0].endsWith(" ") ? e : e - 1)) {
            let l = t.getNextSiblings(), [u, g] = t.splitText(e);
            u?.remove();
            let m = g ? [
                g,
                ...l
            ] : l;
            if (i(n, m, a, !1) !== !1) return !0;
        }
    }
    return !1;
}
function Tn(n, t, e, o) {
    let r = n.getParent();
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRootOrShadowRoot"])(r) || n.getFirstChild() !== t) return !1;
    let c = t.getTextContent();
    if (c[e - 1] !== " ") return !1;
    for (let { regExpEnd: s, regExpStart: i, replace: a } of o){
        if (s && !("optional" in s) || s && "optional" in s && !s.optional) continue;
        let l = c.match(i);
        if (l && l[0].length === (l[0].endsWith(" ") ? e : e - 1)) {
            let u = t.getNextSiblings(), [g, m] = t.splitText(e);
            g?.remove();
            let p = m ? [
                m,
                ...u
            ] : u;
            if (a(n, p, l, null, null, !1) !== !1) return !0;
        }
    }
    return !1;
}
function Sn(n, t, e) {
    let o = n.getTextContent(), r = o[t - 1], c = e[r];
    if (c == null) return !1;
    t < o.length && (o = o.slice(0, t));
    for (let s of c){
        if (!s.replace || !s.regExp) continue;
        let i = o.match(s.regExp);
        if (i === null) continue;
        let a = i.index || 0, l = a + i[0].length, u;
        return a === 0 ? [u] = n.splitText(l) : [, u] = n.splitText(a, l), u && (u.selectNext(0, 0), s.replace(u, i)), !0;
    }
    return !1;
}
function wn(n, t, e) {
    let o = n.getTextContent(), r = t - 1, c = o[r], s = e[c];
    if (!s) return !1;
    for (let i of s){
        let { tag: a } = i, l = a.length, u = r - l + 1;
        if (l > 1 && !Bt(o, u, a, 0, l) || o[u - 1] === " ") continue;
        let g = o[r + 1];
        if (i.intraword === !1 && g && !A.test(g)) continue;
        let m = n, p = m, f = Lt(o, u, a), d = p;
        for(; f < 0 && (d = d.getPreviousSibling()) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isLineBreakNode"])(d);)if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(d)) {
            let R = d.getTextContent();
            p = d, f = Lt(R, R.length, a);
        }
        if (f < 0 || p === m && f + l === u) continue;
        let h = p.getTextContent();
        if (f > 0 && h[f - 1] === c) continue;
        let x = h[f - 1];
        if (i.intraword === !1 && x && !A.test(x)) continue;
        let E = m.getTextContent(), _ = E.slice(0, u) + E.slice(r + 1);
        m.setTextContent(_);
        let T = p === m ? _ : h;
        p.setTextContent(T.slice(0, f) + T.slice(f + l));
        let I = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])(), S = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createRangeSelection"])();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$setSelection"])(S);
        let L = r - l * (p === m ? 2 : 1) + 1;
        S.anchor.set(p.__key, f, "text"), S.focus.set(m.__key, L, "text");
        for (let R of i.format)S.hasFormat(R) || S.formatText(R);
        S.anchor.set(S.focus.key, S.focus.offset, S.focus.type);
        for (let R of i.format)S.hasFormat(R) && S.toggleFormat(R);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(I) && (S.format = I.format), !0;
    }
    return !1;
}
function Lt(n, t, e) {
    let o = e.length;
    for(let r = t; r >= o; r--){
        let c = r - o;
        if (Bt(n, c, e, 0, o) && n[c + o] !== " ") return c;
    }
    return -1;
}
function Bt(n, t, e, o, r) {
    for(let c = 0; c < r; c++)if (n[t + c] !== e[o + c]) return !1;
    return !0;
}
function ur(n, t = K) {
    let e = b(t), o = D(e.textFormat, ({ tag: s })=>s[s.length - 1]), r = D(e.textMatch, ({ trigger: s })=>s);
    for (let s of t){
        let i = s.type;
        if (i === "element" || i === "text-match" || i === "multiline-element") {
            let a = s.dependencies;
            for (let l of a)if (!n.hasNode(l)) throw new Error("MarkdownShortcuts: missing dependency %s for transformer. Ensure node dependency is included in editor initial config." + l.getType());
        }
    }
    let c = (s, i, a)=>{
        _n(s, i, a, e.element) || Tn(s, i, a, e.multilineElement) || Sn(i, a, r) || wn(i, a, o);
    };
    return n.registerUpdateListener(({ dirtyLeaves: s, editorState: i, prevEditorState: a, tags: l })=>{
        if (l.has("collaboration") || l.has("historic") || n.isComposing()) return;
        let u = i.read(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"]), g = a.read(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"]);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(g) || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(u) || !u.isCollapsed() || u.is(g)) return;
        let m = u.anchor.key, p = u.anchor.offset, f = i._nodeMap.get(m);
        !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(f) || !s.has(m) || p !== 1 && p > g.anchor.offset + 1 || n.update(()=>{
            if (f.hasFormat("code")) return;
            let d = f.getParent();
            d !== null && c(d, f, u.anchor.offset);
        });
    });
}
;
;
;
var vt = /^[\t ]*$/, Gt = /^(\s*)(\d+)\.\s/, zt = /^(\s*)[-*+]\s/, Xt = /^(\s*)(?:-\s)?\s?(\[(\s|x)?\])\s/i, Z = /^(#{1,6})\s/, Yt = /^>\s/, kn = /^[ \t]*(\\`\\`\\`|```)(\w+)?/, Ht = /[ \t]*(\\`\\`\\`|```)$/, Mn = /^[ \t]*```[^`]+(?:(?:`{1,2}|`{4,})[^`]+)*```(?:[^`]|$)/, Ln = /^\|(.+)\|\s?$/, $n = /^(\| ?:?-*:? ?)+\|\s?$/, Kt = /^[ \t]*<[a-z_][\w-]*(?:\s[^<>]*)?\/?>/i, Ut = /^[ \t]*<\/[a-z_][\w-]*\s*>/i, Dn = (n)=>(t, e, o)=>{
        let r = n(o);
        r.append(...e), t.replace(r), r.select(0, 0);
    }, Wt = 4;
function Bn(n) {
    let t = n.match(/\t/g), e = n.match(/ /g), o = 0;
    return t && (o += t.length), e && (o += Math.floor(e.length / Wt)), o;
}
var et = (n)=>(t, e, o)=>{
        let r = t.getPreviousSibling(), c = t.getNextSibling(), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createListItemNode"])(n === "check" ? o[3] === "x" : void 0);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(c) && c.getListType() === n) {
            let a = c.getFirstChild();
            a !== null ? a.insertBefore(s) : c.append(s), t.remove();
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(r) && r.getListType() === n) r.append(s), t.remove();
        else {
            let a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createListNode"])(n, n === "number" ? Number(o[2]) : void 0);
            a.append(s), t.replace(a);
        }
        s.append(...e), s.select(0, 0);
        let i = Bn(o[1]);
        i && s.setIndent(i);
    }, U = (n, t, e)=>{
    let o = [], r = n.getChildren(), c = 0;
    for (let s of r)if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListItemNode"])(s)) {
        if (s.getChildrenSize() === 1) {
            let u = s.getFirstChild();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(u)) {
                o.push(U(u, t, e + 1));
                continue;
            }
        }
        let i = " ".repeat(e * Wt), a = n.getListType(), l = a === "number" ? `${n.getStart() + c}. ` : a === "check" ? `- [${s.getChecked() ? "x" : " "}] ` : "- ";
        o.push(i + l + t(s)), c++;
    }
    return o.join(`
`);
}, qt = {
    type: "element",
    dependencies: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeadingNode"]
    ],
    export: (n, t)=>{
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isHeadingNode"])(n)) return null;
        let e = Number(n.getTag().slice(1));
        return "#".repeat(e) + " " + t(n);
    },
    regExp: Z,
    replace: Dn((n)=>{
        let t = "h" + n[1].length;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createHeadingNode"])(t);
    })
}, Qt = {
    type: "element",
    dependencies: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuoteNode"]
    ],
    export: (n, t)=>{
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isQuoteNode"])(n)) return null;
        let e = t(n).split(`
`), o = [];
        for (let r of e)o.push("> " + r);
        return o.join(`
`);
    },
    regExp: Yt,
    replace: (n, t, e, o)=>{
        if (o) {
            let c = n.getPreviousSibling();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isQuoteNode"])(c)) {
                c.splice(c.getChildrenSize(), 0, [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createLineBreakNode"])(),
                    ...t
                ]), c.select(0, 0), n.remove();
                return;
            }
        }
        let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createQuoteNode"])();
        r.append(...t), n.replace(r), r.select(0, 0);
    }
}, jt = {
    type: "element",
    dependencies: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"]
    ],
    export: (n, t)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(n) ? U(n, t, 0) : null,
    regExp: zt,
    replace: et("bullet")
}, Pn = {
    type: "element",
    dependencies: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"]
    ],
    export: (n, t)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(n) ? U(n, t, 0) : null,
    regExp: Xt,
    replace: et("check")
}, Vt = {
    type: "element",
    dependencies: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"]
    ],
    export: (n, t)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(n) ? U(n, t, 0) : null,
    regExp: Gt,
    replace: et("number")
}, Zt = {
    type: "text-format",
    format: [
        "code"
    ],
    tag: "`"
}, Jt = {
    type: "text-format",
    format: [
        "highlight"
    ],
    tag: "=="
}, te = {
    type: "text-format",
    format: [
        "bold",
        "italic"
    ],
    tag: "***"
}, ee = {
    type: "text-format",
    format: [
        "bold",
        "italic"
    ],
    intraword: !1,
    tag: "___"
}, ne = {
    type: "text-format",
    format: [
        "bold"
    ],
    tag: "**"
}, oe = {
    type: "text-format",
    format: [
        "bold"
    ],
    intraword: !1,
    tag: "__"
}, re = {
    type: "text-format",
    format: [
        "strikethrough"
    ],
    tag: "~~"
}, ie = {
    type: "text-format",
    format: [
        "italic"
    ],
    tag: "*"
}, se = {
    type: "text-format",
    format: [
        "italic"
    ],
    intraword: !1,
    tag: "_"
};
function ce(n, t) {
    let e = n.split(`
`), o = !1, r = [], c = 0;
    for(let s = 0; s < e.length; s++){
        let i = e[s], a = r[r.length - 1];
        if (Mn.test(i)) {
            r.push(i);
            continue;
        }
        if (Ht.test(i)) {
            c === 0 && (o = !0), c === 1 && (o = !1), c > 0 && c--, r.push(i);
            continue;
        }
        if (kn.test(i)) {
            o = !0, c++, r.push(i);
            continue;
        }
        if (o) {
            r.push(i);
            continue;
        }
        vt.test(i) || vt.test(a) || !a || Z.test(a) || Z.test(i) || Yt.test(i) || Gt.test(i) || zt.test(i) || Xt.test(i) || Ln.test(i) || $n.test(i) || !t || Kt.test(i) || Ut.test(i) || Kt.test(a) || Ut.test(a) || Ht.test(a) ? r.push(i) : r[r.length - 1] = a + " " + i.trim();
    }
    return r.join(`
`);
}
var vn = [
    qt,
    Qt,
    jt,
    Vt
], Hn = [], Kn = [
    Zt,
    te,
    ee,
    ne,
    oe,
    Jt,
    ie,
    se,
    re
], Un = [], K = [
    ...vn,
    ...Hn,
    ...Kn,
    ...Un
];
function Tr(n, t = K, e, o = !1, r = !0) {
    let c = o ? n : ce(n, r);
    return Mt(t, o)(c, e);
}
function Sr(n = K, t, e = !1) {
    return Nt(n, e)(t);
}
;
 //# sourceMappingURL=chunk-AFXLIYGL.js.map
}),
"[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createAutoLinkNode",
    ()=>Nt,
    "$createBlockNode",
    ()=>Ae,
    "$createHorizontalRuleNode",
    ()=>Ye,
    "$createLinkNode",
    ()=>_e,
    "$createRelationshipNode",
    ()=>He,
    "$createUploadNode",
    ()=>pe,
    "$isAutoLinkNode",
    ()=>we,
    "$isBlockNode",
    ()=>$e,
    "$isHorizontalRuleNode",
    ()=>St,
    "$isLinkNode",
    ()=>J,
    "$isRelationshipNode",
    ()=>Er,
    "$isUploadNode",
    ()=>ct,
    "AlignFeatureClient",
    ()=>Ac,
    "AutoLinkNode",
    ()=>Te,
    "BlockCollapsible",
    ()=>kC,
    "BlockEditButton",
    ()=>wC,
    "BlockNode",
    ()=>ie,
    "BlockRemoveButton",
    ()=>NC,
    "BlockquoteFeatureClient",
    ()=>Uc,
    "BlocksFeatureClient",
    ()=>qu,
    "BoldFeatureClient",
    ()=>_d,
    "ChecklistFeatureClient",
    ()=>Lf,
    "CodeBlockBlockComponent",
    ()=>ZC,
    "CodeComponent",
    ()=>$C,
    "DETAIL_TYPE_TO_DETAIL",
    ()=>b0,
    "DOUBLE_LINE_BREAK",
    ()=>h0,
    "DebugJsxConverterFeatureClient",
    ()=>I0,
    "ELEMENT_FORMAT_TO_TYPE",
    ()=>_0,
    "ELEMENT_TYPE_TO_FORMAT",
    ()=>k0,
    "FixedToolbarFeatureClient",
    ()=>oh,
    "HeadingFeatureClient",
    ()=>gm,
    "HorizontalRuleFeatureClient",
    ()=>$m,
    "HorizontalRuleNode",
    ()=>ke,
    "INSERT_BLOCK_COMMAND",
    ()=>Xe,
    "INSERT_INLINE_BLOCK_COMMAND",
    ()=>Ze,
    "IS_ALL_FORMATTING",
    ()=>p0,
    "IndentFeatureClient",
    ()=>Zm,
    "InlineBlockContainer",
    ()=>CC,
    "InlineBlockEditButton",
    ()=>cC,
    "InlineBlockLabel",
    ()=>hC,
    "InlineBlockRemoveButton",
    ()=>mC,
    "InlineCodeFeatureClient",
    ()=>Nd,
    "InlineToolbarFeatureClient",
    ()=>fh,
    "ItalicFeatureClient",
    ()=>Id,
    "LTR_REGEX",
    ()=>x0,
    "LexicalPluginToLexicalFeatureClient",
    ()=>Zf,
    "LinkFeatureClient",
    ()=>mf,
    "LinkNode",
    ()=>oe,
    "NON_BREAKING_SPACE",
    ()=>f0,
    "NodeFormat",
    ()=>F,
    "OrderedListFeatureClient",
    ()=>Af,
    "ParagraphFeatureClient",
    ()=>l0,
    "RTL_REGEX",
    ()=>g0,
    "RelationshipFeatureClient",
    ()=>k1,
    "RelationshipNode",
    ()=>Se,
    "RenderLexical",
    ()=>n2,
    "RichTextField",
    ()=>Qx,
    "SlateToLexicalFeatureClient",
    ()=>r0,
    "StrikethroughFeatureClient",
    ()=>Ad,
    "SubscriptFeatureClient",
    ()=>Bd,
    "SuperscriptFeatureClient",
    ()=>Wd,
    "TEXT_MODE_TO_TYPE",
    ()=>T0,
    "TEXT_TYPE_TO_FORMAT",
    ()=>C0,
    "TEXT_TYPE_TO_MODE",
    ()=>w0,
    "TOGGLE_LINK_COMMAND",
    ()=>ue,
    "TableFeatureClient",
    ()=>ix,
    "TestRecorderFeatureClient",
    ()=>md,
    "TextStateFeatureClient",
    ()=>lm,
    "ToolbarButton",
    ()=>Ft,
    "ToolbarDropdown",
    ()=>Ue,
    "TreeViewFeatureClient",
    ()=>xd,
    "UnderlineFeatureClient",
    ()=>zd,
    "UnorderedListFeatureClient",
    ()=>Wf,
    "UploadFeatureClient",
    ()=>Wx,
    "UploadNode",
    ()=>me,
    "addSwipeDownListener",
    ()=>iC,
    "addSwipeLeftListener",
    ()=>rC,
    "addSwipeRightListener",
    ()=>nC,
    "addSwipeUpListener",
    ()=>lC,
    "buildDefaultEditorState",
    ()=>i2,
    "buildEditorState",
    ()=>pc,
    "codeConverterClient",
    ()=>tc,
    "createBlockNode",
    ()=>or,
    "createClientFeature",
    ()=>$,
    "defaultColors",
    ()=>v0,
    "defaultEditorLexicalConfig",
    ()=>Yr,
    "getDOMRangeRect",
    ()=>Ir,
    "getRestPopulateFn",
    ()=>yC,
    "getSelectedNode",
    ()=>qe,
    "isHTMLElement",
    ()=>eC,
    "joinClasses",
    ()=>tC,
    "sanitizeClientEditorConfig",
    ()=>qr,
    "sanitizeClientFeatures",
    ()=>Qa,
    "setFloatingElemPosition",
    ()=>_o,
    "setFloatingElemPositionForLinkEditor",
    ()=>fo,
    "slashMenuBasicGroupWithItems",
    ()=>Z,
    "toolbarAddDropdownGroupWithItems",
    ()=>be,
    "toolbarFeatureButtonsGroupWithItems",
    ()=>nr,
    "toolbarFormatGroupWithItems",
    ()=>Y,
    "toolbarTextDropdownGroupWithItems",
    ()=>te,
    "useBlockComponentContext",
    ()=>Ce,
    "useLexicalListDrawer",
    ()=>Ot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-TRHFMZ3F.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$DBWINSQN$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-DBWINSQN.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$O6XRT2H3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-O6XRT2H3.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$INBEEENE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-INBEEENE.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$F26IQ5RE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-F26IQ5RE.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-AFXLIYGL.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-BZZVLW4U.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalComposerContext.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalDecoratorBlockNode.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+utils@0.35.0/node_modules/@lexical/utils/LexicalUtils.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lexical@0.35.0/node_modules/lexical/Lexical.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+rich-text@0.35.0/node_modules/@lexical/rich-text/LexicalRichText.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$selection$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+selection@0.35.0/node_modules/@lexical/selection/LexicalSelection.dev.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+translations@3.70.0/node_modules/@payloadcms/translations/dist/utilities/getTranslation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsox$40$1$2e$2$2e$121$2f$node_modules$2f$jsox$2f$lib$2f$jsox$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jsox@1.2.121/node_modules/jsox/lib/jsox.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/bson-objectid@2.0.4/node_modules/bson-objectid/objectid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/useLexicalEditable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c__as__useConfig$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/chunk-53XJ3K67.js [app-client] (ecmascript) <export c as useConfig>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/chunk-7V3NHDV6.js [app-client] (ecmascript) <export d as useTranslation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/shared/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/payload@3.70.0_graphql@16.12.0_typescript@5.7.3/node_modules/payload/dist/utilities/deepCopyObject.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$reduceFieldsToValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/payload@3.70.0_graphql@16.12.0_typescript@5.7.3/node_modules/payload/dist/utilities/reduceFieldsToValues.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/uuid@10.0.0/node_modules/uuid/dist/esm-browser/v4.js [app-client] (ecmascript) <export default as v4>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$headless$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$headless$2f$LexicalHeadless$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+headless@0.35.0/node_modules/@lexical/headless/LexicalHeadless.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalTreeView$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalTreeView.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+table@0.35.0/node_modules/@lexical/table/LexicalTable.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalTabIndentationPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalTabIndentationPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalClickableLinkPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalClickableLinkPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.1.1_@babel+core@7.28.5_@playwright+test@1.56.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.77.4/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$formatAdminURL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/payload@3.70.0_graphql@16.12.0_typescript@5.7.3/node_modules/payload/dist/utilities/formatAdminURL.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+list@0.35.0/node_modules/@lexical/list/LexicalList.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalListPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalCheckListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalCheckListPlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalTablePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lexical+react@0.35.0_react-dom@19.2.3_react@19.2.3__react@19.2.3_yjs@13.6.29/node_modules/@lexical/react/LexicalTablePlugin.dev.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__f__as__ShimmerEffect$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+ui@3.70.0_@types+react@19.2.1_monaco-editor@0.55.1_next@16.1.1_@babel+core@7.28.5_wljpfz4j2jdp7c5zdolenvksbi/node_modules/@payloadcms/ui/dist/exports/client/chunk-53XJ3K67.js [app-client] (ecmascript) <export f as ShimmerEffect>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$deepmerge$40$4$2e$3$2e$1$2f$node_modules$2f$deepmerge$2f$dist$2f$cjs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__deepMerge$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/deepmerge@4.3.1/node_modules/deepmerge/dist/cjs.js [app-client] (ecmascript) <export default as deepMerge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$qs$2d$esm$40$7$2e$0$2e$2$2f$node_modules$2f$qs$2d$esm$2f$lib$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/qs-esm@7.0.2/node_modules/qs-esm/lib/stringify.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
function Z(t) {
    return {
        items: t,
        key: "basic",
        label: ({ i18n: e })=>e.t("lexical:general:slashMenuBasicGroupLabel")
    };
}
;
;
;
;
;
;
;
;
var ln = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 5H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 10H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M5 15H15",
                stroke: "currentColor",
                strokeWidth: "1.5"
            })
        ]
    });
;
;
var sn = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 5H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 10H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 15H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            })
        ]
    });
;
;
var Zt = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 5H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 10H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 15H12.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            })
        ]
    });
;
;
var an = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 5H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 10H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M7.5 15H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            })
        ]
    });
var $ = (t)=>(o)=>{
        let r = {
            clientFeatureProps: o
        };
        if (typeof t == "function") r.feature = ({ config: n, featureClientImportMap: l, featureClientSchemaMap: i, featureProviderMap: s, field: d, resolvedFeatures: c, schemaPath: u, unSanitizedEditorConfig: a })=>{
            let m = t({
                config: n,
                featureClientImportMap: l,
                featureClientSchemaMap: i,
                featureProviderMap: s,
                field: d,
                props: o,
                resolvedFeatures: c,
                schemaPath: u,
                unSanitizedEditorConfig: a
            });
            return m.sanitizedClientFeatureProps === null && (m.sanitizedClientFeatureProps = o), m;
        };
        else {
            let n = {
                ...t
            };
            n.sanitizedClientFeatureProps = o, r.feature = n;
        }
        return r;
    };
var cn = (t)=>({
        type: "dropdown",
        ChildComponent: Zt,
        items: t,
        key: "align",
        order: 30
    });
var Ie = (t)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(t) ? t.getFormatType() : t.__format, un = [
    cn([
        {
            ChildComponent: Zt,
            isActive: ({ selection: t })=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t)) return !1;
                for (let e of t.getNodes()){
                    if (((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(e) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorBlockNode"])(e)) && Ie(e) === "left") continue;
                    let o = e.getParent();
                    if (!(((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(o) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorBlockNode"])(o)) && Ie(o) === "left")) return !1;
                }
                return !0;
            },
            key: "alignLeft",
            label: ({ i18n: t })=>t.t("lexical:align:alignLeftLabel"),
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_ELEMENT_COMMAND"], "left");
            },
            order: 1
        },
        {
            ChildComponent: ln,
            isActive: ({ selection: t })=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t)) return !1;
                for (let e of t.getNodes()){
                    if (((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(e) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorBlockNode"])(e)) && Ie(e) === "center") continue;
                    let o = e.getParent();
                    if (!(((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(o) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorBlockNode"])(o)) && Ie(o) === "center")) return !1;
                }
                return !0;
            },
            key: "alignCenter",
            label: ({ i18n: t })=>t.t("lexical:align:alignCenterLabel"),
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_ELEMENT_COMMAND"], "center");
            },
            order: 2
        },
        {
            ChildComponent: an,
            isActive: ({ selection: t })=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t)) return !1;
                for (let e of t.getNodes()){
                    if (((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(e) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorBlockNode"])(e)) && Ie(e) === "right") continue;
                    let o = e.getParent();
                    if (!(((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(o) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorBlockNode"])(o)) && Ie(o) === "right")) return !1;
                }
                return !0;
            },
            key: "alignRight",
            label: ({ i18n: t })=>t.t("lexical:align:alignRightLabel"),
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_ELEMENT_COMMAND"], "right");
            },
            order: 3
        },
        {
            ChildComponent: sn,
            isActive: ({ selection: t })=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t)) return !1;
                for (let e of t.getNodes()){
                    if (((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(e) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorBlockNode"])(e)) && Ie(e) === "justify") continue;
                    let o = e.getParent();
                    if (!(((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(o) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorBlockNode"])(o)) && Ie(o) === "justify")) return !1;
                }
                return !0;
            },
            key: "alignJustify",
            label: ({ i18n: t })=>t.t("lexical:align:alignJustifyLabel"),
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_ELEMENT_COMMAND"], "justify");
            },
            order: 4
        }
    ])
], $c = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3), [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), o, r;
    return t[0] !== e ? (o = ()=>e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_ELEMENT_COMMAND"], Fc, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), r = [
        e
    ], t[0] = e, t[1] = o, t[2] = r) : (o = t[1], r = t[2]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(o, r), null;
}, Ac = $({
    plugins: [
        {
            Component: $c,
            position: "normal"
        }
    ],
    toolbarFixed: {
        groups: un
    },
    toolbarInline: {
        groups: un
    }
});
function Oc(t) {
    return ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(t) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isDecoratorBlockNode"])(t)) && !t.isInline();
}
function Fc(t) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(e) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])(e)) return !1;
    let o = e.getNodes();
    for (let r of o){
        let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$findMatchingParent"])(r, Oc);
        n !== null && n.setFormat(t);
    }
    return !0;
}
;
;
;
;
;
var Uo = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M13.5353 10.5725C13.5353 9.47709 11.0456 9.99991 11.0456 7.85883C11.0456 6.46464 12.1162 5.61816 13.361 5.61816C14.805 5.61816 16 6.86298 16 8.92937C16 11.2945 14.4564 13.7841 11.1203 14.3816L10.8216 13.1368C12.888 12.4895 13.5353 11.4937 13.5353 10.5725ZM6.71369 10.5725C6.71369 9.47709 4.22407 9.99991 4.22407 7.85883C4.22407 6.46464 5.29461 5.61816 6.53942 5.61816C7.9834 5.61816 9.17842 6.86298 9.17842 8.92937C9.17842 11.2945 7.63485 13.7841 4.29876 14.3816L4 13.1368C6.06639 12.4895 6.71369 11.4937 6.71369 10.5725Z",
            fill: "currentColor"
        })
    });
;
;
var xt = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "currentColor",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M11.708 14.5H7.79785V13.9414H8.01367C9.00391 13.9414 9.15625 13.9033 9.15625 13.6113V6.70508H8.07715C6.82031 6.70508 6.73145 7.08594 6.28711 8.67285H5.80469L5.91895 6.12109H13.5869L13.7012 8.67285H13.2188C12.7744 7.08594 12.6855 6.70508 11.4287 6.70508H10.3496V13.6113C10.3496 13.9033 10.502 13.9414 11.4922 13.9414H11.708V14.5Z",
            fill: "currentColor"
        })
    });
var te = (t)=>({
        type: "dropdown",
        ChildComponent: xt,
        items: t,
        key: "text",
        order: 25
    });
;
var fn = {
    type: "element",
    dependencies: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuoteNode"]
    ],
    export: (t, e)=>{
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isQuoteNode"])(t)) return null;
        let o = e(t).split(`
`), r = [];
        for (let n of o)r.push("> " + n);
        return r.join(`
`);
    },
    regExp: /^>\s/,
    replace: (t, e, o, r)=>{
        if (r) {
            let l = t.getPreviousSibling();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isQuoteNode"])(l)) {
                l.splice(l.getChildrenSize(), 0, [
                    ...e
                ]), l.select(0, 0), t.remove();
                return;
            }
        }
        let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createQuoteNode"])();
        n.append(...e), t.replace(n), n.select(0, 0);
    }
};
var gn = [
    te([
        {
            ChildComponent: Uo,
            isActive: ({ selection: t })=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t)) return !1;
                for (let e of t.getNodes())if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isQuoteNode"])(e) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isQuoteNode"])(e.getParent())) return !1;
                return !0;
            },
            key: "blockquote",
            label: ({ i18n: t })=>t.t("lexical:blockquote:label"),
            onSelect: ({ editor: t })=>{
                t.update(()=>{
                    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$selection$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$setBlocksType"])(e, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createQuoteNode"])());
                });
            },
            order: 20
        }
    ])
], Uc = $({
    markdownTransformers: [
        fn
    ],
    nodes: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuoteNode"]
    ],
    slashMenu: {
        groups: [
            Z([
                {
                    Icon: Uo,
                    key: "blockquote",
                    keywords: [
                        "quote",
                        "blockquote"
                    ],
                    label: ({ i18n: t })=>t.t("lexical:blockquote:label"),
                    onSelect: ({ editor: t })=>{
                        t.update(()=>{
                            let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$selection$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$setBlocksType"])(e, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createQuoteNode"])());
                        });
                    }
                }
            ])
        ]
    },
    toolbarFixed: {
        groups: gn
    },
    toolbarInline: {
        groups: gn
    }
});
;
;
;
var Yt = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                height: "4",
                rx: "0.5",
                stroke: "currentColor",
                width: "4",
                x: "8",
                y: "5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                height: "4",
                rx: "0.5",
                stroke: "currentColor",
                width: "4",
                x: "5",
                y: "11"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                height: "4",
                rx: "0.5",
                stroke: "currentColor",
                width: "4",
                x: "11",
                y: "11"
            })
        ]
    });
;
;
var qt = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M5.33333 6.5C5.11232 6.5 4.90036 6.5878 4.74408 6.74408C4.5878 6.90036 4.5 7.11232 4.5 7.33333V12.1667C4.5 12.3877 4.5878 12.5996 4.74408 12.7559C4.90036 12.9122 5.11232 13 5.33333 13H14.6667C14.8877 13 15.0996 12.9122 15.2559 12.7559C15.4122 12.5996 15.5 12.3877 15.5 12.1667V11.6667C15.5 11.3905 15.7239 11.1667 16 11.1667C16.2761 11.1667 16.5 11.3905 16.5 11.6667V12.1667C16.5 12.6529 16.3068 13.1192 15.963 13.463C15.6192 13.8068 15.1529 14 14.6667 14H5.33333C4.8471 14 4.38079 13.8068 4.03697 13.463C3.69315 13.1192 3.5 12.6529 3.5 12.1667V7.33333C3.5 6.8471 3.69315 6.38079 4.03697 6.03697C4.38079 5.69315 4.8471 5.5 5.33333 5.5H10.3333C10.6095 5.5 10.8333 5.72386 10.8333 6C10.8333 6.27614 10.6095 6.5 10.3333 6.5H5.33333ZM13 6.5C12.7239 6.5 12.5 6.27614 12.5 6C12.5 5.72386 12.7239 5.5 13 5.5H16C16.2761 5.5 16.5 5.72386 16.5 6V9C16.5 9.27614 16.2761 9.5 16 9.5C15.7239 9.5 15.5 9.27614 15.5 9V7.20711L13.3536 9.35355C13.1583 9.54882 12.8417 9.54882 12.6464 9.35355C12.4512 9.15829 12.4512 8.84171 12.6464 8.64645L14.7929 6.5H13ZM6.16699 8.33325C6.16699 8.05711 6.39085 7.83325 6.66699 7.83325H11.0003C11.2765 7.83325 11.5003 8.05711 11.5003 8.33325C11.5003 8.60939 11.2765 8.83325 11.0003 8.83325H6.66699C6.39085 8.83325 6.16699 8.60939 6.16699 8.33325ZM6.16699 10.9999C6.16699 10.7238 6.39085 10.4999 6.66699 10.4999H13.3337C13.6098 10.4999 13.8337 10.7238 13.8337 10.9999C13.8337 11.2761 13.6098 11.4999 13.3337 11.4999H6.66699C6.39085 11.4999 6.16699 11.2761 6.16699 10.9999Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    });
;
;
function Qt(t, e) {
    return t ? ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("img", {
            alt: e ?? "Block Image",
            className: "lexical-block-custom-image",
            src: t,
            style: {
                maxHeight: 20,
                maxWidth: 20
            }
        }) : Yt;
}
;
;
function eo({ propsString: t }) {
    let e = {}, o = "", r = !0;
    for(let n = 0; n < t.length; n++){
        let l = t[n];
        if (r) l === "=" || l === " " ? o && (l === " " ? (e[o] = !0, o = "") : r = !1) : o += l;
        else {
            let i = Vc(t, n);
            e[o] = i.value, n = i.newIndex, o = "", r = !0;
        }
    }
    return o && (e[o] = !0), e;
}
function Vc(t, e) {
    let o = t[e];
    return o === '"' ? _n(t, e) : o === "'" ? _n(t, e, !0) : o === "{" ? Jc(t, e) : o === "[" ? Kc(t, e) : Xc(t, e);
}
function Kc(t, e) {
    let o = 1, r = "", n = e + 1;
    for(; n < t.length && o > 0;)t[n] === "[" ? o++ : t[n] === "]" && o--, o > 0 && (r += t[n]), n++;
    return {
        newIndex: n,
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsox$40$1$2e$2$2e$121$2f$node_modules$2f$jsox$2f$lib$2f$jsox$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JSOX"].parse(`[${r}]`)
    };
}
function _n(t, e, o = !1) {
    let r = "", n = e + 1;
    for(; n < t.length && (t[n] !== (o ? "'" : '"') || t[n - 1] === "\\");)r += t[n], n++;
    return {
        newIndex: n,
        value: r
    };
}
function Jc(t, e) {
    let o = 1, r = "", n = e + 1;
    for(; n < t.length && o > 0;)t[n] === "{" ? o++ : t[n] === "}" && o--, o > 0 && (r += t[n]), n++;
    return {
        newIndex: n,
        value: zc(r)
    };
}
function zc(t) {
    return t[0] !== "{" ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsox$40$1$2e$2$2e$121$2f$node_modules$2f$jsox$2f$lib$2f$jsox$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JSOX"].parse(t) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jsox$40$1$2e$2$2e$121$2f$node_modules$2f$jsox$2f$lib$2f$jsox$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JSOX"].parse(t.replace(/(\w+):/g, '"$1":'));
}
function Xc(t, e) {
    let o = "", r = e;
    for(; r < t.length && t[r] !== " ";)o += t[r], r++;
    return {
        newIndex: r - 1,
        value: o
    };
}
function Ct({ props: t }) {
    let e = [];
    for (let [o, r] of Object.entries(t))typeof r == "string" ? e.push(`${o}="${Zc(r)}"`) : typeof r == "number" ? e.push(`${o}={${r}}`) : typeof r == "boolean" ? r && e.push(`${o}`) : r !== null && typeof r == "object" && (Array.isArray(r) ? e.push(`${o}={[${r.map((n)=>JSON.stringify(n, Tn)).join(", ")}]}`) : e.push(`${o}={${JSON.stringify(r, Tn)}}`));
    return e.join(" ");
}
function Zc(t) {
    return t.replace(/"/g, "&quot;");
}
function Tn(t, e) {
    return typeof e == "string" ? e.replace(/'/g, "\\'") : e;
}
function to({ isEndOptional: t, lines: e, regexpEndRegex: o, startLineIndex: r, startMatch: n, trimChildren: l }) {
    let i = "", s = "", d = e.slice(r), c = !1, u = 0, a = 0, m = null, p = !1, f = 0, h = d[0].slice(0, n.index), x = 0, w = r;
    e: for (let [N, _] of d.entries()){
        let C = l ? _.trim() : _, g = 0;
        if (l) for(let k = 0; k < _.length && _[k] === " "; k++)g++;
        let b = 0;
        for(N === 0 && (b = (n.index ?? 0) + n[0].length - g); b < C.length;){
            let k = C[b], y = C[b + 1];
            if (c) {
                if (k === "`" && f++, f % 2 === 0) if (k === "<" && y === "/") {
                    if (u--, u < 0) {
                        s[s.length - 1] === `
` && (s = s.slice(0, -1)), w = N;
                        for(let R = b; R < C.length; R++)if (C[R] === ">") {
                            x = R + 1;
                            break;
                        }
                        break e;
                    }
                } else if (k === "/" && y === ">") {
                    if (u--, u < 0) {
                        s[s.length - 1] === `
` && (s = s.slice(0, -1)), w = N, x = b + 2;
                        break e;
                    }
                } else k === "<" && y !== "/" && u++;
                s += k;
            } else {
                if (k === "{" && !m ? a++ : k === "}" && !m ? a-- : (k === '"' || k === "'") && !m ? m = k : k === m && (m = null), k === "/" && y === ">" && a === 0 && !m) {
                    p = !0, w = N, x = b + 2;
                    break e;
                } else if (k === ">" && a === 0 && !m) {
                    c = !0, b++;
                    continue;
                }
                i += k;
            }
            b++;
        }
        if (c ? s?.length > 0 && N > 0 && (s += `
`) : i += `
`, o && u < 0) {
            let k = C.match(o);
            if (k?.index !== void 0) {
                w = N, x = k.index + k[0].length - 1;
                break;
            }
        }
        if (N === d.length - 1 && !t && !p) throw new Error("End match not found for lines " + e.join(`
`) + `

. Start match: ` + JSON.stringify(n));
    }
    return {
        afterEndLine: d[w].trim().slice(x),
        beforeStartLine: h,
        content: s,
        endLineIndex: r + w,
        endlineLastCharIndex: x,
        propsString: i
    };
}
;
;
;
;
;
;
;
;
var bt = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorBlockNode"] {
    __cacheBuster;
    __fields;
    constructor({ cacheBuster: e, fields: o, format: r, key: n }){
        super(r, n), this.__fields = o, this.__cacheBuster = e || 0;
    }
    static clone(e) {
        return new this({
            cacheBuster: e.__cacheBuster,
            fields: e.__fields,
            format: e.__format,
            key: e.__key
        });
    }
    static getType() {
        return "block";
    }
    static importDOM() {
        return {};
    }
    static importJSON(e) {
        e.version === 1 && (e = {
            ...e,
            fields: {
                ...e.fields.data
            },
            version: 2
        });
        let o = tu(e.fields);
        return o.setFormat(e.format), o;
    }
    static isInline() {
        return !1;
    }
    createDOM(e) {
        let o = document.createElement("div");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addClassNamesToElement"])(o, e?.theme?.block), o;
    }
    decorate(e, o) {
        return null;
    }
    exportDOM() {
        let e = document.createElement("div"), o = document.createTextNode(this.getTextContent());
        return e.append(o), {
            element: e
        };
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            type: "block",
            fields: this.getFields(),
            version: 2
        };
    }
    getCacheBuster() {
        return this.getLatest().__cacheBuster;
    }
    getFields() {
        return this.getLatest().__fields;
    }
    getTextContent() {
        return "Block Field";
    }
    setFields(e, o) {
        let r = this.getWritable();
        r.__fields = e, o || r.__cacheBuster++;
    }
};
function tu(t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new bt({
        fields: {
            ...t,
            id: t?.id || new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString()
        }
    }));
}
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var wn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    baseClass: "LexicalEditorTheme__block",
    BlockCollapsible: ()=>null,
    BlockDrawer: ()=>null,
    CustomBlock: null,
    EditButton: ()=>null,
    errorCount: 0,
    formSchema: [],
    initialState: !1,
    nodeKey: "",
    RemoveButton: ()=>null
}), Ce = ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].use(wn), En = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4), { Collapsible: o, ...r } = t, { BlockDrawer: n, CustomBlock: l, errorCount: i, formSchema: s } = r, c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFormSubmitted"])() && i > 0, u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), a;
    e[0] !== o || e[1] !== i || e[2] !== c ? (a = (p)=>{
        let { children: f, ...h } = p;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(o, {
            errorCount: i,
            fieldHasErrors: c,
            ...h,
            children: f
        });
    }, e[0] = o, e[1] = i, e[2] = c, e[3] = a) : a = e[3];
    let m = a;
    return l ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(wn, {
        value: {
            ...r,
            BlockCollapsible: m
        },
        children: [
            l,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(n, {})
        ]
    }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(m, {
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RenderFields"], {
            fields: s,
            forceRender: !0,
            parentIndexPath: "",
            parentPath: "",
            parentSchemaPath: "",
            permissions: !0,
            readOnly: !u
        })
    });
};
function Sn({ fields: t }) {
    for(let e in t){
        let o = t[e];
        Array.isArray(o?.rows) && "value" in o && (o.disableFormData = !0);
    }
    return t;
}
var In = (t)=>{
    let { cacheBuster: e, className: o, formData: r, nodeKey: n } = t, l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFormSubmitted"])(), { id: i, collectionSlug: s, globalSlug: d } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDocumentInfo"])(), { fieldProps: { featureClientSchemaMap: c, field: u, initialLexicalFormState: a, schemaPath: m }, uuid: p } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), { fields: f } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDocumentForm"])(), h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new AbortController), x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEditDepth"])(), [w, E] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(0), { config: N } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c__as__useConfig$3e$__["useConfig"])(), _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["formatDrawerSlug"])({
        slug: `lexical-blocks-create-${p}-${r.id}`,
        depth: x
    }), { toggleDrawer: C } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$INBEEENE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(_), { getDocPreferences: g, setDocFieldPreferences: b } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDocumentInfo"])(), [k] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), R = r.blockType, { getFormState: M } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useServerFunctions"])(), L = `${m}.lexical_internal_feature.blocks.lexical_blocks.${R}.fields`, [T, S] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        "In.useState": ()=>{
            let j = a?.[r.id]?.formState;
            if (!j) return !1;
            let ee = Object.fromEntries(Object.entries(j).map({
                "In.useState.ee": ([U, V])=>[
                        U,
                        U in r ? {
                            ...V,
                            initialValue: r[U],
                            value: r[U]
                        } : V
                    ]
            }["In.useState.ee"]));
            return ee.blockName = {
                initialValue: r.blockName,
                passesCondition: !0,
                valid: !0,
                value: r.blockName
            }, ee;
        }
    }["In.useState"]), I = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1), A = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(e);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        I.current ? (A.current !== e && S(!1), A.current = e) : I.current = !0;
    }, [
        e
    ]);
    let [v, O] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(T?._components?.customComponents?.BlockLabel ?? void 0), [D, G] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(T?._components?.customComponents?.Block ?? void 0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let j = new AbortController;
        return r && !T && (async ()=>{
            let { state: U } = await M({
                id: i,
                collectionSlug: s,
                data: r,
                docPermissions: {
                    fields: !0
                },
                docPreferences: await g(),
                documentFormState: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepCopyObjectSimpleWithoutReactComponents"])(f),
                globalSlug: d,
                initialBlockData: r,
                operation: "update",
                readOnly: !y,
                renderAllFields: !0,
                schemaPath: L,
                signal: j.signal
            });
            if (U) {
                U.blockName = {
                    initialValue: r.blockName,
                    passesCondition: !0,
                    valid: !0,
                    value: r.blockName
                };
                let V = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$reduceFieldsToValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduceFieldsToValues"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepCopyObjectSimpleWithoutReactComponents"])(U), !0);
                k.update(()=>{
                    let Q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(n);
                    if (Q && $e(Q)) {
                        let ne = V;
                        ne.blockType = R, Q.setFields(ne, !0);
                    }
                }), S(U), O(U._components?.customComponents?.BlockLabel ?? void 0), G(U._components?.customComponents?.Block ?? void 0);
            }
        })(), ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["abortAndIgnore"])(j);
        };
    }, [
        M,
        L,
        y,
        i,
        r,
        k,
        n,
        T,
        s,
        d,
        g,
        f,
        R
    ]);
    let [q, z] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(a?.[r.id]?.collapsed ?? !1), Ut = `${m}.lexical_internal_feature.blocks.lexical_blocks.${R}`, X = c.blocks?.[Ut]?.[0], W = X.blockReferences ? typeof X?.blockReferences?.[0] == "string" ? N.blocksMap[X?.blockReferences?.[0]] : X?.blockReferences?.[0] : X?.blocks?.[0], { i18n: Ge, t: ye } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__["useTranslation"])(), fe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(async ({ formState: j, submit: ee })=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["abortAndIgnore"])(h.current);
        let U = new AbortController;
        h.current = U;
        let { state: V } = await M({
            id: i,
            collectionSlug: s,
            docPermissions: {
                fields: !0
            },
            docPreferences: await g(),
            documentFormState: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepCopyObjectSimpleWithoutReactComponents"])(f),
            formState: j,
            globalSlug: d,
            initialBlockFormState: j,
            operation: "update",
            readOnly: !y,
            renderAllFields: !!ee,
            schemaPath: L,
            signal: U.signal
        });
        if (!V) return j;
        j.blockName && (V.blockName = j.blockName);
        let Q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$reduceFieldsToValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduceFieldsToValues"])(Sn({
            fields: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$deepCopyObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deepCopyObjectSimpleWithoutReactComponents"])(V)
        }), !0);
        if (setTimeout(()=>{
            k.update(()=>{
                let ne = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(n);
                if (ne && $e(ne)) {
                    let Ke = Q;
                    Ke.blockType = R, ne.setFields(Ke, !0);
                }
            });
        }, 0), ee) {
            O(V._components?.customComponents?.BlockLabel ?? void 0), G(V._components?.customComponents?.Block ?? void 0);
            let ne = 0;
            for (let Ke of Object.values(V))Ke?.valid === !1 && ne++;
            E(ne);
        }
        return V;
    }, [
        M,
        i,
        s,
        g,
        d,
        L,
        R,
        f,
        y,
        k,
        n
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["abortAndIgnore"])(h.current);
        }, []);
    let Gt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        k.update(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(n)?.remove();
        });
    }, [
        k,
        n
    ]), Re = W?.labels?.singular ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslation"])(W.labels.singular, Ge) : W?.slug, Vt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((j)=>{
        g().then((ee)=>{
            let V = ee?.fields?.[u.name]?.collapsed, Q = V && V?.length ? V : [];
            j ? Q.includes(r.id) || Q.push(r.id) : Q.includes(r.id) && Q.splice(Q.indexOf(r.id), 1), b(u.name, {
                collapsed: Q,
                hello: "hi"
            });
        });
    }, [
        g,
        u.name,
        b,
        r.id
    ]), Ve = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Button"], {
                buttonStyle: "icon-label",
                className: `${o}__editButton`,
                disabled: !y,
                el: "button",
                icon: "edit",
                onClick: (j)=>(j.preventDefault(), j.stopPropagation(), C(), !1),
                onMouseDown: (j)=>{
                    j.preventDefault();
                },
                round: !0,
                size: "small",
                tooltip: ye("lexical:blocks:inlineBlocks:edit", {
                    label: Re
                })
            }), [
        o,
        y,
        ye,
        Re,
        C
    ]), Kt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Button"], {
                buttonStyle: "icon-label",
                className: `${o}__removeButton`,
                disabled: !y,
                icon: "x",
                onClick: (j)=>{
                    j.preventDefault(), Gt();
                },
                round: !0,
                tooltip: "Remove Block"
            }), [
        o,
        y,
        Gt
    ]), Oo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({ Actions: j, children: ee, className: U, collapsibleProps: V, disableBlockName: Q, editButton: ne, errorCount: Ke, fieldHasErrors: Fo, Label: on, Pill: rn, removeButton: hc })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: `${o}__container ${o}-${R}`,
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Collapsible"], {
                    className: [
                        `${o}__row`,
                        Fo ? `${o}__row--has-errors` : `${o}__row--no-errors`,
                        U
                    ].filter(Boolean).join(" "),
                    collapsibleStyle: Fo ? "error" : "default",
                    header: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                        className: `${o}__block-header`,
                        children: [
                            typeof on < "u" ? on : typeof v < "u" ? v : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                                className: `${o}__block-label`,
                                children: [
                                    typeof rn < "u" ? rn : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Pill"], {
                                        className: `${o}__block-pill ${o}__block-pill-${R}`,
                                        pillStyle: "white",
                                        size: "small",
                                        children: Re ?? R
                                    }),
                                    !Q && !W?.admin?.disableBlockName && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["SectionTitle"], {
                                        path: "blockName",
                                        readOnly: !y
                                    }),
                                    Fo && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ErrorPill"], {
                                        count: Ke ?? 0,
                                        i18n: Ge,
                                        withMessage: !0
                                    })
                                ]
                            }),
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                                className: `${o}__block-actions`,
                                children: typeof j < "u" ? j : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        D && ne !== !1 || !D && ne ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ve, {}) : null,
                                        hc !== !1 && y ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Kt, {}) : null
                                    ]
                                })
                            })
                        ]
                    }),
                    isCollapsed: q,
                    onToggle: (nn)=>{
                        Vt(nn), z(nn);
                    },
                    ...V || {},
                    children: ee
                }, 0)
            }), [
        D,
        v,
        Ve,
        Kt,
        Re,
        o,
        W?.admin?.disableBlockName,
        R,
        Ge,
        q,
        Vt,
        y
    ]), en = r?.id, tn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["EditDepthProvider"], {
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Drawer"], {
                    className: "",
                    slug: _,
                    title: ye(`lexical:blocks:inlineBlocks:${en ? "edit" : "create"}`, {
                        label: Re ?? ye("lexical:blocks:inlineBlocks:label")
                    }),
                    children: T ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RenderFields"], {
                                fields: W?.fields ?? [],
                                forceRender: !0,
                                parentIndexPath: "",
                                parentPath: "",
                                parentSchemaPath: L,
                                permissions: !0,
                                readOnly: !y
                            }),
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FormSubmit"], {
                                programmaticSubmit: !0,
                                children: ye("fields:saveChanges")
                            })
                        ]
                    }) : null
                })
            }), [
        T,
        _,
        en,
        Re,
        ye,
        y,
        W?.fields,
        L
    ]), fc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>T ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Form"], {
            beforeSubmit: [
                async ({ formState: j })=>await fe({
                        formState: j,
                        submit: !0
                    })
            ],
            el: "div",
            fields: W?.fields ?? [],
            initialState: T,
            onChange: [
                fe
            ],
            onSubmit: (j, ee)=>{
                ee.blockType = R, k.update(()=>{
                    let U = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(n);
                    U && $e(U) && U.setFields(ee, !0);
                }), C();
            },
            submitted: l,
            uuid: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])(),
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(En, {
                baseClass: o,
                BlockDrawer: tn,
                Collapsible: Oo,
                CustomBlock: D,
                EditButton: Ve,
                errorCount: w,
                formSchema: W?.fields ?? [],
                initialState: T,
                nodeKey: n,
                RemoveButton: Kt
            })
        }) : null, [
        Oo,
        tn,
        D,
        R,
        Kt,
        Ve,
        o,
        k,
        w,
        C,
        W?.fields,
        T,
        n,
        fe,
        l
    ]);
    return W ? fc : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Oo, {
        disableBlockName: !0,
        fieldHasErrors: !0,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
            className: `${o}-not-found`,
            children: [
                "Error: Block '",
                R,
                "' not found in the config but exists in the lexical data"
            ]
        })
    });
};
var ie = class extends bt {
    static clone(e) {
        return super.clone(e);
    }
    static getType() {
        return super.getType();
    }
    static importJSON(e) {
        e.version === 1 && (e = {
            ...e,
            fields: {
                ...e.fields.data
            },
            version: 2
        });
        let o = Ae(e.fields);
        return o.setFormat(e.format), o;
    }
    decorate(e, o) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(In, {
            cacheBuster: this.getCacheBuster(),
            className: o.theme.block ?? "LexicalEditorTheme__block",
            formData: this.getFields(),
            nodeKey: this.getKey()
        });
    }
    exportJSON() {
        return super.exportJSON();
    }
};
function Ae(t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new ie({
        fields: {
            ...t,
            id: t?.id || new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString()
        }
    }));
}
function $e(t) {
    return t instanceof ie;
}
;
function Xo(t, e) {
    return ({ editorState: r })=>{
        let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$headless$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$headless$2f$LexicalHeadless$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createHeadlessEditor"])({
            nodes: t
        });
        try {
            n.setEditorState(n.parseEditorState(r));
        } catch (i) {
            console.error("getLexicalToMarkdown: ERROR parsing editor state", i);
        }
        let l = "";
        return n.getEditorState().read(()=>{
            l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(e);
        }), l;
    };
}
;
function lo(t, e) {
    return ({ markdown: r })=>{
        let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$headless$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$headless$2f$LexicalHeadless$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createHeadlessEditor"])({
            nodes: t
        });
        return n.update(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(r, e);
        }, {
            discrete: !0
        }), n.getEditorState().toJSON();
    };
}
function $u(t) {
    let e = t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return {
        regExpEnd: new RegExp(`</(${e})\\s*>|<${e}[^>]*?/>`, "i"),
        regExpStart: new RegExp(`<(${e})([^>]*?)\\s*(/?)>`, "i")
    };
}
var Dn = ({ blocks: t, inlineBlocks: e })=>{
    if (!t?.length && !e?.length) return [];
    let o = [];
    if (t?.length) for (let r of t){
        let n = Mn(r, !1);
        n && (o = o.concat(n));
    }
    if (e?.length) for (let r of e){
        let n = Mn(r, !0);
        n && (o = o.concat(n));
    }
    return o;
};
function Mn(t, e) {
    if (!t.jsx) return null;
    let o = $u(t.slug), r = [];
    return e ? (r.push(({ allNodes: n, allTransformers: l })=>({
            type: "text-match",
            dependencies: [
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"]
            ],
            export: (i)=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["e"])(i) || i.getFields()?.blockType?.toLowerCase() !== t.slug.toLowerCase()) return null;
                let s = i.getFields(), d = Xo(n, l), c = t.jsx.export({
                    fields: s,
                    lexicalToMarkdown: d
                });
                if (c === !1) return null;
                if (typeof c == "string") return c;
                let u = c.props && Object.keys(c.props)?.length > 0, a = c.props ?? {};
                return c?.children?.length ? `<${s.blockType}${u ? " " + Ct({
                    props: a
                }) : ""}>${c.children}</${s.blockType}>` : `<${s.blockType}${u ? " " + Ct({
                    props: a
                }) : ""}/>`;
            },
            getEndIndex: (i, s)=>{
                let { endlineLastCharIndex: d } = to({
                    isEndOptional: !1,
                    lines: [
                        i.getTextContent()
                    ],
                    regexpEndRegex: o.regExpEnd,
                    startLineIndex: 0,
                    startMatch: s,
                    trimChildren: !1
                });
                return d;
            },
            importRegExp: t.jsx?.customStartRegex ?? o.regExpStart,
            regExp: /___ignoreignoreignore___/g,
            replace (i, s) {
                let { content: d, propsString: c } = to({
                    isEndOptional: !1,
                    lines: [
                        i.getTextContent()
                    ],
                    regexpEndRegex: o.regExpEnd,
                    startLineIndex: 0,
                    startMatch: {
                        ...s,
                        index: 0
                    },
                    trimChildren: !1
                });
                if (!t?.jsx?.import) return;
                let u = lo(n, l), a = t.jsx.import({
                    children: d,
                    closeMatch: null,
                    htmlToLexical: null,
                    markdownToLexical: u,
                    openMatch: s,
                    props: c ? eo({
                        propsString: c
                    }) : {}
                });
                if (a === !1) return;
                let m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])({
                    blockType: t.slug,
                    ...a
                });
                i.replace(m);
            }
        })), r) : (r.push(({ allNodes: n, allTransformers: l })=>({
            dependencies: [
                ie
            ],
            export: (i)=>{
                if (!$e(i) || i.getFields()?.blockType?.toLowerCase() !== t.slug.toLowerCase()) return null;
                let s = i.getFields(), d = Xo(n, l), c = t.jsx.export({
                    fields: s,
                    lexicalToMarkdown: d
                });
                if (c === !1) return null;
                if (typeof c == "string") return c;
                let u = c.props && Object.keys(c.props)?.length > 0, a = c.props ?? {};
                if (c?.children?.length) {
                    let m = c.children, p = "";
                    if (m.includes(`
`)) for (let f of m.split(`
`)){
                        let h = "";
                        !t?.jsx?.doNotTrimChildren && f !== "" && (h = "  "), h += f + `
`, p += h;
                    }
                    else p = (t?.jsx?.doNotTrimChildren ? "" : "  ") + m + `
`;
                    return `<${s.blockType}${u ? " " + Ct({
                        props: a
                    }) : ""}>
${p}</${s.blockType}>`;
                }
                return `<${s.blockType}${u ? " " + Ct({
                    props: a
                }) : ""}/>`;
            },
            handleImportAfterStartMatch: t.jsx?.customEndRegex ? void 0 : ({ lines: i, rootNode: s, startLineIndex: d, startMatch: c, transformer: u })=>{
                let a = typeof u.regExpEnd == "object" && "regExp" in u.regExpEnd ? u.regExpEnd.regExp : u.regExpEnd, m = u.regExpEnd && typeof u.regExpEnd == "object" && "optional" in u.regExpEnd ? u.regExpEnd.optional : !u.regExpEnd, { afterEndLine: p, beforeStartLine: f, content: h, endLineIndex: x, propsString: w } = to({
                    isEndOptional: m,
                    lines: i,
                    regexpEndRegex: a,
                    startLineIndex: d,
                    startMatch: c,
                    trimChildren: !1
                }), E = "";
                if (t?.jsx?.doNotTrimChildren) E = h.endsWith(`
`) ? h.slice(0, -1) : h;
                else if (h.includes(`
`)) {
                    let g = h.split(`
`), b = 0;
                    for (let k of g){
                        if (b++, k.startsWith("  ")) E += k.slice(2);
                        else if (k === "") E += k;
                        else {
                            E = h.endsWith(`
`) ? h.slice(0, -1) : h;
                            break;
                        }
                        E += b === g.length ? "" : `
`;
                    }
                } else E = (h.startsWith("  ") ? h.slice(2) : h) + `
`;
                if (!t?.jsx?.import) return [
                    !1,
                    d
                ];
                let N = lo(n, l), _ = t.jsx.import({
                    children: E,
                    closeMatch: null,
                    htmlToLexical: null,
                    markdownToLexical: N,
                    openMatch: c,
                    props: w ? eo({
                        propsString: w
                    }) : {}
                });
                if (_ === !1) return [
                    !1,
                    d
                ];
                let C = Ae({
                    blockType: t.slug,
                    ..._
                });
                if (C) {
                    let g = null, b = null;
                    if (f?.length) {
                        g = N({
                            markdown: f
                        })?.root?.children ?? [];
                        let k = g?.[0];
                        k && s.append((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$parseSerializedNode"])(k));
                    }
                    if (s.append(C), p?.length) {
                        b = N({
                            markdown: p
                        })?.root?.children;
                        let k = s.getChildren()[s.getChildren().length - 1], y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$parseSerializedNode"])(b[0])?.getChildren();
                        if (y?.length) for (let R of y)k.append(R);
                    }
                }
                return [
                    !0,
                    x
                ];
            },
            regExpEnd: t.jsx?.customEndRegex ?? o.regExpEnd,
            regExpStart: t.jsx?.customStartRegex ?? o.regExpStart,
            type: "multiline-element",
            replace: (i, s, d, c, u)=>{
                if (t?.jsx?.import) {
                    if (!u) {
                        let x = "";
                        if (s) for (let w of s)x += w.getTextContent();
                        u = [
                            x
                        ];
                    }
                    let a = "";
                    t?.jsx?.doNotTrimChildren ? a = u.join(`
`) : a = u.join(`
`).trim();
                    let m = d[1]?.trim(), p = lo(n, l), f = t.jsx.import({
                        children: a,
                        closeMatch: c,
                        htmlToLexical: null,
                        markdownToLexical: p,
                        openMatch: d,
                        props: m ? eo({
                            propsString: m
                        }) : {}
                    });
                    if (f === !1) return !1;
                    let h = Ae({
                        blockType: t.slug,
                        ...f
                    });
                    h && i.append(h);
                    return;
                }
                return !1;
            }
        })), r);
}
;
var Xe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("INSERT_BLOCK_COMMAND"), Ze = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("INSERT_INLINE_BLOCK_COMMAND");
;
;
;
;
;
;
var On = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12), [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), [o, r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), { setCreatedInlineBlock: n, uuid: l } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEditDepth"])(), s = "lexical-inlineBlocks-create-" + l, d;
    t[0] !== i || t[1] !== s ? (d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["formatDrawerSlug"])({
        slug: s,
        depth: i
    }), t[0] = i, t[1] = s, t[2] = d) : d = t[2];
    let c = d, { toggleDrawer: u } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$INBEEENE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(c, !0), a;
    t[3] !== e || t[4] !== n || t[5] !== o ? (a = ()=>{
        if (!e.hasNodes([
            ie
        ])) throw new Error("BlocksPlugin: BlocksNode not registered on editor");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(e.registerCommand(Xe, (p)=>(e.update(()=>{
                let f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])() || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getPreviousSelection"])();
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(f)) {
                    let h = Ae(p), { focus: x } = f, w = x.getNode();
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(h), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isParagraphNode"])(w) && !w.__first && w.remove();
                }
            }), !0), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), e.registerCommand(Ze, (p)=>{
            if (o) {
                let h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(o);
                return !h || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["e"])(h) ? !1 : (h.setFields(p), r(null), !0);
            }
            let f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(p);
            return n?.(f), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$insertNodes"])([
                f
            ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRootOrShadowRoot"])(f.getParentOrThrow()) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$wrapNodeInElement"])(f, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"]).selectEnd(), !0;
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]));
    }, t[3] = e, t[4] = n, t[5] = o, t[6] = a) : a = t[6];
    let m;
    return t[7] !== e || t[8] !== n || t[9] !== o || t[10] !== u ? (m = [
        e,
        n,
        o,
        u
    ], t[7] = e, t[8] = n, t[9] = o, t[10] = u, t[11] = m) : m = t[11], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(a, m), null;
};
var qu = $(({ config: t, featureClientSchemaMap: e, props: o, schemaPath: r })=>{
    let n = `${r}.lexical_internal_feature.blocks.lexical_blocks`, l = `${r}.lexical_internal_feature.blocks.lexical_inline_blocks`, i = e.blocks;
    if (!i) return {};
    let s = Object.entries(i).filter(([a])=>a.startsWith(n + ".") && !a.replace(n + ".", "").includes(".")).map(([, a])=>a[0]), d = Object.entries(i).filter(([a])=>a.startsWith(l + ".") && !a.replace(l + ".", "").includes(".")).map(([, a])=>a[0]), c = s.map((a)=>a.blockReferences ? typeof a.blockReferences[0] == "string" ? t.blocksMap[a.blockReferences[0]] : a.blockReferences[0] : a.blocks[0]).filter((a)=>a !== void 0), u = d.map((a)=>a.blockReferences ? typeof a.blockReferences[0] == "string" ? t.blocksMap[a.blockReferences[0]] : a.blockReferences[0] : a.blocks[0]).filter((a)=>a !== void 0);
    return {
        markdownTransformers: Dn({
            blocks: c,
            inlineBlocks: u
        }),
        nodes: [
            ie,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"]
        ],
        plugins: [
            {
                Component: On,
                position: "normal"
            }
        ],
        sanitizedClientFeatureProps: o,
        slashMenu: {
            groups: [
                c?.length ? {
                    items: c.map((a)=>({
                            Icon: Qt(a.imageURL, a.imageAltText),
                            key: "block-" + a.slug,
                            keywords: [
                                "block",
                                "blocks",
                                a.slug
                            ],
                            label: ({ i18n: m })=>a?.labels?.singular ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslation"])(a.labels.singular, m) : a?.slug,
                            onSelect: ({ editor: m })=>{
                                m.dispatchCommand(Xe, {
                                    blockName: "",
                                    blockType: a.slug
                                });
                            }
                        })),
                    key: "blocks",
                    label: ({ i18n: a })=>a.t("lexical:blocks:label")
                } : null,
                u?.length ? {
                    items: u.map((a)=>({
                            Icon: qt,
                            key: "inlineBlocks-" + a.slug,
                            keywords: [
                                "inlineBlock",
                                "inline block",
                                a.slug
                            ],
                            label: ({ i18n: m })=>a?.labels?.singular ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslation"])(a.labels.singular, m) : a?.slug,
                            onSelect: ({ editor: m })=>{
                                m.dispatchCommand(Ze, {
                                    blockName: "",
                                    blockType: a.slug
                                });
                            }
                        })),
                    key: "inlineBlocks",
                    label: ({ i18n: a })=>a.t("lexical:blocks:inlineBlocks:label")
                } : null
            ].filter(Boolean)
        },
        toolbarFixed: {
            groups: [
                c.length ? {
                    type: "dropdown",
                    ChildComponent: Yt,
                    items: c.map((a, m)=>({
                            ChildComponent: Qt(a.imageURL, a.imageAltText),
                            isActive: void 0,
                            key: "block-" + a.slug,
                            label: ({ i18n: p })=>a?.labels?.singular ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslation"])(a.labels.singular, p) : a?.slug,
                            onSelect: ({ editor: p })=>{
                                p.dispatchCommand(Xe, {
                                    blockName: "",
                                    blockType: a.slug
                                });
                            },
                            order: m
                        })),
                    key: "blocks",
                    order: 20
                } : null,
                u?.length ? {
                    type: "dropdown",
                    ChildComponent: qt,
                    items: u.map((a, m)=>({
                            ChildComponent: a.imageURL ? Qt(a.imageURL, a.imageAltText) : qt,
                            isActive: void 0,
                            key: "inlineBlock-" + a.slug,
                            label: ({ i18n: p })=>a?.labels?.singular ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslation"])(a.labels.singular, p) : a?.slug,
                            onSelect: ({ editor: p })=>{
                                p.dispatchCommand(Ze, {
                                    blockName: "",
                                    blockType: a.slug
                                });
                            },
                            order: m
                        })),
                    key: "inlineBlocks",
                    order: 25
                } : null
            ].filter(Boolean)
        }
    };
});
;
;
;
;
;
;
var Qu = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"] && "documentMode" in document ? document.documentMode : null, Fn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"] && /Mac|iPod|iPhone|iPad/.test(navigator.platform), z5 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"] && /^(?!.*Seamonkey)(?=.*Firefox).*/i.test(navigator.userAgent), X5 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"] && "InputEvent" in window && !Qu ? "getTargetRanges" in new window.InputEvent("input") : !1, Z5 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"] && /Version\/[\d.].*Safari/.test(navigator.userAgent), Y5 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"] && /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream, q5 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"] && /Android/.test(navigator.userAgent), Q5 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"] && /Win/.test(navigator.platform), ed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"] && /^(?=.*Chrome).*/i.test(navigator.userAgent), e6 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"] && /AppleWebKit\/[\d.]+/.test(navigator.userAgent) && !ed;
var id = (t)=>{
    let e = document.createElement("textarea");
    e.value = t || "", e.style.position = "absolute", e.style.opacity = "0", document.body?.appendChild(e), e.focus(), e.select();
    try {
        let o = document.execCommand("copy");
        console.log(o);
    } catch (o) {
        console.error(o);
    }
    document.body?.removeChild(e);
}, sd = (t, e)=>{
    let o = document.createElement("a");
    o.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(e || "")), o.setAttribute("download", t), o.style.display = "none", document.body?.appendChild(o), o.click(), document.body?.removeChild(o);
}, ad = (t)=>{
    let o = ((r, n)=>{
        switch(r){
            case "click":
                return `      await page.mouse.click(${n.x}, ${n.y});`;
            case "keydown":
                return `      await page.keyboard.keydown('${n}');`;
            case "keyup":
                return `      await page.keyboard.keyup('${n}');`;
            case "press":
                return `      await page.keyboard.press('${n}');`;
            case "selectAll":
                return "      await selectAll(page);";
            case "snapshot":
                return `      await assertHTMLSnapshot(page);
      await assertSelection(page, {
        anchorPath: [${n.anchorPath.toString()}],
        anchorOffset: ${n.anchorOffset},
        focusPath: [${n.focusPath.toString()}],
        focusOffset: ${n.focusOffset},
      });
`;
            case "type":
                return `      await page.keyboard.type('${n}');`;
            default:
                return "";
        }
    })(t.name, t.value);
    switch(t.count){
        case 1:
            return o;
        case 2:
            return [
                o,
                o
            ].join(`
`);
        default:
            return `      await repeat(${t.count}, async () => {
  ${o}
      );`;
    }
};
function cd(t) {
    return t.key.toLowerCase() === "a" && (Fn ? t.metaKey : t.ctrlKey);
}
function ud(t) {
    let { anchorNode: e, focusNode: o } = t, { anchorOffset: r, focusOffset: n } = t;
    return r !== 0 && r--, n !== 0 && n--, {
        anchorNode: e,
        anchorOffset: r,
        focusNode: o,
        focusOffset: n
    };
}
function Bn(t, e) {
    let o = t, r = [];
    for(; o !== e;)o != null && r.unshift(Array.from(o?.parentNode?.childNodes ?? []).indexOf(o)), o = o?.parentNode;
    return r;
}
var jn = new Set([
    "ArrowDown",
    "ArrowLeft",
    "ArrowRight",
    "ArrowUp",
    "Backspace",
    "Delete",
    "Enter",
    "Escape"
]);
function dd(t) {
    let [e, o] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]), [r, n] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [, l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(""), [i, s] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(""), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>t, [
        t
    ]), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        let _ = t.getRootElement(), C = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDOMSelection"])(t._window);
        return _ == null || C == null || C.anchorNode == null || C.focusNode == null || !_.contains(C.anchorNode) || !_.contains(C.focusNode) ? null : `
import {
  initializeE2E,
  assertHTMLSnapshot,
  assertSelection,
  repeat,
} from '../utils';
import {selectAll} from '../keyboardShortcuts';
import { RangeSelection } from 'lexical';
import { NodeSelection } from 'lexical';

describe('Test case', () => {
  initializeE2E((e2e) => {
    it('Should pass this test', async () => {
      const {page} = e2e;

      await page.focus('div[contenteditable="true"]');
${e.map(ad).join(`
`)}
    });
});
    `;
    }, [
        t,
        e
    ]), p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((_, C)=>{
        o((g)=>{
            let b = e.length - 1, k = e[b];
            if (k && k.name === _) {
                if (_ === "type") return [
                    ...e.slice(0, b),
                    {
                        ...k,
                        value: k.value + C
                    }
                ];
                if (k.value === C) return [
                    ...e.slice(0, b),
                    {
                        ...k,
                        count: k.count + 1
                    }
                ];
            }
            return [
                ...g,
                {
                    name: _,
                    count: 1,
                    value: C
                }
            ];
        });
    }, [
        e,
        o
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])(()=>{
        let _ = (g)=>{
            if (!r) return;
            let b = g.key;
            cd(g) ? p("selectAll", "") : jn.has(b) ? p("press", g.key) : [
                ...b
            ].length > 1 ? p("keydown", g.key) : p("type", g.key);
        }, C = (g)=>{
            if (!r) return;
            let b = g.key;
            !jn.has(b) && [
                ...b
            ].length > 1 && p("keyup", g.key);
        };
        return t.registerRootListener((g, b)=>{
            b !== null && (b.removeEventListener("keydown", _), b.removeEventListener("keyup", C)), g !== null && (g.addEventListener("keydown", _), g.addEventListener("keyup", C));
        });
    }, [
        t,
        r,
        p
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])(()=>{
        u.current && u.current.scrollTo(0, u.current.scrollHeight);
    }, [
        m
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (e) {
            let _ = m();
            _ !== null && s(_), u.current && u.current.scrollTo(0, u.current.scrollHeight);
        }
    }, [
        m,
        e
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>t.registerUpdateListener(({ dirtyElements: C, dirtyLeaves: g, editorState: b })=>{
            if (!r) return;
            let k = b._selection, y = d.current, R = c.current;
            if (y !== k) {
                if (g.size === 0 && C.size === 0 && !R) {
                    let L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDOMSelection"])(t._window);
                    if (L && (L.anchorNode == null || L.focusNode == null)) return;
                }
                d.current = k;
            }
            c.current = !1;
            let M = m();
            M !== null && s(M);
        }), [
        t,
        m,
        r,
        p
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>r ? t.registerUpdateListener(()=>{
            let C = t.getRootElement();
            C !== null && l(C?.innerHTML);
        }) : void 0, [
        t,
        r
    ]);
    let f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((_)=>{
        r || (_.update(()=>{
            let C = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])();
            C.clear();
            let g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])();
            C.append((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])().append(g)), g.select();
        }), o([])), n((C)=>!C);
    }, [
        r
    ]), h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if (!r) return;
        let _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDOMSelection"])(t._window);
        if (_ === null || _.anchorNode == null || _.focusNode == null) return;
        let { anchorNode: C, anchorOffset: g, focusNode: b, focusOffset: k } = ud(_), y = a().getRootElement(), R;
        C !== null && (R = Bn(C, y));
        let M;
        b !== null && (M = Bn(b, y)), p("snapshot", {
            anchorNode: C,
            anchorOffset: g,
            anchorPath: R,
            focusNode: b,
            focusOffset: k,
            focusPath: M
        });
    }, [
        p,
        r,
        a
    ]), x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        id(m());
    }, [
        m
    ]), w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        sd("test.js", m());
    }, [
        m
    ]);
    return [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
            className: `editor-dev-button ${r ? "active" : ""}`,
            id: "test-recorder-button",
            onClick: (_)=>{
                f(a()), _.preventDefault();
            },
            title: r ? "Disable test recorder" : "Enable test recorder",
            type: "button",
            children: r ? "Disable test recorder" : "Enable test recorder"
        }),
        r ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
            className: "test-recorder-output",
            children: [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    className: "test-recorder-toolbar",
                    children: [
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                            className: "test-recorder-button",
                            id: "test-recorder-button-snapshot",
                            onClick: (_)=>{
                                h(), _.preventDefault();
                            },
                            title: "Insert snapshot",
                            type: "button",
                            children: "Insert Snapshot"
                        }),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                            className: "test-recorder-button",
                            id: "test-recorder-button-copy",
                            onClick: (_)=>{
                                x(), _.preventDefault();
                            },
                            title: "Copy to clipboard",
                            type: "button",
                            children: "Copy"
                        }),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                            className: "test-recorder-button",
                            id: "test-recorder-button-download",
                            onClick: (_)=>{
                                w(), _.preventDefault();
                            },
                            title: "Download as a file",
                            type: "button",
                            children: "Download"
                        })
                    ]
                }),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("pre", {
                    id: "test-recorder",
                    ref: u,
                    children: i
                })
            ]
        }) : null
    ];
}
var Un = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3), [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), [o, r] = dd(e), n;
    return t[0] !== o || t[1] !== r ? (n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", {
                children: "HI"
            }),
            o,
            r,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", {
                children: "DONE"
            })
        ]
    }), t[0] = o, t[1] = r, t[2] = n) : n = t[2], n;
};
var md = $({
    plugins: [
        {
            Component: Un,
            position: "bottom"
        }
    ]
});
;
;
;
;
;
var Wn = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), o;
    return t[0] !== e ? (o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalTreeView$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TreeView"], {
        editor: e,
        timeTravelButtonClassName: "debug-timetravel-button",
        timeTravelPanelButtonClassName: "debug-timetravel-panel-button",
        timeTravelPanelClassName: "debug-timetravel-panel",
        timeTravelPanelSliderClassName: "debug-timetravel-panel-slider",
        treeTypeButtonClassName: "debug-treetype-button",
        viewClassName: "tree-view-output"
    }), t[0] = e, t[1] = o) : o = t[1], o;
};
var xd = $({
    plugins: [
        {
            Component: Wn,
            position: "bottom"
        }
    ]
});
;
;
;
;
var Vn = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "currentColor",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M10.6772 15H6.27017V5.718H10.4172C12.6792 5.718 13.8492 6.602 13.8492 8.292C13.8492 9.098 13.1992 9.982 12.4712 10.216C13.3812 10.476 14.1742 11.256 14.1742 12.322C14.1742 14.09 12.9002 15 10.6772 15ZM8.46717 9.501H10.3262C11.3012 9.501 11.7042 9.046 11.7042 8.409C11.7042 7.72 11.2362 7.317 10.3392 7.317H8.46717V9.501ZM8.46717 11.061V13.401H10.4822C11.4702 13.401 11.9642 12.959 11.9642 12.218C11.9642 11.49 11.4702 11.061 10.4822 11.061H8.46717Z",
            fill: "currentColor"
        })
    });
var Y = (t)=>({
        type: "buttons",
        items: t,
        key: "format",
        order: 40
    });
var Kn = {
    type: "text-format",
    format: [
        "bold",
        "italic"
    ],
    tag: "***"
}, Jn = {
    type: "text-format",
    format: [
        "bold",
        "italic"
    ],
    intraword: !1,
    tag: "___"
}, zn = {
    type: "text-format",
    format: [
        "bold"
    ],
    tag: "**"
}, Xn = {
    type: "text-format",
    format: [
        "bold"
    ],
    intraword: !1,
    tag: "__"
};
var Zn = [
    Y([
        {
            ChildComponent: Vn,
            isActive: ({ selection: t })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(t) ? t.hasFormat("bold") : !1,
            key: "bold",
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_TEXT_COMMAND"], "bold");
            },
            order: 1
        }
    ])
], _d = $(({ featureProviderMap: t })=>{
    let e = [
        zn,
        Xn
    ];
    return t.get("italic") && e.push(Jn, Kn), {
        enableFormats: [
            "bold"
        ],
        markdownTransformers: e,
        toolbarFixed: {
            groups: Zn
        },
        toolbarInline: {
            groups: Zn
        }
    };
});
;
;
;
;
var qn = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M7.76465 6L3.76465 10L7.76465 14",
                stroke: "currentColor"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M12.2354 6L16.2354 10L12.2354 14",
                stroke: "currentColor"
            })
        ]
    });
var Qn = {
    type: "text-format",
    format: [
        "code"
    ],
    tag: "`"
};
var el = [
    Y([
        {
            ChildComponent: qn,
            isActive: ({ selection: t })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(t) ? t.hasFormat("code") : !1,
            key: "inlineCode",
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_TEXT_COMMAND"], "code");
            },
            order: 7
        }
    ])
], Nd = $({
    enableFormats: [
        "code"
    ],
    markdownTransformers: [
        Qn
    ],
    toolbarFixed: {
        groups: el
    },
    toolbarInline: {
        groups: el
    }
});
;
;
;
;
var ol = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "currentColor",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M11.311 14.2969L11.0327 15H6.18408L6.4624 14.2969C7.54639 14.2969 7.70752 14.209 7.83936 13.8721L10.8423 6.45996C10.8716 6.38672 10.8862 6.32812 10.8862 6.26953C10.8862 6.09375 10.6519 6.03516 9.80225 6.03516L10.0952 5.33203H14.9438L14.6509 6.03516C13.5669 6.03516 13.4204 6.12305 13.2886 6.45996L10.2856 13.8721C10.2563 13.9453 10.2271 14.0039 10.2271 14.0625C10.2271 14.2383 10.4614 14.2969 11.311 14.2969Z",
            fill: "currentColor"
        })
    });
var rl = {
    type: "text-format",
    format: [
        "italic"
    ],
    tag: "*"
}, nl = {
    type: "text-format",
    format: [
        "italic"
    ],
    intraword: !1,
    tag: "_"
};
var ll = [
    Y([
        {
            ChildComponent: ol,
            isActive: ({ selection: t })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(t) ? t.hasFormat("italic") : !1,
            key: "italic",
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_TEXT_COMMAND"], "italic");
            },
            order: 2
        }
    ])
], Id = $({
    enableFormats: [
        "italic"
    ],
    markdownTransformers: [
        rl,
        nl
    ],
    toolbarFixed: {
        groups: ll
    },
    toolbarInline: {
        groups: ll
    }
});
;
;
;
;
var sl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "currentColor",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M5.50756 12.76H7.42756C7.56256 14.215 8.82256 14.71 10.1576 14.71C11.4326 14.71 12.4226 14.14 12.4226 13.06C12.4226 12.28 11.9576 11.845 10.6676 11.605L8.70256 11.245C7.12756 10.96 5.85256 10.21 5.85256 8.335C5.85256 6.43 7.53256 5.11 9.87256 5.11C12.4226 5.11 13.9526 6.22 14.1626 8.23H12.2876C12.1526 7.18 11.2226 6.595 9.88756 6.595C8.59756 6.595 7.78756 7.27 7.78756 8.215C7.78756 9.1 8.34256 9.385 9.49756 9.61L11.5676 10.015C13.3226 10.345 14.3726 11.215 14.3726 12.94C14.3726 14.89 12.5876 16.18 10.2176 16.18C7.66756 16.18 5.70256 15.115 5.50756 12.76Z",
                fill: "currentColor"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M4.99756 11.44H15.0026V12.19H4.99756V11.44Z",
                fill: "currentColor"
            })
        ]
    });
var al = {
    type: "text-format",
    format: [
        "strikethrough"
    ],
    tag: "~~"
};
var cl = [
    Y([
        {
            ChildComponent: sl,
            isActive: ({ selection: t })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(t) ? t.hasFormat("strikethrough") : !1,
            key: "strikethrough",
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_TEXT_COMMAND"], "strikethrough");
            },
            order: 4
        }
    ])
], Ad = $({
    enableFormats: [
        "strikethrough"
    ],
    markdownTransformers: [
        al
    ],
    toolbarFixed: {
        groups: cl
    },
    toolbarInline: {
        groups: cl
    }
});
;
;
;
;
var dl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "currentColor",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M10.167 15L7.45002 11.36L4.73302 15H2.91302L6.55302 10.177L3.23802 5.718H5.20102L7.54102 8.89L9.89402 5.718H11.714L8.43802 10.06L12.13 15H10.167ZM16.7768 13.258C16.7768 14.155 16.1398 14.532 15.2038 15C14.5538 15.325 14.2808 15.546 14.2418 15.78H16.7898V16.82H12.7208V16.339C12.7208 15.286 13.5918 14.675 14.3588 14.233C15.0868 13.83 15.4378 13.635 15.4378 13.232C15.4378 12.894 15.2038 12.686 14.8268 12.686C14.3848 12.686 14.1248 13.024 14.1118 13.427H12.7468C12.8248 12.426 13.5528 11.633 14.8398 11.633C15.9448 11.633 16.7768 12.257 16.7768 13.258Z",
            fill: "currentColor"
        })
    });
var ml = [
    Y([
        {
            ChildComponent: dl,
            isActive: ({ selection: t })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(t) ? t.hasFormat("subscript") : !1,
            key: "subscript",
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_TEXT_COMMAND"], "subscript");
            },
            order: 5
        }
    ])
], Bd = $({
    enableFormats: [
        "subscript"
    ],
    toolbarFixed: {
        groups: ml
    },
    toolbarInline: {
        groups: ml
    }
});
;
;
;
;
var fl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "currentColor",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M10.167 15L7.45002 11.36L4.73302 15H2.91302L6.55302 10.177L3.23802 5.718H5.20102L7.54102 8.89L9.89402 5.718H11.714L8.43802 10.06L12.13 15H10.167ZM16.7768 7.252C16.7768 8.149 16.1398 8.526 15.2038 8.994C14.5538 9.319 14.2808 9.54 14.2418 9.774H16.7898V10.814H12.7208V10.333C12.7208 9.28 13.5918 8.669 14.3588 8.227C15.0868 7.824 15.4378 7.629 15.4378 7.226C15.4378 6.888 15.2038 6.68 14.8268 6.68C14.3848 6.68 14.1248 7.018 14.1118 7.421H12.7468C12.8248 6.42 13.5528 5.627 14.8398 5.627C15.9448 5.627 16.7768 6.251 16.7768 7.252Z",
            fill: "currentColor"
        })
    });
var hl = [
    Y([
        {
            ChildComponent: fl,
            isActive: ({ selection: t })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(t) ? t.hasFormat("superscript") : !1,
            key: "superscript",
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_TEXT_COMMAND"], "superscript");
            },
            order: 6
        }
    ])
], Wd = $({
    enableFormats: [
        "superscript"
    ],
    toolbarFixed: {
        groups: hl
    },
    toolbarInline: {
        groups: hl
    }
});
;
;
;
;
var xl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "currentColor",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M13.9656 11.256C13.9656 13.791 12.5096 15.156 10.0006 15.156C7.50461 15.156 6.03561 13.791 6.03561 11.23V5.718H7.76461V11.243C7.76461 12.868 8.50561 13.778 10.0006 13.778C11.4956 13.778 12.2496 12.868 12.2496 11.243V5.718H13.9656V11.256Z",
                fill: "currentColor"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M5.09961 16.3H14.9016V16.95H5.09961V16.3Z",
                fill: "currentColor"
            })
        ]
    });
var Cl = [
    Y([
        {
            ChildComponent: xl,
            isActive: ({ selection: t })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(t) ? t.hasFormat("underline") : !1,
            key: "underline",
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FORMAT_TEXT_COMMAND"], "underline");
            },
            order: 3
        }
    ])
], zd = $({
    enableFormats: [
        "underline"
    ],
    toolbarFixed: {
        groups: Cl
    },
    toolbarInline: {
        groups: Cl
    }
});
;
;
function Zd(t) {
    return t.replace(/-([a-z])/g, (e, o)=>o.toUpperCase());
}
var ao = ({ css: t })=>{
    let e = t ? Object.fromEntries(Object.entries(t).map(([o, r])=>[
            Zd(o),
            r
        ])) : {};
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
        style: {
            ...e,
            alignItems: "center",
            borderRadius: "4px",
            display: "flex",
            fontSize: "16px",
            height: "20px",
            justifyContent: "center",
            width: "20px"
        },
        children: "A"
    });
};
;
;
;
;
function bl(t) {
    let e = new Map;
    for(let o in t){
        let r = t[o], n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createState"])(o, {
            parse: (l)=>typeof l == "string" && Object.keys(r).includes(l) ? l : void 0
        });
        e.set(o, {
            stateConfig: n,
            stateValues: r
        });
    }
    return e;
}
function er(t, e, o, r) {
    t.update(()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$selection$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$forEachSelectedTextNode"])((n)=>{
            let l = e.get(o);
            if (!l) throw new Error(`State config for ${o} not found`);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$setState"])(n, l.stateConfig, r);
        });
    });
}
function kl({ stateMap: t }) {
    let [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>e.registerMutationListener(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextNode"], (o)=>{
            e.getEditorState().read(()=>{
                for (let [r, n] of o){
                    if (n === "destroyed") continue;
                    let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(r), i = e.getElementByKey(r);
                    if (!l || !i) continue;
                    let s = Object.create(null);
                    t.forEach((d, c)=>{
                        let u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getState"])(l, d.stateConfig);
                        if (!u) {
                            delete i.dataset[c];
                            return;
                        }
                        i.dataset[c] = u;
                        let a = d.stateValues[u]?.css;
                        a && Object.assign(s, a);
                    }), i.style.cssText = "", Object.assign(i.style, s);
                }
            });
        }), [
        e
    ]), null;
}
var _l = (t, e)=>{
    let o = [];
    for(let n in t.state){
        let l = t.state[n];
        for(let i in l){
            let s = l[i];
            o.push({
                ChildComponent: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ao, {
                        css: s.css
                    }),
                key: i,
                label: s.label,
                onSelect: ({ editor: d })=>{
                    er(d, e, n, i);
                }
            });
        }
    }
    return [
        {
            type: "dropdown",
            ChildComponent: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ao, {
                    css: {
                        color: "var(--theme-elevation-600)"
                    }
                }),
            items: [
                ...[
                    {
                        ChildComponent: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ao, {}),
                        key: "clear-style",
                        label: ({ i18n: n })=>n.t("lexical:textState:defaultStyle"),
                        onSelect: ({ editor: n })=>{
                            for(let l in t.state)er(n, e, l, void 0);
                        },
                        order: 1
                    }
                ],
                ...o
            ],
            key: "textState",
            order: 30
        }
    ];
}, lm = $(({ props: t })=>{
    let e = bl(t.state);
    return {
        plugins: [
            {
                Component: ()=>kl({
                        stateMap: e
                    }),
                position: "normal"
            }
        ],
        toolbarFixed: {
            groups: _l(t, e)
        },
        toolbarInline: {
            groups: _l(t, e)
        }
    };
});
;
;
;
;
;
;
;
;
var wl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M4.639 13.5V7.074H6.196V9.648H9.076V7.074H10.642V13.5H9.076V10.836H6.196V13.5H4.639ZM11.5656 9.045V8.019C12.6636 8.019 13.1316 7.731 13.2846 7.065H14.4006V13.5H12.8436V9.045H11.5656Z",
            fill: "currentColor"
        })
    });
;
;
var Sl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M4.139 13.5V7.074H5.696V9.648H8.576V7.074H10.142V13.5H8.576V10.836H5.696V13.5H4.139ZM15.9796 8.973C15.9796 10.116 15.1696 10.656 14.0356 11.232C13.2256 11.646 12.8206 11.943 12.7846 12.294H15.9886V13.5H11.0566V12.951C11.0566 11.601 12.1636 10.845 13.1176 10.287C14.0356 9.756 14.5126 9.486 14.5126 8.946C14.5126 8.46 14.2156 8.145 13.6306 8.145C13.0186 8.145 12.6586 8.613 12.6226 9.198H11.1196C11.2186 7.947 12.1006 6.966 13.6396 6.966C15.0346 6.966 15.9796 7.785 15.9796 8.973Z",
            fill: "currentColor"
        })
    });
;
;
var Ll = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M4.139 13.5V7.074H5.696V9.648H8.576V7.074H10.142V13.5H8.576V10.836H5.696V13.5H4.139ZM16.1146 11.745C16.1146 12.744 15.2236 13.608 13.6126 13.608C12.0736 13.608 11.0926 12.762 10.9846 11.547H12.4696C12.5146 12.114 13.0006 12.456 13.6126 12.456C14.2876 12.456 14.6746 12.132 14.6746 11.619C14.6746 11.061 14.2426 10.836 13.6216 10.836H12.9826V9.738H13.6036C14.1526 9.738 14.5486 9.486 14.5486 8.937C14.5486 8.46 14.2156 8.127 13.6486 8.127C13.0366 8.127 12.6586 8.514 12.6226 9.045H11.1916C11.2726 7.929 12.1276 6.966 13.6666 6.966C15.1876 6.966 15.9706 7.848 15.9706 8.865C15.9706 9.603 15.5026 10.143 14.8186 10.269C15.6196 10.404 16.1146 10.971 16.1146 11.745Z",
            fill: "currentColor"
        })
    });
;
;
var Rl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M3.639 13.5V7.074H5.196V9.648H8.076V7.074H9.642V13.5H8.076V10.836H5.196V13.5H3.639ZM15.1736 7.074V10.854H16.3706V12.033H15.1736V13.5H13.6796V12.033H10.5116V10.845L13.4996 7.074H15.1736ZM13.6796 8.46L11.8256 10.854H13.6796V8.46Z",
            fill: "currentColor"
        })
    });
;
;
var vl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M3.639 13.5V7.074H5.196V9.648H8.076V7.074H9.642V13.5H8.076V10.836H5.196V13.5H3.639ZM13.1576 10.269C12.6896 10.269 12.3746 10.494 12.2216 10.737H10.8176L11.1956 7.074H15.2546V8.28H12.3206L12.1856 9.549C12.4016 9.351 12.8516 9.126 13.4636 9.126C14.7866 9.126 15.6596 10.053 15.6596 11.358C15.6596 12.609 14.7326 13.608 13.1756 13.608C11.5826 13.608 10.6556 12.753 10.5566 11.511H12.1136C12.1586 12.06 12.5456 12.465 13.1576 12.465C13.8236 12.465 14.1746 11.97 14.1746 11.376C14.1746 10.764 13.8416 10.269 13.1576 10.269Z",
            fill: "currentColor"
        })
    });
;
;
var Dl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M3.639 13.5V7.074H5.196V9.648H8.076V7.074H9.642V13.5H8.076V10.836H5.196V13.5H3.639ZM13.3646 8.127C12.5456 8.127 12.0416 8.937 12.0416 9.999C12.3296 9.54 12.8246 9.207 13.5536 9.207C14.8586 9.207 15.8036 10.134 15.8036 11.376C15.8036 12.645 14.8226 13.608 13.3196 13.608C11.7266 13.608 10.6196 12.393 10.6196 10.395C10.6196 8.316 11.7716 6.966 13.4186 6.966C14.7056 6.966 15.5786 7.749 15.7316 8.829H14.3186C14.2016 8.415 13.9226 8.127 13.3646 8.127ZM13.3106 12.51C13.9586 12.51 14.3816 12.042 14.3816 11.385C14.3816 10.737 13.9586 10.278 13.3106 10.278C12.6536 10.278 12.2126 10.737 12.2126 11.385C12.2126 12.042 12.6536 12.51 13.3106 12.51Z",
            fill: "currentColor"
        })
    });
;
var or = (t)=>(e, o, r)=>{
        let n = t(r);
        n && (n.append(...o), e.replace(n), n.select(0, 0));
    };
var $l = (t)=>{
    let o = `^(${t.map((n)=>Number(n.slice(1))).map((n)=>`#{${n}}`).join("|")})\\s`, r = new RegExp(o);
    return {
        type: "element",
        dependencies: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeadingNode"]
        ],
        export: (n, l)=>{
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isHeadingNode"])(n)) return null;
            let i = Number(n.getTag().slice(1));
            return "#".repeat(i) + " " + l(n);
        },
        regExp: r,
        replace: or((n)=>{
            let l = "h" + n[1]?.length;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createHeadingNode"])(l);
        })
    };
};
var Ol = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$selection$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$setBlocksType"])(e, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createHeadingNode"])(t));
}, Fl = {
    h1: wl,
    h2: Sl,
    h3: Ll,
    h4: Rl,
    h5: vl,
    h6: Dl
}, gm = $(({ props: t })=>{
    let { enabledHeadingSizes: e = [
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6"
    ] } = t, o = [
        te(e.map((r, n)=>({
                ChildComponent: Fl[r],
                isActive: ({ selection: l })=>{
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(l)) return !1;
                    for (let i of l.getNodes()){
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isHeadingNode"])(i) && i.getTag() === r) continue;
                        let s = i.getParent();
                        if (!((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isHeadingNode"])(s) && s.getTag() === r)) return !1;
                    }
                    return !0;
                },
                key: r,
                label: ({ i18n: l })=>l.t("lexical:heading:label", {
                        headingLevel: r.charAt(1)
                    }),
                onSelect: ({ editor: l })=>{
                    l.update(()=>{
                        Ol(r);
                    });
                },
                order: n + 2
            })))
    ];
    return {
        markdownTransformers: [
            $l(e)
        ],
        nodes: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeadingNode"]
        ],
        plugins: [
            {
                Component: xm,
                position: "normal"
            }
        ],
        sanitizedClientFeatureProps: t,
        slashMenu: {
            groups: e?.length ? [
                Z(e.map((r)=>({
                        Icon: Fl[r],
                        key: `heading-${r.charAt(1)}`,
                        keywords: [
                            "heading",
                            r
                        ],
                        label: ({ i18n: n })=>n.t("lexical:heading:label", {
                                headingLevel: r.charAt(1)
                            }),
                        onSelect: ({ editor: n })=>{
                            n.update(()=>{
                                Ol(r);
                            });
                        }
                    })))
            ] : []
        },
        toolbarFixed: {
            groups: e?.length ? o : []
        },
        toolbarInline: {
            groups: e?.length ? o : []
        }
    };
}), xm = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9), { clientProps: o } = t, { enabledHeadingSizes: r } = o, n;
    e[0] !== r ? (n = r === void 0 ? [
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6"
    ] : r, e[0] = r, e[1] = n) : n = e[1];
    let l = n, i;
    e[2] !== l ? (i = l.at(-1), e[2] = l, e[3] = i) : i = e[3];
    let s = i, [d] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), c, u;
    return e[4] !== d || e[5] !== l || e[6] !== s ? (c = ()=>{
        if (!(!s || l.length === 6)) return d.registerNodeTransform(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$rich$2d$text$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$rich$2d$text$2f$LexicalRichText$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeadingNode"], (a)=>{
            l.includes(a.getTag()) || a.setTag(s);
        });
    }, u = [
        d,
        l,
        s
    ], e[4] = d, e[5] = l, e[6] = s, e[7] = c, e[8] = u) : (c = e[7], u = e[8]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(c, u), null;
};
;
;
;
var rr = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
            fill: "currentColor",
            height: "1",
            width: "12",
            x: "4",
            y: "9.5"
        })
    });
;
;
var Hl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        fill: "none",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M5 10h10",
                stroke: "currentColor"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M10 15V5",
                stroke: "currentColor"
            })
        ]
    });
var be = (t)=>({
        type: "dropdown",
        ChildComponent: Hl,
        items: t,
        key: "add",
        order: 10
    });
;
;
var Et = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("INSERT_HORIZONTAL_RULE_COMMAND"), wt = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    static clone(e) {
        return new this(e.__key);
    }
    static getType() {
        return "horizontalrule";
    }
    static importDOM() {
        return {
            hr: ()=>({
                    conversion: wm,
                    priority: 0
                })
        };
    }
    static importJSON(e) {
        return Ul();
    }
    createDOM(e) {
        let o = document.createElement("hr");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addClassNamesToElement"])(o, e.theme.hr), o;
    }
    decorate() {
        return null;
    }
    exportDOM() {
        return {
            element: document.createElement("hr")
        };
    }
    exportJSON() {
        return {
            type: "horizontalrule",
            version: 1
        };
    }
    getTextContent() {
        return `
`;
    }
    isInline() {
        return !1;
    }
    updateDOM() {
        return !1;
    }
};
function wm() {
    return {
        node: Ul()
    };
}
function Ul() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new wt);
}
;
;
var ke = class extends wt {
    static clone(e) {
        return super.clone(e);
    }
    static getType() {
        return super.getType();
    }
    static importJSON(e) {
        return Ye();
    }
    decorate() {
        return null;
    }
    exportJSON() {
        return super.exportJSON();
    }
};
function Ye() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new ke);
}
function St(t) {
    return t instanceof ke;
}
var Wl = {
    type: "element",
    dependencies: [
        ke
    ],
    export: (t, e)=>St(t) ? "---" : null,
    regExp: /^---\s*$/,
    replace: (t)=>{
        let e = Ye();
        e && t.replace(e);
    }
};
;
;
;
;
;
var Gl = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3), [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), o, r;
    return t[0] !== e ? (o = ()=>e.registerCommand(Et, Mm, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), r = [
        e
    ], t[0] = e, t[1] = o, t[2] = r) : (o = t[1], r = t[2]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(o, r), null;
};
function Mm(t) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(e)) return !1;
    if (e.focus.getNode() !== null) {
        let r = Ye();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(r);
    }
    return !0;
}
var $m = $({
    markdownTransformers: [
        Wl
    ],
    nodes: [
        ke
    ],
    plugins: [
        {
            Component: Gl,
            position: "normal"
        }
    ],
    slashMenu: {
        groups: [
            Z([
                {
                    Icon: rr,
                    key: "horizontalRule",
                    keywords: [
                        "hr",
                        "horizontal rule",
                        "line",
                        "separator"
                    ],
                    label: ({ i18n: t })=>t.t("lexical:horizontalRule:label"),
                    onSelect: ({ editor: t })=>{
                        t.dispatchCommand(Et, void 0);
                    }
                }
            ])
        ]
    },
    toolbarFixed: {
        groups: [
            be([
                {
                    ChildComponent: rr,
                    isActive: ({ selection: t })=>{
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])(t) || !t.getNodes().length) return !1;
                        let e = t.getNodes()[0];
                        return St(e);
                    },
                    key: "horizontalRule",
                    label: ({ i18n: t })=>t.t("lexical:horizontalRule:label"),
                    onSelect: ({ editor: t })=>{
                        t.dispatchCommand(Et, void 0);
                    }
                }
            ])
        ]
    }
});
;
;
;
;
var Vl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 5H10.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 10H10.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.5 15H17.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M12.25 7.25L17.25 3.75V10.75L12.25 7.25Z",
                fill: "currentColor"
            })
        ]
    });
;
;
var Kl = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M17.5 5H9.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M17.5 10H9.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M17.5 15H2.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M7.75 7.25L2.75 3.75V10.75L7.75 7.25Z",
                fill: "currentColor"
            })
        ]
    });
;
;
;
;
;
;
var ql = ({ clientProps: t })=>{
    let [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), { disabledNodes: o, disableTabNode: r } = t;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!(!e || !o?.length)) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INDENT_CONTENT_COMMAND"], ()=>Km((n)=>{
                if (!o.includes(n.getType())) {
                    let l = n.getIndent();
                    n.setIndent(l + 1);
                }
            }), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), e.registerUpdateListener(({ dirtyElements: n, editorState: l })=>{
            e.update(()=>{
                for (let [i] of n){
                    let s = l._nodeMap.get(i);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(s) && o.includes(s.getType()) && s.getIndent() > 0 && s.setIndent(0);
                }
            });
        }));
    }, [
        e,
        o
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!(!e || !r)) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_TAB_COMMAND"], (n)=>(n.preventDefault(), e.dispatchCommand(n.shiftKey ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OUTDENT_CONTENT_COMMAND"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INDENT_CONTENT_COMMAND"], void 0)), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), e.registerNodeTransform(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabNode"], (n)=>{
            n.remove();
        }));
    }, [
        e,
        r
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalTabIndentationPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabIndentationPlugin"], {});
};
function Km(t) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(e)) return !1;
    let o = new Set, r = e.getNodes();
    for(let n = 0; n < r.length; n++){
        let l = r[n], i = l.getKey();
        if (o.has(i)) continue;
        let s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$findMatchingParent"])(l, (c)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(c) && !c.isInline());
        if (s === null) continue;
        let d = s.getKey();
        s.canIndent() && !o.has(d) && (o.add(d), t(s));
    }
    return o.size > 0;
}
var Ql = (t)=>({
        type: "buttons",
        items: t,
        key: "indent",
        order: 35
    });
var ti = ({ disabledNodes: t })=>[
        Ql([
            {
                ChildComponent: Vl,
                isActive: ()=>!1,
                isEnabled: ({ selection: e })=>{
                    let o = e?.getNodes() ?? [], r = (n)=>oi(n) && n.getIndent() > 0;
                    return o.some((n)=>r(n) || !!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$findMatchingParent"])(n, r));
                },
                key: "indentDecrease",
                label: ({ i18n: e })=>e.t("lexical:indent:decreaseLabel"),
                onSelect: ({ editor: e })=>{
                    e.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OUTDENT_CONTENT_COMMAND"], void 0);
                },
                order: 1
            },
            {
                ChildComponent: Kl,
                isActive: ()=>!1,
                isEnabled: ({ selection: e })=>{
                    let o = e?.getNodes() ?? [], r = (n)=>oi(n) && !(t ?? []).includes(n.getType());
                    return o.some((n)=>r(n) || !!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$findMatchingParent"])(n, r));
                },
                key: "indentIncrease",
                label: ({ i18n: e })=>e.t("lexical:indent:increaseLabel"),
                onSelect: ({ editor: e })=>{
                    e.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INDENT_CONTENT_COMMAND"], void 0);
                },
                order: 2
            }
        ])
    ], Zm = $(({ props: t })=>{
    let e = t.disabledNodes ?? [];
    return {
        plugins: [
            {
                Component: ql,
                position: "normal"
            }
        ],
        sanitizedClientFeatureProps: t,
        toolbarFixed: {
            groups: ti({
                disabledNodes: e
            })
        },
        toolbarInline: {
            groups: ti({
                disabledNodes: e
            })
        }
    };
}), oi = (t)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(t) && t.canIndent();
;
;
;
;
var ni = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M8.5 11.5L11.5 8.5M8.5 7L9.625 5.875C10.868 4.633 12.882 4.633 14.125 5.875C15.368 7.118 15.368 9.133 14.125 10.375L13 11.5M7 8.5L5.746 9.754C4.56 10.94 4.519 12.85 5.652 14.087C6.814 15.354 8.78 15.449 10.058 14.298L11.5 13",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round"
        })
    });
;
function qe(t) {
    let { anchor: e } = t, { focus: o } = t, r = t.anchor.getNode(), n = t.focus.getNode();
    return r === n ? r : t.isBackward() ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$selection$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isAtNodeEnd"])(o) ? r : n : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$selection$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isAtNodeEnd"])(e) ? r : n;
}
var nr = (t)=>({
        type: "buttons",
        items: t,
        key: "features",
        order: 50
    });
;
;
;
;
var rp = new Set([
    "http:",
    "https:",
    "mailto:",
    "sms:",
    "tel:"
]), oe = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementNode"] {
    __fields;
    __id;
    constructor({ id: e, fields: o = {
        linkType: "custom",
        newTab: !1
    }, key: r }){
        super(r), this.__fields = o, this.__id = e;
    }
    static clone(e) {
        return new this({
            id: e.__id,
            fields: e.__fields,
            key: e.__key
        });
    }
    static getType() {
        return "link";
    }
    static importDOM() {
        return {
            a: (e)=>({
                    conversion: np,
                    priority: 1
                })
        };
    }
    static importJSON(e) {
        let o = _e({}).updateFromJSON(e);
        return e.version === 1 && typeof e.fields?.doc?.value == "object" && e.fields?.doc?.value?.id && (e.fields.doc.value = e.fields.doc.value.id, e.version = 2), e.version === 2 && !e.id && (e.id = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString(), e.version = 3), o;
    }
    canBeEmpty() {
        return !1;
    }
    canInsertTextAfter() {
        return !1;
    }
    canInsertTextBefore() {
        return !1;
    }
    createDOM(e) {
        let o = document.createElement("a");
        return this.__fields?.linkType === "custom" && (o.href = this.sanitizeUrl(this.__fields.url ?? "")), (this.__fields?.newTab ?? !1) && (o.target = "_blank"), this.__fields?.newTab === !0 && this.__fields?.linkType === "custom" && (o.rel = lr(o.rel, "add", "noopener")), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addClassNamesToElement"])(o, e.theme.link), o;
    }
    exportJSON() {
        let e = this.getFields();
        e?.linkType === "internal" ? delete e.url : e?.linkType === "custom" && delete e.doc;
        let o = {
            ...super.exportJSON(),
            type: "link",
            fields: e,
            version: 3
        }, r = this.getID();
        return r && (o.id = r), o;
    }
    extractWithChild(e, o, r) {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(o)) return !1;
        let n = o.anchor.getNode(), l = o.focus.getNode();
        return this.isParentOf(n) && this.isParentOf(l) && o.getTextContent().length > 0;
    }
    getFields() {
        return this.getLatest().__fields;
    }
    getID() {
        return this.getLatest().__id;
    }
    insertNewAfter(e, o = !0) {
        let r = this.getParentOrThrow().insertNewAfter(e, o);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(r)) {
            let n = _e({
                fields: this.__fields
            });
            return r.append(n), n;
        }
        return null;
    }
    isInline() {
        return !0;
    }
    sanitizeUrl(e) {
        try {
            let o = new URL(e);
            if (!rp.has(o.protocol)) return "about:blank";
        } catch  {
            return "https://";
        }
        return e;
    }
    setFields(e) {
        let o = this.getWritable();
        return o.__fields = e, o;
    }
    setID(e) {
        let o = this.getWritable();
        return o.__id = e, o;
    }
    updateDOM(e, o, r) {
        let n = this.__fields?.url, l = this.__fields?.newTab;
        return n != null && n !== e.__fields?.url && this.__fields?.linkType === "custom" && (o.href = n), this.__fields?.linkType === "internal" && e.__fields?.linkType === "custom" && o.removeAttribute("href"), o.rel == null && (o.rel = ""), l !== e.__fields?.newTab && (l ?? !1 ? (o.target = "_blank", this.__fields?.linkType === "custom" && (o.rel = lr(o.rel, "add", "noopener"))) : (o.removeAttribute("target"), o.rel = lr(o.rel, "remove", "noopener"))), !1;
    }
    updateFromJSON(e) {
        return super.updateFromJSON(e).setFields(e.fields).setID(e.id);
    }
};
function np(t) {
    let e = null;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLAnchorElement"])(t)) {
        let o = t.textContent;
        o !== null && o !== "" && (e = _e({
            id: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString(),
            fields: {
                doc: null,
                linkType: "custom",
                newTab: t.getAttribute("target") === "_blank",
                url: t.getAttribute("href") ?? ""
            }
        }));
    }
    return {
        node: e
    };
}
function _e({ id: t, fields: e }) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new oe({
        id: t ?? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString(),
        fields: e
    }));
}
function J(t) {
    return t instanceof oe;
}
var ue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("TOGGLE_LINK_COMMAND");
function ar(t) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(e) && (t === null || !t.selectedNodes?.length)) return;
    let o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(e) ? e.extract() : t === null ? [] : t.selectedNodes;
    if (t === null) {
        o?.forEach((l)=>{
            let i = l.getParent();
            J(i) && (i.getChildren().forEach((d)=>{
                i.insertBefore(d);
            }), i.remove());
        });
        return;
    }
    if (o?.length === 1) {
        let l = o[0], i = J(l) ? l : lp(l);
        if (i !== null) {
            i.setFields(t.fields), t.text != null && t.text !== i.getTextContent() && (i.append((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(t.text)), i.getChildren().forEach((s)=>{
                s !== i.getLastChild() && s.remove();
            }));
            return;
        }
    }
    let r = null, n = null;
    o?.forEach((l)=>{
        let i = l.getParent();
        if (!(i === n || i === null || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(l) && !l.isInline())) {
            if (J(i)) {
                n = i, i.setFields(t.fields), t.text != null && t.text !== i.getTextContent() && (i.append((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(t.text)), i.getChildren().forEach((s)=>{
                    s !== i.getLastChild() && s.remove();
                }));
                return;
            }
            if (i.is(r) || (r = i, n = _e({
                fields: t.fields
            }), J(i) ? l.getPreviousSibling() === null ? i.insertBefore(n) : i.insertAfter(n) : l.insertBefore(n)), J(l)) {
                if (l.is(n)) return;
                if (n !== null) {
                    let s = l.getChildren();
                    n.append(...s);
                }
                l.remove();
                return;
            }
            n !== null && n.append(l);
        }
    });
}
function lp(t) {
    return ip(t, (e)=>J(e));
}
function ip(t, e) {
    let o = t;
    for(; o !== null && (o = o.getParent(), !(o === null || e(o))););
    return o;
}
function lr(t, e, o) {
    let r, n = `${t}`;
    if (e === "add") {
        if (n.includes(o)) {
            let l = new RegExp(o, "g");
            n = n.replace(l, "").trim();
        }
        n = n.trim(), r = n.length === 0 ? `${o}` : `${n} ${o}`;
    } else {
        let l = new RegExp(o, "g");
        r = n.replace(l, "").trim();
    }
    return r;
}
var ai = {
    type: "text-match",
    dependencies: [
        oe
    ],
    export: (t, e)=>{
        if (!J(t)) return null;
        let o = t, { url: r } = o.getFields();
        return `[${e(o)}](${r})`;
    },
    importRegExp: /\[([^[]+)\]\(([^()\s]+)(?:\s"((?:[^"]*\\")*[^"]*)"\s*)?\)/,
    regExp: /\[([^[]+)\]\(([^()\s]+)(?:\s"((?:[^"]*\\")*[^"]*)"\s*)?\)$/,
    replace: (t, e)=>{
        let [, o, r] = e, n = _e({
            fields: {
                doc: null,
                linkType: "custom",
                newTab: !1,
                url: r
            }
        }), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(o);
        return l.setFormat(t.getFormat()), n.append(l), t.replace(n), l;
    },
    trigger: ")"
};
;
var Te = class extends oe {
    static clone(e) {
        return new this({
            id: "",
            fields: e.__fields,
            key: e.__key
        });
    }
    static getType() {
        return "autolink";
    }
    static importDOM() {
        return null;
    }
    static importJSON(e) {
        let o = Nt({}).updateFromJSON(e);
        return e.version === 1 && typeof e.fields?.doc?.value == "object" && e.fields?.doc?.value?.id && (e.fields.doc.value = e.fields.doc.value.id, e.version = 2), o;
    }
    exportJSON() {
        let e = super.exportJSON();
        return {
            type: "autolink",
            children: e.children,
            direction: e.direction,
            fields: e.fields,
            format: e.format,
            indent: e.indent,
            version: 2
        };
    }
    insertNewAfter(e, o = !0) {
        let r = this.getParentOrThrow().insertNewAfter(e, o);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(r)) {
            let n = Nt({
                fields: this.__fields
            });
            return r.append(n), n;
        }
        return null;
    }
    updateFromJSON(e) {
        return super.updateFromJSON(e).setFields(e.fields);
    }
};
function Nt({ fields: t }) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new Te({
        id: "",
        fields: t
    }));
}
function we(t) {
    return t instanceof Te;
}
;
;
;
;
;
function ui(t, e = (o)=>o) {
    return (o)=>{
        let r = t.exec(o);
        return r === null ? null : {
            index: r.index,
            length: r[0].length,
            text: r[0],
            url: e(r[0])
        };
    };
}
function pi(t, e) {
    for (let o of e){
        let r = o(t);
        if (r != null) return r;
    }
    return null;
}
var Cp = /[.,;\s]/;
function po(t) {
    return t !== void 0 && Cp.test(t);
}
function fi(t) {
    return po(t[t.length - 1]);
}
function ur(t) {
    return po(t[0]);
}
function bp(t, e) {
    return e ? /^\.[a-z]{2,}/i.test(t) : /^\.[a-z0-9]+/i.test(t);
}
function hi(t) {
    let e = t.getPreviousSibling();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(e) && (e = e.getLastDescendant()), e === null || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isLineBreakNode"])(e) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(e) && fi(e.getTextContent());
}
function gi(t) {
    let e = t.getNextSibling();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(e) && (e = e.getFirstDescendant()), e === null || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isLineBreakNode"])(e) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(e) && ur(e.getTextContent());
}
function kp(t, e, o, r) {
    return (t > 0 ? po(o[t - 1]) : hi(r[0])) ? e < o.length ? po(o[e]) : gi(r[r.length - 1]) : !1;
}
function _p(t, e, o) {
    let r = [], n = [], l = [], i = 0, s = 0, d = [
        ...t
    ];
    for(; d.length > 0;){
        let c = d[0], a = c.getTextContent().length, m = s;
        s + a <= e ? (r.push(c), i += a) : m >= o ? l.push(c) : n.push(c), s += a, d.shift();
    }
    return [
        i,
        r,
        n,
        l
    ];
}
function Tp(t, e, o, r) {
    let n = {
        linkType: "custom",
        url: r.url,
        ...r.fields
    }, l = Nt({
        fields: n
    });
    if (t.length === 1) {
        let i = t[0], s;
        if (e === 0 ? [s] = i.splitText(o) : [, s] = i.splitText(e, o), s) {
            let d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(r.text);
            d.setFormat(s.getFormat()), d.setDetail(s.getDetail()), d.setStyle(s.getStyle()), l.append(d), s.replace(l);
        }
        return i;
    } else if (t.length > 1) {
        let i = t[0], s = i.getTextContent().length, d;
        e === 0 ? d = i : [, d] = i.splitText(e);
        let c = [], u;
        if (t.forEach((a)=>{
            let p = a.getTextContent().length, f = s, h = s + p;
            if (f < o) if (h <= o) c.push(a);
            else {
                let [x, w] = a.splitText(o - f);
                x && c.push(x), u = w;
            }
            s += p;
        }), d) {
            let a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])(), m = a ? a.getNodes().find(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"]) : void 0, p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTextNode"])(d.getTextContent());
            return p.setFormat(d.getFormat()), p.setDetail(d.getDetail()), p.setStyle(d.getStyle()), l.append(p, ...c), m && m === d && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(a) ? p.select(a.anchor.offset, a.focus.offset) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])(a) && p.select(0, p.getTextContent().length)), d.replace(l), u;
        }
    }
}
function wp(t, e, o) {
    let r = [
        ...t
    ], n = r.map((d)=>d.getTextContent()).join(""), l = n, i, s = 0;
    for(; (i = pi(l, e)) != null && i !== null;){
        let d = i.index, c = i.length, u = d + c;
        if (kp(s + d, s + u, n, r)) {
            let [m, , p, f] = _p(r, s + d, s + u), h = s + d - m, x = s + u - m, w = Tp(p, h, x, i);
            r = w ? [
                w,
                ...f
            ] : f, o(i.url, null), s = 0;
        } else s += u;
        l = l.substring(u);
    }
}
function cr(t, e, o) {
    let r = t.getChildren(), n = r.length;
    for(let d = 0; d < n; d++){
        let c = r[d];
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(c) || !c.isSimpleText()) {
            mo(t), o(null, t.getFields()?.url ?? null);
            return;
        }
    }
    let l = t.getTextContent(), i = pi(l, e);
    if (i === null || i.text !== l) {
        mo(t), o(null, t.getFields()?.url ?? null);
        return;
    }
    if (!hi(t) || !gi(t)) {
        mo(t), o(null, t.getFields()?.url ?? null);
        return;
    }
    let s = t.getFields()?.url;
    if (s !== i?.url) {
        let d = t.getFields();
        d.url = i?.url, t.setFields(d), o(i.url, s ?? null);
    }
}
function Ep(t, e, o) {
    let r = t.getPreviousSibling(), n = t.getNextSibling(), l = t.getTextContent();
    if (we(r)) {
        let i = r.getFields()?.url ? r.getFields()?.url?.startsWith("mailto:") ?? !1 : !1;
        (!ur(l) || bp(l, i)) && (r.append(t), cr(r, e, o), o(null, r.getFields()?.url ?? null));
    }
    we(n) && !fi(l) && (mo(n), cr(n, e, o), o(null, n.getFields()?.url ?? null));
}
function mo(t) {
    let e = t.getChildren(), o = e.length;
    for(let r = o - 1; r >= 0; r--)t.insertAfter(e[r]);
    return t.remove(), e.map((r)=>r.getLatest());
}
function Sp(t) {
    let e = [
        t
    ], o = t.getNextSibling();
    for(; o !== null && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(o) && o.isSimpleText() && (e.push(o), !/\s/.test(o.getTextContent()));)o = o.getNextSibling();
    return e;
}
function Np(t, e, o) {
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5), n, l;
    r[0] !== t || r[1] !== e || r[2] !== o ? (n = ()=>{
        if (!t.hasNodes([
            Te
        ])) throw new Error("LexicalAutoLinkPlugin: AutoLinkNode not registered on editor");
        let i = (s, d)=>{
            o?.(s, d);
        };
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(t.registerNodeTransform(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextNode"], (s)=>{
            let d = s.getParentOrThrow(), c = s.getPreviousSibling();
            if (we(d)) cr(d, e, i);
            else if (!J(d)) {
                if (s.isSimpleText() && (ur(s.getTextContent()) || !we(c))) {
                    let u = Sp(s);
                    wp(u, e, i);
                }
                Ep(s, e, i);
            }
        }));
    }, l = [
        t,
        e,
        o
    ], r[0] = t, r[1] = e, r[2] = o, r[3] = n, r[4] = l) : (n = r[3], l = r[4]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(n, l);
}
var Lp = RegExp("((https?:\\/\\/(www\\.)?)|(www\\.))[-\\w@:%.+~#=]{1,256}\\.[a-zA-Z\\d()]{1,6}\\b([-\\w()@:%+.~#?&/=]*)(?<![-.+():%])"), yp = /(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\])|(([a-z\-\d]+\.)+[a-z]{2,}))/i, Rp = [
    ui(Lp, (t)=>t.startsWith("http") ? t : `https://${t}`),
    ui(yp, (t)=>`mailto:${t}`)
], xi = ()=>{
    let [t] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    return Np(t, Rp), null;
};
;
;
;
var Ci = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalClickableLinkPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ClickableLinkPlugin"], {});
;
;
;
;
;
;
;
;
;
;
;
;
;
function fo(t, e, o, r = 10, n = 5) {
    let l = o.parentElement;
    if (t === null || l == null) {
        e.style.opacity = "0", e.style.transform = "translate(-10000px, -10000px)";
        return;
    }
    let i = e.getBoundingClientRect(), s = o.getBoundingClientRect(), d = l.getBoundingClientRect(), c = t.top - r, u = t.left - n;
    c < d.top && (c += i.height + t.height + r * 2), u + i.width > d.right && (u = d.right - i.width - n), c -= s.top, u -= s.left, e.style.opacity = "1", e.style.transform = `translate(${u}px, ${c}px)`;
}
;
var ho = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("TOGGLE_LINK_WITH_MODAL_COMMAND");
function Li(t) {
    t.preventDefault();
}
function yi({ anchorElem: t }) {
    let [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), [o, r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [l, i] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [s, d] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), { fieldProps: { schemaPath: c }, uuid: u } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), { config: m, getEntityConfig: p } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c__as__useConfig$3e$__["useConfig"])(), { i18n: f, t: h } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__["useTranslation"])(), [x, w] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(), E = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEditDepth"])(), [N, _] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [C, g] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]), b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useLocale"])(), [k, y] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), R = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["formatDrawerSlug"])({
        slug: "lexical-rich-text-link-" + u,
        depth: E
    }), { toggleDrawer: M } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$INBEEENE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(R), L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        _(!1), n && n.current && (n.current.style.opacity = "0", n.current.style.transform = "translate(-10000px, -10000px)"), y(!1), i(null), d(null), g([]), w(void 0);
    }, [
        _,
        i,
        d,
        g
    ]), T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        let S = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])(), I;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(S) || !S) {
            L();
            return;
        }
        let A = qe(S);
        I = e.getElementByKey(A.getKey())?.getBoundingClientRect();
        let v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$findMatchingParent"])(A, J), O = S.getNodes().filter((X)=>!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isLineBreakNode"])(X)).find((X)=>{
            let W = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$findMatchingParent"])(X, J);
            return v && !v.is(W) || W && !W.is(v);
        });
        if (v == null || O) {
            L();
            return;
        }
        r(v);
        let D = v.getFields(), G = {
            ...D,
            id: v.getID(),
            text: v.getTextContent()
        };
        if (D?.linkType === "custom") i(D?.url ?? null), d(null);
        else {
            i(`${m.routes.admin === "/" ? "" : m.routes.admin}/collections/${D?.doc?.relationTo}/${D?.doc?.value}`);
            let X = D?.doc?.relationTo ? p({
                collectionSlug: D?.doc?.relationTo
            }) : void 0;
            if (!X) d(D?.label ? String(D?.label) : null), i(D?.url ? String(D?.url) : null);
            else {
                let W = typeof D.doc?.value == "object" ? D.doc.value.id : D.doc?.value, Ge = D.doc?.relationTo;
                if (!W || !Ge) throw new Error("Focus link parent is missing doc.value or doc.relationTo");
                let ye = h("fields:linkedTo", {
                    label: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslation"])(X.labels.singular, f)} - ${h("lexical:link:loadingWithEllipsis", f)}`
                }).replace(/<[^>]*>?/g, "");
                d(ye), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$shared$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["requests"].get((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$payload$40$3$2e$70$2e$0_graphql$40$16$2e$12$2e$0_typescript$40$5$2e$7$2e$3$2f$node_modules$2f$payload$2f$dist$2f$utilities$2f$formatAdminURL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatAdminURL"])({
                    apiRoute: m.routes.api,
                    path: `/${Ge}/${W}`,
                    serverURL: m.serverURL
                }), {
                    headers: {
                        "Accept-Language": f.language
                    },
                    params: {
                        depth: 0,
                        locale: b?.code
                    }
                }).then(async (fe)=>{
                    if (!fe.ok) throw new Error(`HTTP error! Status: ${fe.status}`);
                    let Gt = await fe.json(), Re = X?.admin?.useAsTitle || "id", Vt = Gt[Re], Ve = h("fields:linkedTo", {
                        label: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslation"])(X.labels.singular, f)} - ${Vt}`
                    }).replace(/<[^>]*>?/g, "");
                    d(Ve);
                }).catch(()=>{
                    let fe = h("fields:linkedTo", {
                        label: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$translations$40$3$2e$70$2e$0$2f$node_modules$2f40$payloadcms$2f$translations$2f$dist$2f$utilities$2f$getTranslation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTranslation"])(X.labels.singular, f)} - ${h("general:untitled", f)} - ID: ${W}`
                    }).replace(/<[^>]*>?/g, "");
                    d(fe);
                });
            }
        }
        w(G), _(!0), g(S ? S?.getNodes() : []), we(v) ? y(!0) : y(!1);
        let q = n.current, z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDOMSelection"])(e._window), { activeElement: Ut } = document;
        if (q === null) return;
        let Wt = e.getRootElement();
        return z !== null && Wt !== null && Wt.contains(z.anchorNode) ? (I || (I = z.getRangeAt(0).getBoundingClientRect()), I != null && (I.y += 40, fo(I, q, t))) : (Ut == null || Ut.className !== "link-input") && (Wt !== null && fo(null, q, t), i(null), d(null)), !0;
    }, [
        e,
        L,
        m.routes.admin,
        m.routes.api,
        m.serverURL,
        p,
        h,
        f,
        b?.code,
        t
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(e.registerCommand(ho, (S)=>(e.dispatchCommand(ue, S), T(), M(), !0), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"])), [
        e,
        T,
        M,
        R
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let S = t.parentElement, I = ()=>{
            e.getEditorState().read(()=>{
                T();
            });
        };
        return window.addEventListener("resize", I), S?.addEventListener("scroll", I), ()=>{
            window.removeEventListener("resize", I), S?.removeEventListener("scroll", I);
        };
    }, [
        t.parentElement,
        e,
        T
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(e.registerUpdateListener(({ editorState: S })=>{
            S.read(()=>{
                T();
            });
        }), e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SELECTION_CHANGE_COMMAND"], ()=>(T(), !0), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEY_ESCAPE_COMMAND"], ()=>N ? (L(), !0) : !1, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_HIGH"])), [
        e,
        T,
        N,
        L
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        e.getEditorState().read(()=>{
            T();
        });
    }, [
        e,
        T
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "link-editor",
                ref: n,
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    className: "link-input",
                    children: [
                        l && l.length > 0 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("a", {
                            href: l,
                            rel: "noopener noreferrer",
                            target: "_blank",
                            children: [
                                o?.__fields.newTab ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ExternalLinkIcon"], {}) : null,
                                s != null && s.length > 0 ? s : l
                            ]
                        }) : s != null && s.length > 0 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                o?.__fields.newTab ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ExternalLinkIcon"], {}) : null,
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                                    className: "link-input__label-pure",
                                    children: s
                                })
                            ]
                        }) : null,
                        a && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                            children: [
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                                    "aria-label": "Edit link",
                                    className: "link-edit",
                                    onClick: (S)=>{
                                        S.preventDefault(), M();
                                    },
                                    onMouseDown: Li,
                                    tabIndex: 0,
                                    type: "button",
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["EditIcon"], {})
                                }),
                                !k && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                                    "aria-label": "Remove link",
                                    className: "link-trash",
                                    onClick: ()=>{
                                        e.dispatchCommand(ue, null);
                                    },
                                    onMouseDown: Li,
                                    tabIndex: 0,
                                    type: "button",
                                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CloseMenuIcon"], {})
                                })
                            ]
                        })
                    ]
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$O6XRT2H3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"], {
                className: "lexical-link-edit-drawer",
                data: x,
                drawerSlug: R,
                drawerTitle: h("fields:editLink"),
                featureKey: "link",
                handleDrawerSubmit: (S, I)=>{
                    let A = I, v = {
                        ...A
                    };
                    delete v.text, e.update(()=>{
                        let O = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])(), D = null;
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(O) ? D = qe(O).getParent() : C.length && (D = C[0]?.getParent() ?? null), D && we(D)) {
                            let G = _e({
                                fields: v
                            });
                            D.replace(G, !0);
                        }
                    }), e.dispatchCommand(ue, {
                        fields: v,
                        selectedNodes: C,
                        text: A.text
                    });
                },
                schemaPath: c,
                schemaPathSuffix: "fields"
            })
        ]
    });
}
var Ri = (t)=>{
    let { anchorElem: e = document.body } = t;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(yi, {
        anchorElem: e
    }), e);
};
;
;
;
;
;
var Qp = /^(?:[a-zA-Z][a-zA-Z\d+.-]*:(?:\/\/)?(?:[-;:&=+$,\w]+@)?[A-Za-z\d]+(?:\.[A-Za-z\d]+)+|www\.[A-Za-z\d]+(?:\.[A-Za-z\d]+)+|(?:tel|mailto):[\w+.-]+)(?:\/[+~%/\w-]*)?(?:\?[-;&=%\w]*)?(?:#\w+)?$/, ef = /^(?:\/[\w\-./]*(?:\?[-;&=%\w]*)?(?:#[\w-]+)?|#[\w\-]+)$/;
function Ii(t) {
    if (!t || t.includes(" ") || /^[a-z][a-z\d+.-]*:\/[^/]/i.test(t)) return !1;
    if (t === "https://" || Qp.test(t) || ef.test(t)) return !0;
    try {
        let e = new URL(t);
        return !([
            "ftp:",
            "http:",
            "https:"
        ].includes(e.protocol) && !e.hostname.includes("."));
    } catch  {}
    return !1;
}
var Mi = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5), { clientProps: o } = t, [r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), n, l;
    return e[0] !== o.defaultLinkType || e[1] !== o.defaultLinkURL || e[2] !== r ? (n = ()=>{
        if (!r.hasNodes([
            oe
        ])) throw new Error("LinkPlugin: LinkNode not registered on editor");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(r.registerCommand(ue, (i)=>i === null ? (ar(null), !0) : (i.fields?.linkType || (i.fields.linkType = o.defaultLinkType), i.fields?.url || (i.fields.url = o.defaultLinkURL), ar(i), !0), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), r.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PASTE_COMMAND"], (i)=>{
            let s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(s) || s.isCollapsed() || !(i instanceof ClipboardEvent) || i.clipboardData == null) return !1;
            let d = i.clipboardData.getData("text");
            if (!Ii(d)) return !1;
            if (!s.getNodes().some(uf)) {
                let c = {
                    doc: null,
                    linkType: "custom",
                    newTab: !1,
                    url: d
                };
                return r.dispatchCommand(ue, {
                    fields: c,
                    text: null
                }), i.preventDefault(), !0;
            }
            return !1;
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]));
    }, l = [
        o.defaultLinkType,
        o.defaultLinkURL,
        r
    ], e[0] = o.defaultLinkType, e[1] = o.defaultLinkURL, e[2] = r, e[3] = n, e[4] = l) : (n = e[3], l = e[4]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(n, l), null;
};
function uf(t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(t);
}
var $i = [
    nr([
        {
            ChildComponent: ni,
            isActive: ({ selection: t })=>{
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t)) {
                    let e = qe(t);
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$findMatchingParent"])(e, J) != null;
                }
                return !1;
            },
            isEnabled: ({ selection: t })=>!!((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])()?.getTextContent()?.length),
            key: "link",
            label: ({ i18n: t })=>t.t("lexical:link:label"),
            onSelect: ({ editor: t, isActive: e })=>{
                if (e) t.dispatchCommand(ue, null);
                else {
                    let o, r = [];
                    if (t.getEditorState().read(()=>{
                        o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])()?.getTextContent(), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])()?.getNodes() ?? [];
                    }), !o?.length) return;
                    let n = {
                        doc: null
                    };
                    t.dispatchCommand(ho, {
                        fields: n,
                        selectedNodes: r,
                        text: o
                    });
                }
            },
            order: 1
        }
    ])
], mf = $(({ props: t })=>({
        markdownTransformers: [
            ai
        ],
        nodes: [
            oe,
            t?.disableAutoLinks === !0 ? null : Te
        ].filter(Boolean),
        plugins: [
            {
                Component: Mi,
                position: "normal"
            },
            t?.disableAutoLinks === !0 || t?.disableAutoLinks === "creationOnly" ? null : {
                Component: xi,
                position: "normal"
            },
            {
                Component: Ci,
                position: "normal"
            },
            {
                Component: Ri,
                position: "floatingAnchorElem"
            }
        ].filter(Boolean),
        sanitizedClientFeatureProps: t,
        toolbarFixed: {
            groups: $i
        },
        toolbarInline: {
            groups: $i
        }
    }));
;
;
;
;
var pr = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                height: "13",
                rx: "1.5",
                stroke: "currentColor",
                width: "13",
                x: "3.5",
                y: "3.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M7 10L9 12.5L13 7.5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            })
        ]
    });
;
;
;
var Qe = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListPlugin"], {});
function xo(t, e) {
    return t === "ordered" ? !e.has("unorderedList") : t === "checklist" ? !e.has("unorderedList") && !e.has("orderedList") : !1;
}
function et(t) {
    return {
        items: t,
        key: "lists",
        label: ({ i18n: e })=>e.t("lexical:general:slashMenuListGroupLabel")
    };
}
;
;
var Oi = 4, tt = (t)=>(e, o, r)=>{
        let n = e.getPreviousSibling(), l = e.getNextSibling(), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createListItemNode"])(t === "check" ? r[3] === "x" : void 0);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(l) && l.getListType() === t) {
            let d = l.getFirstChild();
            d !== null ? d.insertBefore(i) : l.append(i), e.remove();
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(n) && n.getListType() === t) n.append(i), e.remove();
        else {
            let d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createListNode"])(t, t === "number" ? Number(r[2]) : void 0);
            d.append(i), e.replace(d);
        }
        i.append(...o), i.select(0, 0);
        let s = Math.floor(r[1].length / Oi);
        s && i.setIndent(s);
    }, Be = (t, e, o)=>{
    let r = [], n = t.getChildren(), l = 0;
    for (let i of n)if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListItemNode"])(i)) {
        if (i.getChildrenSize() === 1) {
            let u = i.getFirstChild();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(u)) {
                r.push(Be(u, e, o + 1));
                continue;
            }
        }
        let s = " ".repeat(o * Oi), d = t.getListType(), c = d === "number" ? `${t.getStart() + l}. ` : d === "check" ? `- [${i.getChecked() ? "x" : " "}] ` : "- ";
        r.push(s + c + e(i)), l++;
    }
    return r.join(`
`);
};
var Fi = {
    type: "element",
    dependencies: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"]
    ],
    export: (t, e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(t) ? Be(t, e, 0) : null,
    regExp: /^(\s*)(?:-\s)?\s?(\[(\s|x)?\])\s/i,
    replace: tt("check")
};
;
;
;
var Pi = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalCheckListPlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CheckListPlugin"], {});
var Bi = [
    te([
        {
            ChildComponent: pr,
            isActive: ({ selection: t })=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t)) return !1;
                for (let e of t.getNodes()){
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(e) && e.getListType() === "check") continue;
                    let o = e.getParent();
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(o) && o.getListType() === "check") continue;
                    let r = o?.getParent();
                    if (!((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(r) && r.getListType() === "check")) return !1;
                }
                return !0;
            },
            key: "checklist",
            label: ({ i18n: t })=>t.t("lexical:checklist:label"),
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_CHECK_LIST_COMMAND"], void 0);
            },
            order: 12
        }
    ])
], Lf = $(({ featureProviderMap: t })=>{
    let e = [
        {
            Component: Pi,
            position: "normal"
        }
    ], o = xo("checklist", t);
    return o && e.push({
        Component: Qe,
        position: "normal"
    }), {
        markdownTransformers: [
            Fi
        ],
        nodes: o ? [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"]
        ] : [],
        plugins: e,
        slashMenu: {
            groups: [
                et([
                    {
                        Icon: pr,
                        key: "checklist",
                        keywords: [
                            "check list",
                            "check",
                            "checklist",
                            "cl"
                        ],
                        label: ({ i18n: r })=>r.t("lexical:checklist:label"),
                        onSelect: ({ editor: r })=>{
                            r.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_CHECK_LIST_COMMAND"], void 0);
                        }
                    }
                ])
            ]
        },
        toolbarFixed: {
            groups: Bi
        },
        toolbarInline: {
            groups: Bi
        }
    };
});
;
;
;
;
var gr = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M5.89284 12.479C5.89284 13.368 5.26284 13.788 4.38084 14.236C3.75084 14.558 3.43584 14.789 3.40784 15.062H5.89984V16H2.06384V15.573C2.06384 14.523 2.92484 13.935 3.66684 13.501C4.38084 13.088 4.75184 12.878 4.75184 12.458C4.75184 12.08 4.52084 11.835 4.06584 11.835C3.58984 11.835 3.30984 12.199 3.28184 12.654H2.11284C2.18984 11.681 2.87584 10.918 4.07284 10.918C5.15784 10.918 5.89284 11.555 5.89284 12.479Z",
                fill: "currentColor"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.68608 4.535V3.737C3.54008 3.737 3.90408 3.513 4.02308 2.995H4.89108V8H3.68008L3.68008 4.535H2.68608Z",
                fill: "currentColor"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M8 15L17 15",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M8 10L17 10",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M8 5L17 5",
                stroke: "currentColor",
                strokeWidth: "1.5"
            })
        ]
    });
;
var Hi = {
    type: "element",
    dependencies: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"]
    ],
    export: (t, e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(t) ? Be(t, e, 0) : null,
    regExp: /^(\s*)(\d+)\.\s/,
    replace: tt("number")
};
var Ui = [
    te([
        {
            ChildComponent: gr,
            isActive: ({ selection: t })=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t)) return !1;
                for (let e of t.getNodes()){
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(e) && e.getListType() === "number") continue;
                    let o = e.getParent();
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(o) && o.getListType() === "number") continue;
                    let r = o?.getParent();
                    if (!((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(r) && r.getListType() === "number")) return !1;
                }
                return !0;
            },
            key: "orderedList",
            label: ({ i18n: t })=>t.t("lexical:orderedList:label"),
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_ORDERED_LIST_COMMAND"], void 0);
            },
            order: 10
        }
    ])
], Af = $(({ featureProviderMap: t })=>{
    let e = xo("ordered", t);
    return {
        markdownTransformers: [
            Hi
        ],
        nodes: e ? [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"]
        ] : [],
        plugins: e ? [
            {
                Component: Qe,
                position: "normal"
            }
        ] : [],
        slashMenu: {
            groups: [
                et([
                    {
                        Icon: gr,
                        key: "orderedList",
                        keywords: [
                            "ordered list",
                            "ol"
                        ],
                        label: ({ i18n: o })=>o.t("lexical:orderedList:label"),
                        onSelect: ({ editor: o })=>{
                            o.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_ORDERED_LIST_COMMAND"], void 0);
                        }
                    }
                ])
            ]
        },
        toolbarFixed: {
            groups: Ui
        },
        toolbarInline: {
            groups: Ui
        }
    };
});
;
;
;
;
var Cr = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", {
                cx: "4",
                cy: "5",
                fill: "currentColor",
                r: "1.15",
                stroke: "currentColor",
                strokeWidth: "0.3"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", {
                cx: "4",
                cy: "10",
                fill: "currentColor",
                r: "1.15",
                stroke: "currentColor",
                strokeWidth: "0.3"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", {
                cx: "4",
                cy: "15",
                fill: "currentColor",
                r: "1.15",
                stroke: "currentColor",
                strokeWidth: "0.3"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M17 5H7",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M17 10H7",
                stroke: "currentColor",
                strokeWidth: "1.5"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M17 15H7",
                stroke: "currentColor",
                strokeWidth: "1.5"
            })
        ]
    });
;
var Gi = {
    type: "element",
    dependencies: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"]
    ],
    export: (t, e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(t) ? Be(t, e, 0) : null,
    regExp: /^(\s*)[-*+]\s/,
    replace: tt("bullet")
};
var Vi = [
    te([
        {
            ChildComponent: Cr,
            isActive: ({ selection: t })=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t)) return !1;
                for (let e of t.getNodes()){
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(e) && e.getListType() === "bullet") continue;
                    let o = e.getParent();
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(o) && o.getListType() === "bullet") continue;
                    let r = o?.getParent();
                    if (!((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isListNode"])(r) && r.getListType() === "bullet")) return !1;
                }
                return !0;
            },
            key: "unorderedList",
            label: ({ i18n: t })=>t.t("lexical:unorderedList:label"),
            onSelect: ({ editor: t })=>{
                t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_UNORDERED_LIST_COMMAND"], void 0);
            },
            order: 11
        }
    ])
], Wf = $({
    markdownTransformers: [
        Gi
    ],
    nodes: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListItemNode"]
    ],
    plugins: [
        {
            Component: Qe,
            position: "normal"
        }
    ],
    slashMenu: {
        groups: [
            et([
                {
                    Icon: Cr,
                    key: "unorderedList",
                    keywords: [
                        "unordered list",
                        "ul"
                    ],
                    label: ({ i18n: t })=>t.t("lexical:unorderedList:label"),
                    onSelect: ({ editor: t })=>{
                        t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$list$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$list$2f$LexicalList$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_UNORDERED_LIST_COMMAND"], void 0);
                    }
                }
            ])
        ]
    },
    toolbarFixed: {
        groups: Vi
    },
    toolbarInline: {
        groups: Vi
    }
});
;
;
;
;
var zf = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"](()=>__turbopack_context__.A("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/Component-MBLHTKDK.js [app-client] (ecmascript, async loader)").then((t)=>({
            default: t.UnknownConvertedNodeComponent
        }))), It = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __data;
    constructor({ data: e, key: o }){
        super(o), this.__data = e;
    }
    static clone(e) {
        return new this({
            data: e.__data,
            key: e.__key
        });
    }
    static getType() {
        return "unknownConverted";
    }
    static importJSON(e) {
        return Xf({
            data: e.data
        });
    }
    canInsertTextAfter() {
        return !0;
    }
    canInsertTextBefore() {
        return !0;
    }
    createDOM(e) {
        let o = document.createElement("span");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addClassNamesToElement"])(o, "unknownConverted"), o;
    }
    decorate() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(zf, {
            data: this.__data
        });
    }
    exportJSON() {
        return {
            type: this.getType(),
            data: this.__data,
            version: 1
        };
    }
    isInline() {
        return !0;
    }
    updateDOM(e, o) {
        return !1;
    }
};
function Xf({ data: t }) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new It({
        data: t
    }));
}
var Zf = $(()=>({
        nodes: [
            It
        ]
    }));
;
;
;
;
var t0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"](()=>__turbopack_context__.A("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/Component-DOSSWC76.js [app-client] (ecmascript, async loader)").then((t)=>({
            default: t.UnknownConvertedNodeComponent
        }))), vt = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorNode"] {
    __data;
    constructor({ data: e, key: o }){
        super(o), this.__data = e;
    }
    static clone(e) {
        return new this({
            data: e.__data,
            key: e.__key
        });
    }
    static getType() {
        return "unknownConverted";
    }
    static importJSON(e) {
        return o0({
            data: e.data
        });
    }
    canInsertTextAfter() {
        return !0;
    }
    canInsertTextBefore() {
        return !0;
    }
    createDOM(e) {
        let o = document.createElement("span");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addClassNamesToElement"])(o, "unknownConverted"), o;
    }
    decorate() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(t0, {
            data: this.__data
        });
    }
    exportJSON() {
        return {
            type: this.getType(),
            data: this.__data,
            version: 1
        };
    }
    isInline() {
        return !0;
    }
    updateDOM(e, o) {
        return !1;
    }
};
function o0({ data: t }) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new vt({
        data: t
    }));
}
var r0 = $(()=>({
        nodes: [
            vt
        ]
    }));
;
;
var Zi = [
    te([
        {
            ChildComponent: xt,
            isActive: ({ selection: t })=>{
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t)) return !1;
                for (let e of t.getNodes())if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isParagraphNode"])(e) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isParagraphNode"])(e.getParent())) return !1;
                return !0;
            },
            key: "paragraph",
            label: ({ i18n: t })=>t.t("lexical:paragraph:label2"),
            onSelect: ({ editor: t })=>{
                t.update(()=>{
                    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$selection$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$setBlocksType"])(e, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])());
                });
            },
            order: 1
        }
    ])
], l0 = $({
    slashMenu: {
        groups: [
            Z([
                {
                    Icon: xt,
                    key: "paragraph",
                    keywords: [
                        "normal",
                        "paragraph",
                        "p",
                        "text"
                    ],
                    label: ({ i18n: t })=>t.t("lexical:paragraph:label"),
                    onSelect: ({ editor: t })=>{
                        t.update(()=>{
                            let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$selection$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$selection$2f$LexicalSelection$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$setBlocksType"])(e, ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createParagraphNode"])());
                        });
                    }
                }
            ])
        ]
    },
    toolbarFixed: {
        groups: Zi
    },
    toolbarInline: {
        groups: Zi
    }
});
;
;
;
;
;
;
;
var es = {
    quote: ({ node: t, nodesToJSX: e })=>{
        let o = e({
            nodes: t.children
        });
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("blockquote", {
            children: o
        });
    }
};
;
var ts = {
    heading: ({ node: t, nodesToJSX: e })=>{
        let o = e({
            nodes: t.children
        }), r = t.tag;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(r, {
            children: o
        });
    }
};
;
var os = {
    horizontalrule: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("hr", {})
};
;
var rs = {
    linebreak: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("br", {})
};
;
var ls = ({ internalDocToHref: t })=>({
        autolink: ({ node: e, nodesToJSX: o })=>{
            let r = o({
                nodes: e.children
            }), n = e.fields.newTab ? "noopener noreferrer" : void 0, l = e.fields.newTab ? "_blank" : void 0;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("a", {
                href: e.fields.url,
                rel: n,
                target: l,
                children: r
            });
        },
        link: ({ node: e, nodesToJSX: o })=>{
            let r = o({
                nodes: e.children
            }), n = e.fields.newTab ? "noopener noreferrer" : void 0, l = e.fields.newTab ? "_blank" : void 0, i = e.fields.url ?? "";
            return e.fields.linkType === "internal" && (t ? i = t({
                linkNode: e
            }) : (console.error("Lexical => JSX converter: Link converter: found internal link, but internalDocToHref is not provided"), i = "#")), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("a", {
                href: i,
                rel: n,
                target: l,
                children: r
            });
        }
    });
;
;
var is = {
    list: ({ node: t, nodesToJSX: e })=>{
        let o = e({
            nodes: t.children
        }), r = t.tag;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(r, {
            className: `list-${t?.listType}`,
            children: o
        });
    },
    listitem: ({ node: t, nodesToJSX: e, parent: o })=>{
        let r = t.children.some((l)=>l.type === "list"), n = e({
            nodes: t.children
        });
        if ("listType" in o && o?.listType === "check") {
            let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$uuid$40$10$2e$0$2e$0$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])();
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("li", {
                "aria-checked": t.checked ? "true" : "false",
                className: `list-item-checkbox${t.checked ? " list-item-checkbox-checked" : " list-item-checkbox-unchecked"}${r ? " nestedListItem" : ""}`,
                role: "checkbox",
                style: {
                    listStyleType: "none"
                },
                tabIndex: -1,
                value: t?.value,
                children: r ? n : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("input", {
                            checked: t.checked,
                            id: l,
                            readOnly: !0,
                            type: "checkbox"
                        }),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("label", {
                            htmlFor: l,
                            children: n
                        }),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("br", {})
                    ]
                })
            });
        } else return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("li", {
            className: `${r ? "nestedListItem" : ""}`,
            style: r ? {
                listStyleType: "none"
            } : void 0,
            value: t?.value,
            children: n
        });
    }
};
;
var ss = {
    paragraph: ({ node: t, nodesToJSX: e })=>{
        let o = e({
            nodes: t.children
        });
        return o?.length ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", {
            children: o
        }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", {
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("br", {})
        });
    }
};
var as = {
    tab: "	"
};
;
var cs = {
    table: ({ node: t, nodesToJSX: e })=>{
        let o = e({
            nodes: t.children
        });
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            className: "lexical-table-container",
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("table", {
                className: "lexical-table",
                style: {
                    borderCollapse: "collapse"
                },
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tbody", {
                    children: o
                })
            })
        });
    },
    tablecell: ({ node: t, nodesToJSX: e })=>{
        let o = e({
            nodes: t.children
        }), r = t.headerState > 0 ? "th" : "td", n = `lexical-table-cell-header-${t.headerState}`, l = {
            backgroundColor: t.backgroundColor || void 0,
            border: "1px solid #ccc",
            padding: "8px"
        }, i = t.colSpan && t.colSpan > 1 ? t.colSpan : void 0, s = t.rowSpan && t.rowSpan > 1 ? t.rowSpan : void 0;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(r, {
            className: `lexical-table-cell ${n}`,
            colSpan: i,
            rowSpan: s,
            style: l,
            children: o
        });
    },
    tablerow: ({ node: t, nodesToJSX: e })=>{
        let o = e({
            nodes: t.children
        });
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tr", {
            className: "lexical-table-row",
            children: o
        });
    }
};
;
;
var F = {
    DOM_ELEMENT_TYPE: 1,
    DOM_TEXT_TYPE: 3,
    NO_DIRTY_NODES: 0,
    HAS_DIRTY_NODES: 1,
    FULL_RECONCILE: 2,
    IS_NORMAL: 0,
    IS_TOKEN: 1,
    IS_SEGMENTED: 2,
    IS_INERT: 3,
    IS_BOLD: 1,
    IS_ITALIC: 2,
    IS_STRIKETHROUGH: 4,
    IS_UNDERLINE: 8,
    IS_CODE: 16,
    IS_SUBSCRIPT: 32,
    IS_SUPERSCRIPT: 64,
    IS_HIGHLIGHT: 128,
    IS_DIRECTIONLESS: 1,
    IS_UNMERGEABLE: 2,
    IS_ALIGN_LEFT: 1,
    IS_ALIGN_CENTER: 2,
    IS_ALIGN_RIGHT: 3,
    IS_ALIGN_JUSTIFY: 4,
    IS_ALIGN_START: 5,
    IS_ALIGN_END: 6
}, p0 = F.IS_BOLD | F.IS_ITALIC | F.IS_STRIKETHROUGH | F.IS_UNDERLINE | F.IS_CODE | F.IS_SUBSCRIPT | F.IS_SUPERSCRIPT | F.IS_HIGHLIGHT, f0 = "\xA0", h0 = `

`, us = "\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC", ds = "A-Za-z\xC0-\xD6\xD8-\xF6\xF8-\u02B8\u0300-\u0590\u0800-\u1FFF\u200E\u2C00-\uFB1C\uFE00-\uFE6F\uFEFD-\uFFFF", g0 = new RegExp("^[^" + ds + "]*[" + us + "]"), x0 = new RegExp("^[^" + us + "]*[" + ds + "]"), C0 = {
    bold: F.IS_BOLD,
    code: F.IS_CODE,
    highlight: F.IS_HIGHLIGHT,
    italic: F.IS_ITALIC,
    strikethrough: F.IS_STRIKETHROUGH,
    subscript: F.IS_SUBSCRIPT,
    superscript: F.IS_SUPERSCRIPT,
    underline: F.IS_UNDERLINE
}, b0 = {
    directionless: F.IS_DIRECTIONLESS,
    unmergeable: F.IS_UNMERGEABLE
}, k0 = {
    center: F.IS_ALIGN_CENTER,
    end: F.IS_ALIGN_END,
    justify: F.IS_ALIGN_JUSTIFY,
    left: F.IS_ALIGN_LEFT,
    right: F.IS_ALIGN_RIGHT,
    start: F.IS_ALIGN_START
}, _0 = {
    [F.IS_ALIGN_CENTER]: "center",
    [F.IS_ALIGN_END]: "end",
    [F.IS_ALIGN_JUSTIFY]: "justify",
    [F.IS_ALIGN_LEFT]: "left",
    [F.IS_ALIGN_RIGHT]: "right",
    [F.IS_ALIGN_START]: "start"
}, T0 = {
    normal: F.IS_NORMAL,
    segmented: F.IS_SEGMENTED,
    token: F.IS_TOKEN
}, w0 = {
    [F.IS_NORMAL]: "normal",
    [F.IS_SEGMENTED]: "segmented",
    [F.IS_TOKEN]: "token"
};
var ms = {
    text: ({ node: t })=>{
        let e = t.text;
        return t.format & F.IS_BOLD && (e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("strong", {
            children: e
        })), t.format & F.IS_ITALIC && (e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("em", {
            children: e
        })), t.format & F.IS_STRIKETHROUGH && (e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            style: {
                textDecoration: "line-through"
            },
            children: e
        })), t.format & F.IS_UNDERLINE && (e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            style: {
                textDecoration: "underline"
            },
            children: e
        })), t.format & F.IS_CODE && (e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("code", {
            children: e
        })), t.format & F.IS_SUBSCRIPT && (e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("sub", {
            children: e
        })), t.format & F.IS_SUPERSCRIPT && (e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("sup", {
            children: e
        })), e;
    }
};
;
var ps = {
    upload: ({ node: t })=>{
        let e = t;
        if (typeof e.value != "object") return null;
        let o = e.value, r = o.url;
        if (!o.mimeType.startsWith("image")) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("a", {
            href: r,
            rel: "noopener noreferrer",
            children: o.filename
        });
        if (!o.sizes || !Object.keys(o.sizes).length) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("img", {
            alt: o.filename,
            height: o.height,
            src: r,
            width: o.width
        });
        let n = [];
        for(let l in o.sizes){
            let i = o.sizes[l];
            if (!i || !i.width || !i.height || !i.mimeType || !i.filesize || !i.filename || !i.url) continue;
            let s = i?.url;
            n.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("source", {
                media: `(max-width: ${i.width}px)`,
                srcSet: s,
                type: i.mimeType
            }, l));
        }
        return n.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("img", {
            alt: o?.filename,
            height: o?.height,
            src: r,
            width: o?.width
        }, "image")), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("picture", {
            children: n
        });
    }
};
var nt = {
    ...ss,
    ...ms,
    ...rs,
    ...es,
    ...cs,
    ...ts,
    ...os,
    ...is,
    ...ls({}),
    ...ps,
    ...as
};
;
;
function fs(t) {
    let e = !!t?.root?.children?.length, o = !1;
    if (t?.root?.children?.length === 1 && t?.root?.children[0]?.type === "paragraph") {
        let r = t?.root?.children[0];
        if (!r?.children || r?.children?.length === 0) o = !0;
        else if (r?.children?.length === 1) {
            let n = r?.children[0];
            n?.type === "text" && (n?.text?.length || (o = !0));
        }
    }
    return !(!e || o);
}
function gs({ converters: t, data: e, disableIndent: o, disableTextAlign: r }) {
    return fs(e) ? xs({
        converters: t,
        disableIndent: o,
        disableTextAlign: r,
        nodes: e?.root?.children,
        parent: e?.root
    }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {});
}
function xs({ converters: t, disableIndent: e, disableTextAlign: o, nodes: r, parent: n }) {
    let l = t.unknown;
    return r.map((s, d)=>{
        let c;
        s.type === "block" ? (c = t?.blocks?.[s?.fields?.blockType], !c && !l && console.error(`Lexical => JSX converter: Blocks converter: found ${s?.fields?.blockType} block, but no converter is provided`)) : s.type === "inlineBlock" ? (c = t?.inlineBlocks?.[s?.fields?.blockType], !c && !l && console.error(`Lexical => JSX converter: Inline Blocks converter: found ${s?.fields?.blockType} inline block, but no converter is provided`)) : c = t[s.type];
        try {
            !c && l && (c = l);
            let u;
            c ? u = typeof c == "function" ? c({
                childIndex: d,
                converters: t,
                node: s,
                nodesToJSX: (p)=>xs({
                        converters: p.converters ?? t,
                        disableIndent: p.disableIndent ?? e,
                        disableTextAlign: p.disableTextAlign ?? o,
                        nodes: p.nodes,
                        parent: p.parent ?? {
                            ...s,
                            parent: n
                        }
                    }),
                parent: n
            }) : c : u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                children: "unknown node"
            }, d);
            let a = {};
            if (!o && (!Array.isArray(o) || !o?.includes(s.type)) && "format" in s && s.format) switch(s.format){
                case "center":
                    a.textAlign = "center";
                    break;
                case "end":
                    a.textAlign = "right";
                    break;
                case "justify":
                    a.textAlign = "justify";
                    break;
                case "left":
                    break;
                case "right":
                    a.textAlign = "right";
                    break;
                case "start":
                    a.textAlign = "left";
                    break;
            }
            if (!e && (!Array.isArray(e) || !e?.includes(s.type)) && "indent" in s && s.indent && s.type !== "listitem" && (a.paddingInlineStart = `${Number(s.indent) * 40}px`), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isValidElement(u)) {
                if (a.textAlign || a.paddingInlineStart) {
                    let m = {
                        ...a,
                        ...u?.props?.style ?? {}
                    };
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].cloneElement(u, {
                        key: d,
                        style: m
                    });
                }
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].cloneElement(u, {
                    key: d
                });
            }
            return u;
        } catch (u) {
            return console.error("Error converting lexical node to JSX:", u, "node:", s), null;
        }
    }).filter(Boolean);
}
var Tr = ({ className: t, converters: e, data: o, disableContainer: r, disableIndent: n, disableTextAlign: l })=>{
    if (!o) return null;
    let i = {};
    e ? typeof e == "function" ? i = e({
        defaultConverters: nt
    }) : i = e : i = nt;
    let s = o && !Array.isArray(o) && typeof o == "object" && "root" in o && gs({
        converters: i,
        data: o,
        disableIndent: n,
        disableTextAlign: l
    });
    return r ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: s
    }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: t ?? "payload-richtext",
        children: s
    });
};
function ks() {
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7), [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), o;
    t[0] !== e ? (o = e.getEditorState().toJSON(), t[0] = e, t[1] = o) : o = t[1];
    let [r, n] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(o), l, i;
    t[2] !== e ? (l = ()=>e.registerUpdateListener((d)=>{
            let { editorState: c } = d;
            n(c.toJSON());
        }), i = [
        e
    ], t[2] = e, t[3] = l, t[4] = i) : (l = t[3], i = t[4]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(l, i);
    let s;
    return t[5] !== r ? (s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "debug-jsx-converter",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Tr, {
            converters: nt,
            data: r
        })
    }), t[5] = r, t[6] = s) : s = t[6], s;
}
var I0 = $({
    plugins: [
        {
            Component: ks,
            position: "bottom"
        }
    ]
});
var B = {
    amber: {
        50: "oklch(0.987 0.022 95.277)",
        100: "oklch(0.962 0.059 95.617)",
        200: "oklch(0.924 0.12 95.746)",
        300: "oklch(0.879 0.169 91.605)",
        400: "oklch(0.828 0.189 84.429)",
        500: "oklch(0.769 0.188 70.08)",
        600: "oklch(0.666 0.179 58.318)",
        700: "oklch(0.555 0.163 48.998)",
        800: "oklch(0.473 0.137 46.201)",
        900: "oklch(0.414 0.112 45.904)",
        950: "oklch(0.279 0.077 45.635)"
    },
    black: "#000",
    blue: {
        50: "oklch(0.97 0.014 254.604)",
        100: "oklch(0.932 0.032 255.585)",
        200: "oklch(0.882 0.059 254.128)",
        300: "oklch(0.809 0.105 251.813)",
        400: "oklch(0.707 0.165 254.624)",
        500: "oklch(0.623 0.214 259.815)",
        600: "oklch(0.546 0.245 262.881)",
        700: "oklch(0.488 0.243 264.376)",
        800: "oklch(0.424 0.199 265.638)",
        900: "oklch(0.379 0.146 265.522)",
        950: "oklch(0.282 0.091 267.935)"
    },
    current: "currentColor",
    cyan: {
        50: "oklch(0.984 0.019 200.873)",
        100: "oklch(0.956 0.045 203.388)",
        200: "oklch(0.917 0.08 205.041)",
        300: "oklch(0.865 0.127 207.078)",
        400: "oklch(0.789 0.154 211.53)",
        500: "oklch(0.715 0.143 215.221)",
        600: "oklch(0.609 0.126 221.723)",
        700: "oklch(0.52 0.105 223.128)",
        800: "oklch(0.45 0.085 224.283)",
        900: "oklch(0.398 0.07 227.392)",
        950: "oklch(0.302 0.056 229.695)"
    },
    emerald: {
        50: "oklch(0.979 0.021 166.113)",
        100: "oklch(0.95 0.052 163.051)",
        200: "oklch(0.905 0.093 164.15)",
        300: "oklch(0.845 0.143 164.978)",
        400: "oklch(0.765 0.177 163.223)",
        500: "oklch(0.696 0.17 162.48)",
        600: "oklch(0.596 0.145 163.225)",
        700: "oklch(0.508 0.118 165.612)",
        800: "oklch(0.432 0.095 166.913)",
        900: "oklch(0.378 0.077 168.94)",
        950: "oklch(0.262 0.051 172.552)"
    },
    fuchsia: {
        50: "oklch(0.977 0.017 320.058)",
        100: "oklch(0.952 0.037 318.852)",
        200: "oklch(0.903 0.076 319.62)",
        300: "oklch(0.833 0.145 321.434)",
        400: "oklch(0.74 0.238 322.16)",
        500: "oklch(0.667 0.295 322.15)",
        600: "oklch(0.591 0.293 322.896)",
        700: "oklch(0.518 0.253 323.949)",
        800: "oklch(0.452 0.211 324.591)",
        900: "oklch(0.401 0.17 325.612)",
        950: "oklch(0.293 0.136 325.661)"
    },
    gray: {
        50: "oklch(0.985 0.002 247.839)",
        100: "oklch(0.967 0.003 264.542)",
        200: "oklch(0.928 0.006 264.531)",
        300: "oklch(0.872 0.01 258.338)",
        400: "oklch(0.707 0.022 261.325)",
        500: "oklch(0.551 0.027 264.364)",
        600: "oklch(0.446 0.03 256.802)",
        700: "oklch(0.373 0.034 259.733)",
        800: "oklch(0.278 0.033 256.848)",
        900: "oklch(0.21 0.034 264.665)",
        950: "oklch(0.13 0.028 261.692)"
    },
    green: {
        50: "oklch(0.982 0.018 155.826)",
        100: "oklch(0.962 0.044 156.743)",
        200: "oklch(0.925 0.084 155.995)",
        300: "oklch(0.871 0.15 154.449)",
        400: "oklch(0.792 0.209 151.711)",
        500: "oklch(0.723 0.219 149.579)",
        600: "oklch(0.627 0.194 149.214)",
        700: "oklch(0.527 0.154 150.069)",
        800: "oklch(0.448 0.119 151.328)",
        900: "oklch(0.393 0.095 152.535)",
        950: "oklch(0.266 0.065 152.934)"
    },
    indigo: {
        50: "oklch(0.962 0.018 272.314)",
        100: "oklch(0.93 0.034 272.788)",
        200: "oklch(0.87 0.065 274.039)",
        300: "oklch(0.785 0.115 274.713)",
        400: "oklch(0.673 0.182 276.935)",
        500: "oklch(0.585 0.233 277.117)",
        600: "oklch(0.511 0.262 276.966)",
        700: "oklch(0.457 0.24 277.023)",
        800: "oklch(0.398 0.195 277.366)",
        900: "oklch(0.359 0.144 278.697)",
        950: "oklch(0.257 0.09 281.288)"
    },
    inherit: "inherit",
    lime: {
        50: "oklch(0.986 0.031 120.757)",
        100: "oklch(0.967 0.067 122.328)",
        200: "oklch(0.938 0.127 124.321)",
        300: "oklch(0.897 0.196 126.665)",
        400: "oklch(0.841 0.238 128.85)",
        500: "oklch(0.768 0.233 130.85)",
        600: "oklch(0.648 0.2 131.684)",
        700: "oklch(0.532 0.157 131.589)",
        800: "oklch(0.453 0.124 130.933)",
        900: "oklch(0.405 0.101 131.063)",
        950: "oklch(0.274 0.072 132.109)"
    },
    neutral: {
        50: "oklch(0.985 0 0)",
        100: "oklch(0.97 0 0)",
        200: "oklch(0.922 0 0)",
        300: "oklch(0.87 0 0)",
        400: "oklch(0.708 0 0)",
        500: "oklch(0.556 0 0)",
        600: "oklch(0.439 0 0)",
        700: "oklch(0.371 0 0)",
        800: "oklch(0.269 0 0)",
        900: "oklch(0.205 0 0)",
        950: "oklch(0.145 0 0)"
    },
    orange: {
        50: "oklch(0.98 0.016 73.684)",
        100: "oklch(0.954 0.038 75.164)",
        200: "oklch(0.901 0.076 70.697)",
        300: "oklch(0.837 0.128 66.29)",
        400: "oklch(0.75 0.183 55.934)",
        500: "oklch(0.705 0.213 47.604)",
        600: "oklch(0.646 0.222 41.116)",
        700: "oklch(0.553 0.195 38.402)",
        800: "oklch(0.47 0.157 37.304)",
        900: "oklch(0.408 0.123 38.172)",
        950: "oklch(0.266 0.079 36.259)"
    },
    pink: {
        50: "oklch(0.971 0.014 343.198)",
        100: "oklch(0.948 0.028 342.258)",
        200: "oklch(0.899 0.061 343.231)",
        300: "oklch(0.823 0.12 346.018)",
        400: "oklch(0.718 0.202 349.761)",
        500: "oklch(0.656 0.241 354.308)",
        600: "oklch(0.592 0.249 0.584)",
        700: "oklch(0.525 0.223 3.958)",
        800: "oklch(0.459 0.187 3.815)",
        900: "oklch(0.408 0.153 2.432)",
        950: "oklch(0.284 0.109 3.907)"
    },
    purple: {
        50: "oklch(0.977 0.014 308.299)",
        100: "oklch(0.946 0.033 307.174)",
        200: "oklch(0.902 0.063 306.703)",
        300: "oklch(0.827 0.119 306.383)",
        400: "oklch(0.714 0.203 305.504)",
        500: "oklch(0.627 0.265 303.9)",
        600: "oklch(0.558 0.288 302.321)",
        700: "oklch(0.496 0.265 301.924)",
        800: "oklch(0.438 0.218 303.724)",
        900: "oklch(0.381 0.176 304.987)",
        950: "oklch(0.291 0.149 302.717)"
    },
    red: {
        50: "oklch(0.971 0.013 17.38)",
        100: "oklch(0.936 0.032 17.717)",
        200: "oklch(0.885 0.062 18.334)",
        300: "oklch(0.808 0.114 19.571)",
        400: "oklch(0.704 0.191 22.216)",
        500: "oklch(0.637 0.237 25.331)",
        600: "oklch(0.577 0.245 27.325)",
        700: "oklch(0.505 0.213 27.518)",
        800: "oklch(0.444 0.177 26.899)",
        900: "oklch(0.396 0.141 25.723)",
        950: "oklch(0.258 0.092 26.042)"
    },
    rose: {
        50: "oklch(0.969 0.015 12.422)",
        100: "oklch(0.941 0.03 12.58)",
        200: "oklch(0.892 0.058 10.001)",
        300: "oklch(0.81 0.117 11.638)",
        400: "oklch(0.712 0.194 13.428)",
        500: "oklch(0.645 0.246 16.439)",
        600: "oklch(0.586 0.253 17.585)",
        700: "oklch(0.514 0.222 16.935)",
        800: "oklch(0.455 0.188 13.697)",
        900: "oklch(0.41 0.159 10.272)",
        950: "oklch(0.271 0.105 12.094)"
    },
    sky: {
        50: "oklch(0.977 0.013 236.62)",
        100: "oklch(0.951 0.026 236.824)",
        200: "oklch(0.901 0.058 230.902)",
        300: "oklch(0.828 0.111 230.318)",
        400: "oklch(0.746 0.16 232.661)",
        500: "oklch(0.685 0.169 237.323)",
        600: "oklch(0.588 0.158 241.966)",
        700: "oklch(0.5 0.134 242.749)",
        800: "oklch(0.443 0.11 240.79)",
        900: "oklch(0.391 0.09 240.876)",
        950: "oklch(0.293 0.066 243.157)"
    },
    slate: {
        50: "oklch(0.984 0.003 247.858)",
        100: "oklch(0.968 0.007 247.896)",
        200: "oklch(0.929 0.013 255.508)",
        300: "oklch(0.869 0.022 252.894)",
        400: "oklch(0.704 0.04 256.788)",
        500: "oklch(0.554 0.046 257.417)",
        600: "oklch(0.446 0.043 257.281)",
        700: "oklch(0.372 0.044 257.287)",
        800: "oklch(0.279 0.041 260.031)",
        900: "oklch(0.208 0.042 265.755)",
        950: "oklch(0.129 0.042 264.695)"
    },
    stone: {
        50: "oklch(0.985 0.001 106.423)",
        100: "oklch(0.97 0.001 106.424)",
        200: "oklch(0.923 0.003 48.717)",
        300: "oklch(0.869 0.005 56.366)",
        400: "oklch(0.709 0.01 56.259)",
        500: "oklch(0.553 0.013 58.071)",
        600: "oklch(0.444 0.011 73.639)",
        700: "oklch(0.374 0.01 67.558)",
        800: "oklch(0.268 0.007 34.298)",
        900: "oklch(0.216 0.006 56.043)",
        950: "oklch(0.147 0.004 49.25)"
    },
    teal: {
        50: "oklch(0.984 0.014 180.72)",
        100: "oklch(0.953 0.051 180.801)",
        200: "oklch(0.91 0.096 180.426)",
        300: "oklch(0.855 0.138 181.071)",
        400: "oklch(0.777 0.152 181.912)",
        500: "oklch(0.704 0.14 182.503)",
        600: "oklch(0.6 0.118 184.704)",
        700: "oklch(0.511 0.096 186.391)",
        800: "oklch(0.437 0.078 188.216)",
        900: "oklch(0.386 0.063 188.416)",
        950: "oklch(0.277 0.046 192.524)"
    },
    transparent: "transparent",
    violet: {
        50: "oklch(0.969 0.016 293.756)",
        100: "oklch(0.943 0.029 294.588)",
        200: "oklch(0.894 0.057 293.283)",
        300: "oklch(0.811 0.111 293.571)",
        400: "oklch(0.702 0.183 293.541)",
        500: "oklch(0.606 0.25 292.717)",
        600: "oklch(0.541 0.281 293.009)",
        700: "oklch(0.491 0.27 292.581)",
        800: "oklch(0.432 0.232 292.759)",
        900: "oklch(0.38 0.189 293.745)",
        950: "oklch(0.283 0.141 291.089)"
    },
    white: "#fff",
    yellow: {
        50: "oklch(0.987 0.026 102.212)",
        100: "oklch(0.973 0.071 103.193)",
        200: "oklch(0.945 0.129 101.54)",
        300: "oklch(0.905 0.182 98.111)",
        400: "oklch(0.852 0.199 91.936)",
        500: "oklch(0.795 0.184 86.047)",
        600: "oklch(0.681 0.162 75.834)",
        700: "oklch(0.554 0.135 66.442)",
        800: "oklch(0.476 0.114 61.907)",
        900: "oklch(0.421 0.095 57.708)",
        950: "oklch(0.286 0.066 53.813)"
    },
    zinc: {
        50: "oklch(0.985 0 0)",
        100: "oklch(0.967 0.001 286.375)",
        200: "oklch(0.92 0.004 286.32)",
        300: "oklch(0.871 0.006 286.286)",
        400: "oklch(0.705 0.015 286.067)",
        500: "oklch(0.552 0.016 285.938)",
        600: "oklch(0.442 0.017 285.786)",
        700: "oklch(0.37 0.013 285.805)",
        800: "oklch(0.274 0.006 286.033)",
        900: "oklch(0.21 0.006 285.885)",
        950: "oklch(0.141 0.005 285.823)"
    }
}, v0 = {
    text: {
        "text-red": {
            css: {
                color: `light-dark(${B.red[600]}, ${B.red[400]})`
            },
            label: "Red"
        },
        "text-orange": {
            css: {
                color: `light-dark(${B.orange[600]}, ${B.orange[400]})`
            },
            label: "Orange"
        },
        "text-yellow": {
            css: {
                color: `light-dark(${B.yellow[700]}, ${B.yellow[300]})`
            },
            label: "Yellow"
        },
        "text-green": {
            css: {
                color: `light-dark(${B.green[700]}, ${B.green[400]})`
            },
            label: "Green"
        },
        "text-blue": {
            css: {
                color: `light-dark(${B.blue[600]}, ${B.blue[400]})`
            },
            label: "Blue"
        },
        "text-purple": {
            css: {
                color: `light-dark(${B.purple[600]}, ${B.purple[400]})`
            },
            label: "Purple"
        },
        "text-pink": {
            css: {
                color: `light-dark(${B.pink[600]}, ${B.pink[400]})`
            },
            label: "Pink"
        }
    },
    background: {
        "bg-red": {
            css: {
                "background-color": `light-dark(${B.red[400]}, ${B.red[600]})`
            },
            label: "Red"
        },
        "bg-orange": {
            css: {
                "background-color": `light-dark(${B.orange[400]}, ${B.orange[600]})`
            },
            label: "Orange"
        },
        "bg-yellow": {
            css: {
                "background-color": `light-dark(${B.yellow[300]}, ${B.yellow[700]})`
            },
            label: "Yellow"
        },
        "bg-green": {
            css: {
                "background-color": `light-dark(${B.green[400]}, ${B.green[700]})`
            },
            label: "Green"
        },
        "bg-blue": {
            css: {
                "background-color": `light-dark(${B.blue[400]}, ${B.blue[600]})`
            },
            label: "Blue"
        },
        "bg-purple": {
            css: {
                "background-color": `light-dark(${B.purple[400]}, ${B.purple[600]})`
            },
            label: "Purple"
        },
        "bg-pink": {
            css: {
                "background-color": `light-dark(${B.pink[400]}, ${B.pink[600]})`
            },
            label: "Pink"
        }
    }
};
;
;
;
var wr = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                clipPath: "url(#clip0_4397_10817)",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                    d: "M7.75 12.25L15.25 4.75M15.25 4.75H11.5M15.25 4.75V8.5M13 11.5V13.75C13 14.5784 12.3284 15.25 11.5 15.25H6.25C5.42157 15.25 4.75 14.5784 4.75 13.75V8.5C4.75 7.67157 5.42157 7 6.25 7H8.5",
                    stroke: "currentColor",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("defs", {
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("clipPath", {
                    id: "clip0_4397_10817",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                        fill: "currentColor",
                        height: "12",
                        transform: "translate(4 4)",
                        width: "12"
                    })
                })
            })
        ]
    });
;
;
;
;
;
;
function O0(t) {
    let e = t.getAttribute("data-lexical-relationship-id"), o = t.getAttribute("data-lexical-relationship-relationTo");
    return e != null && o != null ? {
        node: _s({
            relationTo: o,
            value: e
        })
    } : null;
}
var At = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorBlockNode"] {
    __data;
    constructor({ data: e, format: o, key: r }){
        super(o, r), this.__data = e;
    }
    static clone(e) {
        return new this({
            data: e.__data,
            format: e.__format,
            key: e.__key
        });
    }
    static getType() {
        return "relationship";
    }
    static importDOM() {
        return {
            div: (e)=>!e.hasAttribute("data-lexical-relationship-relationTo") || !e.hasAttribute("data-lexical-relationship-id") ? null : {
                    conversion: O0,
                    priority: 2
                }
        };
    }
    static importJSON(e) {
        e.version === 1 && e?.value?.id && (e.value = e.value.id);
        let o = {
            relationTo: e.relationTo,
            value: e.value
        }, r = _s(o);
        return r.setFormat(e.format), r;
    }
    static isInline() {
        return !1;
    }
    createDOM(e) {
        let o = document.createElement("div");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addClassNamesToElement"])(o, e?.theme?.relationship), o;
    }
    decorate(e, o) {
        return null;
    }
    exportDOM() {
        let e = document.createElement("div");
        e.setAttribute("data-lexical-relationship-id", String(typeof this.__data?.value == "object" ? this.__data?.value?.id : this.__data?.value)), e.setAttribute("data-lexical-relationship-relationTo", this.__data?.relationTo);
        let o = document.createTextNode(this.getTextContent());
        return e.append(o), {
            element: e
        };
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            ...this.getData(),
            type: "relationship",
            version: 2
        };
    }
    getData() {
        return this.getLatest().__data;
    }
    getTextContent() {
        return `${this.__data?.relationTo} relation to ${typeof this.__data?.value == "object" ? this.__data?.value?.id : this.__data?.value}`;
    }
    setData(e) {
        let o = this.getWritable();
        o.__data = e;
    }
};
function _s(t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new At({
        data: t
    }));
}
var B0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"](()=>__turbopack_context__.A("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/RelationshipComponent-BG3DPV3T.js [app-client] (ecmascript, async loader)").then((t)=>({
            default: t.RelationshipComponent
        })));
function j0(t) {
    let e = t.getAttribute("data-lexical-relationship-id"), o = t.getAttribute("data-lexical-relationship-relationTo");
    return e != null && o != null ? {
        node: He({
            relationTo: o,
            value: e
        })
    } : null;
}
var Se = class extends At {
    static clone(e) {
        return super.clone(e);
    }
    static getType() {
        return super.getType();
    }
    static importDOM() {
        return {
            div: (e)=>!e.hasAttribute("data-lexical-relationship-relationTo") || !e.hasAttribute("data-lexical-relationship-id") ? null : {
                    conversion: j0,
                    priority: 2
                }
        };
    }
    static importJSON(e) {
        e.version === 1 && e?.value?.id && (e.value = e.value.id);
        let o = {
            relationTo: e.relationTo,
            value: e.value
        }, r = He(o);
        return r.setFormat(e.format), r;
    }
    decorate(e, o) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(B0, {
            className: o.theme.relationship ?? "LexicalEditorTheme__relationship",
            data: this.__data,
            format: this.__format,
            nodeKey: this.getKey()
        });
    }
    exportJSON() {
        return super.exportJSON();
    }
};
function He(t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new Se({
        data: t
    }));
}
function Er(t) {
    return t instanceof Se;
}
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var Ot = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23), [o] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), [r, n] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [l, i] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [s, d, c] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useListDrawer"])(t), { closeDrawer: u, drawerSlug: a, isDrawerOpen: m, openDrawer: p } = c, { modalState: f } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useModal"])(), h;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (h = ()=>{
        let R = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])() ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getPreviousSelection"])();
        n(R);
    }, e[0] = h) : h = e[0];
    let x = h, w;
    e[1] !== o || e[2] !== r ? (w = ()=>{
        r && o.update(()=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(r)) {
                let { anchor: R, focus: M } = r;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(R.key) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(M.key) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$setSelection"])(r.clone());
            } else (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getRoot"])().selectEnd();
        }, {
            discrete: !0,
            skipTransforms: !0
        });
    }, e[1] = o, e[2] = r, e[3] = w) : w = e[3];
    let E = w, N;
    e[4] !== u ? (N = ()=>{
        u();
    }, e[4] = u, e[5] = N) : N = e[5];
    let _ = N, C, g;
    e[6] !== a || e[7] !== f || e[8] !== E || e[9] !== l ? (C = ()=>{
        if (!l) return;
        let R = f[a];
        R && !R?.isOpen && (i(!1), setTimeout(()=>{
            E();
        }, 1));
    }, g = [
        f,
        a,
        E,
        l
    ], e[6] = a, e[7] = f, e[8] = E, e[9] = l, e[10] = C, e[11] = g) : (C = e[10], g = e[11]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(C, g);
    let b;
    e[12] !== d ? (b = (R)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(d, {
            ...R,
            onClick: ()=>{
                x();
            }
        }), e[12] = d, e[13] = b) : b = e[13];
    let k;
    e[14] !== p ? (k = ()=>{
        x(), p(), i(!0);
    }, e[14] = p, e[15] = k) : k = e[15];
    let y;
    return e[16] !== s || e[17] !== _ || e[18] !== m || e[19] !== a || e[20] !== b || e[21] !== k ? (y = {
        closeListDrawer: _,
        isListDrawerOpen: m,
        ListDrawer: s,
        listDrawerSlug: a,
        ListDrawerToggler: b,
        openListDrawer: k
    }, e[16] = s, e[17] = _, e[18] = m, e[19] = a, e[20] = b, e[21] = k, e[22] = y) : y = e[22], y;
};
var t1 = ({ editor: t, relationTo: e, replaceNodeKey: o, value: r })=>{
    o ? t.update(()=>{
        let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(o);
        n && n.replace(He({
            relationTo: e,
            value: r
        }));
    }) : t.dispatchCommand(Nr, {
        relationTo: e,
        value: r
    });
}, o1 = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14), { enabledCollectionSlugs: o } = t, [r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), [n, l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), i = o?.[0], s;
    e[0] !== o || e[1] !== i ? (s = {
        collectionSlugs: o,
        selectedCollection: i
    }, e[0] = o, e[1] = i, e[2] = s) : s = e[2];
    let { closeListDrawer: d, ListDrawer: c, openListDrawer: u } = Ot(s), a, m;
    e[3] !== r || e[4] !== u ? (a = ()=>r.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$DBWINSQN$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"], (x)=>(l(x?.replace ? x?.replace.nodeKey : null), u(), !0), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), m = [
        r,
        u
    ], e[3] = r, e[4] = u, e[5] = a, e[6] = m) : (a = e[5], m = e[6]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(a, m);
    let p;
    e[7] !== d || e[8] !== r || e[9] !== n ? (p = (x)=>{
        let { collectionSlug: w, doc: E } = x;
        t1({
            editor: r,
            relationTo: w,
            replaceNodeKey: n,
            value: E.id
        }), d();
    }, e[7] = d, e[8] = r, e[9] = n, e[10] = p) : p = e[10];
    let f = p, h;
    return e[11] !== c || e[12] !== f ? (h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(c, {
        onSelect: f
    }), e[11] = c, e[12] = f, e[13] = h) : h = e[13], h;
}, r1 = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3), [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), o, r;
    return t[0] !== e ? (o = ()=>e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$DBWINSQN$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"], n1, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), r = [
        e
    ], t[0] = e, t[1] = o, t[2] = r) : (o = t[1], r = t[2]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(o, r), null;
}, Rs = ({ enabledCollectionSlugs: t })=>t?.length ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(o1, {
        enabledCollectionSlugs: t
    }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(r1, {});
function n1() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toast"].error("No relationship collections enabled"), !0;
}
;
;
var Co = (t)=>{
    let { collectionSlugsBlacklist: e, collectionSlugsWhitelist: o, uploads: r = !1 } = t || {}, { config: { collections: n } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c__as__useConfig$3e$__["useConfig"])(), { visibleEntities: l } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEntityVisibility"])();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "Co.useMemo": ()=>{
            let s = [], d = [], c = o ? new Set(o) : null, u = e ? new Set(e) : null;
            for (let a of n){
                let { slug: m, admin: { enableRichTextRelationship: p }, upload: f } = a;
                if (l?.collections.includes(m)) {
                    if (r) {
                        if (!p || !f) continue;
                    } else if (f || !p) continue;
                    c && !c.has(m) || u && u.has(m) || (s.push(m), d.push(a));
                }
            }
            return {
                enabledCollections: d,
                enabledCollectionSlugs: s
            };
        }
    }["Co.useMemo"], [
        n,
        l,
        r,
        o,
        e
    ]);
};
var Nr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("INSERT_RELATIONSHIP_COMMAND"), vs = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8), { clientProps: o } = t, [r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), n = o?.disabledCollections, l = o?.enabledCollections, i;
    e[0] !== n || e[1] !== l ? (i = {
        collectionSlugsBlacklist: n,
        collectionSlugsWhitelist: l
    }, e[0] = n, e[1] = l, e[2] = i) : i = e[2];
    let { enabledCollectionSlugs: s } = Co(i), d, c;
    e[3] !== r ? (d = ()=>{
        if (!r.hasNodes([
            Se
        ])) throw new Error("RelationshipPlugin: RelationshipNode not registered on editor");
        return r.registerCommand(Nr, C1, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]);
    }, c = [
        r
    ], e[3] = r, e[4] = d, e[5] = c) : (d = e[4], c = e[5]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(d, c);
    let u;
    return e[6] !== s ? (u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Rs, {
        enabledCollectionSlugs: s
    }), e[6] = s, e[7] = u) : u = e[7], u;
};
function C1(t) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])() || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getPreviousSelection"])();
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(e)) {
        let o = He(t), { focus: r } = e, n = r.getNode();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(o), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isParagraphNode"])(n) && !n.__first && n.remove();
    }
    return !0;
}
var k1 = $({
    nodes: [
        Se
    ],
    plugins: [
        {
            Component: vs,
            position: "normal"
        }
    ],
    slashMenu: {
        groups: [
            Z([
                {
                    Icon: wr,
                    key: "relationship",
                    keywords: [
                        "relationship",
                        "relation",
                        "rel"
                    ],
                    label: ({ i18n: t })=>t.t("lexical:relationship:label"),
                    onSelect: ({ editor: t })=>{
                        t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$DBWINSQN$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"], {
                            replace: !1
                        });
                    }
                }
            ])
        ]
    },
    toolbarFixed: {
        groups: [
            be([
                {
                    ChildComponent: wr,
                    isActive: ({ selection: t })=>{
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])(t) || !t.getNodes().length) return !1;
                        let e = t.getNodes()[0];
                        return Er(e);
                    },
                    key: "relationship",
                    label: ({ i18n: t })=>t.t("lexical:relationship:label"),
                    onSelect: ({ editor: t })=>{
                        t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$DBWINSQN$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"], {
                            replace: !1
                        });
                    }
                }
            ])
        ]
    }
});
;
;
;
;
;
;
;
;
;
;
;
;
var Ms = "toolbar-popup__button", Ft = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23), { children: o, editor: r, item: n } = t, l;
    e[0] === Symbol.for("react.memo_cache_sentinel") ? (l = {
        active: !1,
        enabled: !0
    }, e[0] = l) : l = e[0];
    let [i, s] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(l), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeferredValue"])(i), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), u = d.enabled ? "" : "disabled", a = d.active ? "active" : "", m = n.key ? `${Ms}-${n.key}` : "", p;
    e[1] !== u || e[2] !== a || e[3] !== m ? (p = [
        Ms,
        u,
        a,
        m
    ].filter(Boolean), e[1] = u, e[2] = a, e[3] = m, e[4] = p) : p = e[4];
    let f = p.join(" "), h;
    e[5] !== r || e[6] !== c || e[7] !== n ? (h = ()=>{
        r.getEditorState().read(()=>{
            let k = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
            if (!k) return;
            let y = n.isActive ? n.isActive({
                editor: r,
                editorConfigContext: c,
                selection: k
            }) : !1, R = n.isEnabled ? n.isEnabled({
                editor: r,
                editorConfigContext: c,
                selection: k
            }) : !0;
            s((M)=>M.active === y && M.enabled === R ? M : {
                    active: y,
                    enabled: R
                });
        });
    }, e[5] = r, e[6] = c, e[7] = n, e[8] = h) : h = e[8];
    let x = h, w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["e"])(), E, N;
    e[9] !== r || e[10] !== w || e[11] !== x ? (E = ()=>{
        w(x);
        let k = ()=>w(x), y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(r.registerUpdateListener(k));
        return document.addEventListener("mouseup", k), ()=>{
            y(), document.removeEventListener("mouseup", k);
        };
    }, N = [
        r,
        w,
        x
    ], e[9] = r, e[10] = w, e[11] = x, e[12] = E, e[13] = N) : (E = e[12], N = e[13]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(E, N);
    let _;
    e[14] !== i || e[15] !== r || e[16] !== n ? (_ = ()=>{
        i.enabled && r.focus(()=>{
            r.update(R1), n.onSelect?.({
                editor: r,
                isActive: i.active
            });
        });
    }, e[14] = i, e[15] = r, e[16] = n, e[17] = _) : _ = e[17];
    let C = _, g = I1, b;
    return e[18] !== o || e[19] !== f || e[20] !== C || e[21] !== n.key ? (b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
        className: f,
        "data-button-key": n.key,
        onClick: C,
        onMouseDown: g,
        type: "button",
        children: o
    }), e[18] = o, e[19] = f, e[20] = C, e[21] = n.key, e[22] = b) : b = e[22], b;
};
function R1() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$addUpdateTag"])("toolbar");
}
function I1(t) {
    t.preventDefault();
}
;
;
;
;
;
;
;
;
;
;
;
var $s = "toolbar-popup__dropdown-item", Os = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext(null);
function Fs({ active: t, children: e, editor: o, enabled: r, Icon: n, item: l, itemKey: i, tooltip: s }) {
    let d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>[
            $s,
            r === !1 ? "disabled" : "",
            t ? "active" : "",
            l?.key ? `${$s}-${l.key}` : ""
        ].filter(Boolean).join(" "), [
        r,
        t,
        l.key
    ]), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), u = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].use(Os);
    if (u === null) throw new Error("DropDownItem must be used within a DropDown");
    let { registerItem: a } = u;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        c?.current != null && a(c);
    }, [
        c,
        a
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Button"], {
        "aria-label": s,
        buttonStyle: "none",
        className: d,
        disabled: r === !1,
        extraButtonProps: {
            "data-item-key": i
        },
        icon: n,
        iconPosition: "left",
        iconStyle: "none",
        onClick: ()=>{
            r !== !1 && o.focus(()=>{
                o.update(()=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$addUpdateTag"])("toolbar");
                }), l.onSelect?.({
                    editor: o,
                    isActive: t
                });
            });
        },
        onMouseDown: (m)=>{
            m.preventDefault();
        },
        ref: c,
        tooltip: s,
        type: "button",
        children: e
    });
}
function O1({ children: t, dropDownRef: e, itemsContainerClassNames: o, onClose: r }) {
    let [n, l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(), [i, s] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((a)=>{
        l((m)=>m != null ? [
                ...m,
                a
            ] : [
                a
            ]);
    }, [
        l
    ]), c = (a)=>{
        if (n == null) return;
        let { key: m } = a;
        [
            "ArrowDown",
            "ArrowUp",
            "Escape",
            "Tab"
        ].includes(m) && a.preventDefault(), m === "Escape" || m === "Tab" ? r() : m === "ArrowUp" ? s((p)=>{
            if (p == null) return n[0];
            let f = n.indexOf(p) - 1;
            return n[f === -1 ? n.length - 1 : f];
        }) : m === "ArrowDown" && s((p)=>p == null ? n[0] : n[n.indexOf(p) + 1]);
    }, u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            registerItem: d
        }), [
        d
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        n != null && i == null && s(n[0]), i != null && i?.current != null && i.current.focus();
    }, [
        n,
        i
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Os, {
        value: u,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            className: (o ?? [
                "toolbar-popup__dropdown-items"
            ]).join(" "),
            onKeyDown: c,
            ref: e,
            children: t
        })
    });
}
function Ps({ buttonAriaLabel: t, buttonClassName: e, children: o, disabled: r = !1, dropdownKey: n, Icon: l, itemsContainerClassNames: i, label: s, stopCloseOnClickSelf: d }) {
    let c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [a, m] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), p = ()=>{
        m(!1), u?.current != null && u.current.focus();
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let h = u.current, x = c.current;
        if (a && h !== null && x !== null) {
            let { left: w, top: E } = h.getBoundingClientRect(), N = window.scrollY || document.documentElement.scrollTop;
            x.style.top = `${E + N + h.offsetHeight + 5}px`, x.style.left = `${Math.min(w - 5, window.innerWidth - x.offsetWidth - 20)}px`;
        }
    }, [
        c,
        u,
        a
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let h = u.current;
        if (h !== null && a) {
            let x = (w)=>{
                let E = w.target;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDOMNode"])(E) && (d && c.current && c.current.contains(E) || h.contains(E) || m(!1));
            };
            return document.addEventListener("click", x), ()=>{
                document.removeEventListener("click", x);
            };
        }
    }, [
        c,
        u,
        a,
        d
    ]);
    let f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(O1, {
        dropDownRef: c,
        itemsContainerClassNames: i,
        onClose: p,
        children: o
    }), document.body);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("button", {
                "aria-label": t,
                className: e + (a ? " active" : ""),
                "data-dropdown-key": n,
                disabled: r,
                onClick: (h)=>{
                    h.preventDefault(), m(!a);
                },
                onMouseDown: (h)=>{
                    h.preventDefault();
                },
                ref: u,
                type: "button",
                children: [
                    l && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(l, {}),
                    s && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                        className: "toolbar-popup__dropdown-label",
                        children: s
                    }),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("i", {
                        className: "toolbar-popup__dropdown-caret"
                    })
                ]
            }),
            a && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                children: f
            })
        ]
    });
}
var Rr = "toolbar-popup__dropdown", V1 = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14), { active: o, anchorElem: r, editor: n, enabled: l, item: i } = t, { i18n: s } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__["useTranslation"])(), { fieldProps: d } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), { featureClientSchemaMap: c, schemaPath: u } = d;
    if (i.Component) {
        let m;
        return e[0] !== o || e[1] !== r || e[2] !== n || e[3] !== l || e[4] !== i ? (m = i?.Component && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(i.Component, {
            active: o,
            anchorElem: r,
            editor: n,
            enabled: l,
            item: i
        }, i.key), e[0] = o, e[1] = r, e[2] = n, e[3] = l, e[4] = i, e[5] = m) : m = e[5], m;
    }
    let a;
    if (e[6] !== o || e[7] !== n || e[8] !== l || e[9] !== c || e[10] !== s || e[11] !== i || e[12] !== u) {
        let m = i.key, p;
        i.label && (m = typeof i.label == "function" ? i.label({
            featureClientSchemaMap: c,
            i18n: s,
            schemaPath: u
        }) : i.label), m.length > 25 ? p = m.substring(0, 25) + "..." : p = m, a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Fs, {
            active: o,
            editor: n,
            enabled: l,
            Icon: i?.ChildComponent ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(i.ChildComponent, {}) : void 0,
            item: i,
            itemKey: i.key,
            tooltip: m,
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                className: "text",
                children: p
            })
        }, i.key), e[6] = o, e[7] = n, e[8] = l, e[9] = c, e[10] = s, e[11] = i, e[12] = u, e[13] = a;
    } else a = e[13];
    return a;
}, K1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(V1), Ue = ({ anchorElem: t, classNames: e, editor: o, group: r, Icon: n, itemsContainerClassNames: l, label: i, maxActiveItems: s, onActiveChange: d })=>{
    let [c, u] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState({
        activeItemKeys: [],
        enabledGroup: !0,
        enabledItemKeys: []
    }), a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeferredValue"])(c), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), { items: p, key: f } = r, h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["e"])(), x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        o.getEditorState().read(()=>{
            let E = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
            if (!E) return;
            let N = [], _ = [], C = [];
            for (let g of p)g.isActive && (!s || N.length < s) && g.isActive({
                editor: o,
                editorConfigContext: m,
                selection: E
            }) && (N.push(g.key), _.push(g)), g.isEnabled ? g.isEnabled({
                editor: o,
                editorConfigContext: m,
                selection: E
            }) && C.push(g.key) : C.push(g.key);
            u({
                activeItemKeys: N,
                enabledGroup: r.isEnabled ? r.isEnabled({
                    editor: o,
                    editorConfigContext: m,
                    selection: E
                }) : !0,
                enabledItemKeys: C
            }), d && d({
                activeItems: _
            });
        });
    }, [
        o,
        m,
        r,
        p,
        s,
        d
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>(h(x), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(o.registerUpdateListener(async ()=>{
            await h(x);
        }))), [
        o,
        h,
        x
    ]);
    let w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>p?.length ? p.map((E)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(K1, {
                active: a.activeItemKeys.includes(E.key),
                anchorElem: t,
                editor: o,
                enabled: a.enabledItemKeys.includes(E.key),
                item: E
            }, E.key)) : null, [
        p,
        a,
        t,
        o
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ps, {
        buttonAriaLabel: `${f} dropdown`,
        buttonClassName: [
            Rr,
            `${Rr}-${f}`,
            ...e || []
        ].filter(Boolean).join(" "),
        disabled: !a.enabledGroup,
        dropdownKey: f,
        Icon: n,
        itemsContainerClassNames: [
            `${Rr}-items`,
            ...l || []
        ],
        label: i,
        children: w
    }, f);
};
function Q1({ anchorElem: t, editor: e, item: o }) {
    return o.Component ? o?.Component && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(o.Component, {
        anchorElem: t,
        editor: e,
        item: o
    }, o.key) : o.ChildComponent ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ft, {
        editor: e,
        item: o,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(o.ChildComponent, {})
    }, o.key) : null;
}
function eh(t) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(23), { anchorElem: o, editor: r, editorConfig: n, group: l, index: i } = t, { i18n: s } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__["useTranslation"])(), { fieldProps: d } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), { featureClientSchemaMap: c, schemaPath: u } = d, [a, m] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](void 0), [p, f] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](void 0), h;
    e[0] !== l.ChildComponent || e[1] !== l.items || e[2] !== l.type ? (h = ()=>{
        l?.type === "dropdown" && l.items.length && l.ChildComponent ? f(()=>l.ChildComponent) : f(void 0);
    }, e[0] = l.ChildComponent, e[1] = l.items, e[2] = l.type, e[3] = h) : h = e[3];
    let x;
    e[4] !== l ? (x = [
        l
    ], e[4] = l, e[5] = x) : x = e[5], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](h, x);
    let w;
    e[6] !== c || e[7] !== l.ChildComponent || e[8] !== l.items || e[9] !== l.type || e[10] !== s || e[11] !== u ? (w = (C)=>{
        let { activeItems: g } = C;
        if (!g.length) {
            l?.type === "dropdown" && l.items.length && l.ChildComponent ? (f(()=>l.ChildComponent), m(void 0)) : (f(void 0), m(void 0));
            return;
        }
        let b = g[0], k = b.key;
        b.label && (k = typeof b.label == "function" ? b.label({
            featureClientSchemaMap: c,
            i18n: s,
            schemaPath: u
        }) : b.label), k.length > 25 && (k = k.substring(0, 25) + "..."), g.length === 1 ? (m(k), f(()=>b.ChildComponent)) : (m(s.t("lexical:general:toolbarItemsActive", {
            count: g.length
        })), l?.type === "dropdown" && l.items.length && l.ChildComponent ? f(()=>l.ChildComponent) : f(void 0));
    }, e[6] = c, e[7] = l.ChildComponent, e[8] = l.items, e[9] = l.type, e[10] = s, e[11] = u, e[12] = w) : w = e[12];
    let E = w, N = `fixed-toolbar__group fixed-toolbar__group-${l.key}`, _;
    return e[13] !== p || e[14] !== o || e[15] !== a || e[16] !== r || e[17] !== n.features.toolbarFixed?.groups.length || e[18] !== l || e[19] !== i || e[20] !== E || e[21] !== N ? (_ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: N,
        "data-toolbar-group-key": l.key,
        children: [
            l.type === "dropdown" && l.items.length ? p ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ue, {
                anchorElem: o,
                editor: r,
                group: l,
                Icon: p,
                itemsContainerClassNames: [
                    "fixed-toolbar__dropdown-items"
                ],
                label: a,
                maxActiveItems: l.maxActiveItems ?? 1,
                onActiveChange: E
            }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ue, {
                anchorElem: o,
                editor: r,
                group: l,
                itemsContainerClassNames: [
                    "fixed-toolbar__dropdown-items"
                ],
                label: a,
                maxActiveItems: l.maxActiveItems ?? 1,
                onActiveChange: E
            }) : null,
            l.type === "buttons" && l.items.length ? l.items.map((C)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Q1, {
                    anchorElem: o,
                    editor: r,
                    item: C
                }, C.key)) : null,
            i < n.features.toolbarFixed?.groups.length - 1 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "divider"
            })
        ]
    }, l.key), e[13] = p, e[14] = o, e[15] = a, e[16] = r, e[17] = n.features.toolbarFixed?.groups.length, e[18] = l, e[19] = i, e[20] = E, e[21] = N, e[22] = _) : _ = e[22], _;
}
function th({ anchorElem: t, clientProps: e, editor: o, editorConfig: r, parentWithFixedToolbar: n }) {
    let l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), { y: s } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useScrollInfo"])(), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (!n || e?.disableIfParentHasFixedToolbar) return null;
        let u = n.editorContainerRef.current.previousElementSibling;
        for(; u;){
            if (u.classList.contains("fixed-toolbar")) return u;
            u = u.previousElementSibling;
        }
        return null;
    }, [
        e?.disableIfParentHasFixedToolbar,
        n
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useThrottledEffect"])(()=>{
        if (!d) return;
        let c = l.current;
        if (!c) return;
        let u = c.getBoundingClientRect(), a = d.getBoundingClientRect();
        if (!(u.bottom < a.top || u.top > a.bottom)) c.classList.remove("fixed-toolbar"), c.classList.add("fixed-toolbar", "fixed-toolbar--overlapping"), d.classList.remove("fixed-toolbar"), d.classList.add("fixed-toolbar", "fixed-toolbar--hide");
        else {
            if (!c.classList.contains("fixed-toolbar--overlapping")) return;
            c.classList.remove("fixed-toolbar--overlapping"), c.classList.add("fixed-toolbar"), d.classList.remove("fixed-toolbar--hide"), d.classList.add("fixed-toolbar");
        }
    }, 50, [
        l,
        d,
        s
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "fixed-toolbar",
        onFocus: (c)=>{
            c.stopPropagation();
        },
        ref: l,
        children: i && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: r?.features && r.features?.toolbarFixed?.groups.map((c, u)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(eh, {
                    anchorElem: t,
                    editor: o,
                    editorConfig: r,
                    group: c,
                    index: u
                }, c.key))
        })
    });
}
var Us = (t)=>{
    if (t.parentEditor?.editorConfig) {
        if (t.parentEditor?.editorConfig.resolvedFeatureMap.has("toolbarFixed")) return t.parentEditor;
        if (t.parentEditor) return Us(t.parentEditor);
    }
    return !1;
}, Ws = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6), { clientProps: o } = t, [r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])();
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])()) return null;
    let { editorConfig: i } = n, s = o.applyToFocusedEditor && n.focusedEditor?.editor || r, d = o.applyToFocusedEditor && n.focusedEditor?.editorConfig || i, c, u;
    if (e[0] !== o.disableIfParentHasFixedToolbar || e[1] !== s || e[2] !== d || e[3] !== n) {
        u = Symbol.for("react.early_return_sentinel");
        e: {
            let a = Us(n);
            if (o?.disableIfParentHasFixedToolbar && a) {
                u = null;
                break e;
            }
            if (!d?.features?.toolbarFixed?.groups?.length) {
                u = null;
                break e;
            }
            c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(th, {
                anchorElem: document.body,
                editor: s,
                editorConfig: d,
                parentWithFixedToolbar: a
            });
        }
        e[0] = o.disableIfParentHasFixedToolbar, e[1] = s, e[2] = d, e[3] = n, e[4] = c, e[5] = u;
    } else c = e[4], u = e[5];
    return u !== Symbol.for("react.early_return_sentinel") ? u : c;
};
var oh = $({
    plugins: [
        {
            Component: Ws,
            position: "aboveContainer"
        }
    ]
});
;
;
;
;
;
;
;
;
;
function Ir(t, e) {
    let o = t.getRangeAt(0), r;
    if (t.anchorNode === e) {
        let n = e;
        for(; n.firstElementChild != null;)n = n.firstElementChild;
        r = n.getBoundingClientRect();
    } else r = o.getBoundingClientRect();
    return r;
}
function _o(t) {
    let { alwaysDisplayOnTop: e = !1, anchorElem: o, anchorFlippedOffset: r = 0, floatingElem: n, horizontalOffset: l = 32, horizontalPosition: i = "left", specialHandlingForCaret: s = !1, targetRect: d, verticalGap: c = 10 } = t, u = o.parentElement;
    if (d === null || u == null) {
        n.style.opacity = "0", n.style.transform = "translate(-10000px, -10000px)";
        return;
    }
    let a = n.getBoundingClientRect(), m = o.getBoundingClientRect(), p = u.getBoundingClientRect(), f = d.top - a.height - c, h = d.left - l;
    i === "center" && (h = d.left + d.width / 2 - a.width / 2);
    let x = 0;
    return !e && f < p.top && !s && (x = a.height + d.height + c * 2, f += x), i === "center" ? h + a.width > p.right ? h = p.right - a.width - l : h < p.left && (h = p.left + l) : h + a.width > p.right && (h = p.right - a.width - l), h -= m.left, n.style.opacity = "1", s && r !== 0 ? (f -= m.bottom - r + a.height - 3, n.style.transform = `translate(${h}px, ${f}px) rotate(180deg)`) : (f -= m.top, n.style.transform = `translate(${h}px, ${f}px)`), x;
}
function uh({ anchorElem: t, editor: e, item: o }) {
    return o.Component ? o?.Component && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(o.Component, {
        anchorElem: t,
        editor: e,
        item: o
    }, o.key) : o.ChildComponent ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ft, {
        editor: e,
        item: o,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(o.ChildComponent, {})
    }, o.key) : null;
}
function dh(t) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19), { anchorElem: o, editor: r, group: n, index: l } = t, { editorConfig: i } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), [s, d] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](), c;
    e[0] !== n.ChildComponent || e[1] !== n.items || e[2] !== n.type ? (c = ()=>{
        n?.type === "dropdown" && n.items.length && n.ChildComponent ? d(()=>n.ChildComponent) : d(void 0);
    }, e[0] = n.ChildComponent, e[1] = n.items, e[2] = n.type, e[3] = c) : c = e[3];
    let u;
    e[4] !== n ? (u = [
        n
    ], e[4] = n, e[5] = u) : u = e[5], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](c, u);
    let a;
    e[6] !== n.ChildComponent || e[7] !== n.items || e[8] !== n.type ? (a = (h)=>{
        let { activeItems: x } = h;
        if (!x.length) {
            n?.type === "dropdown" && n.items.length && n.ChildComponent ? d(()=>n.ChildComponent) : d(void 0);
            return;
        }
        let w = x[0];
        d(()=>w?.ChildComponent);
    }, e[6] = n.ChildComponent, e[7] = n.items, e[8] = n.type, e[9] = a) : a = e[9];
    let m = a, p = `inline-toolbar-popup__group inline-toolbar-popup__group-${n.key}`, f;
    return e[10] !== s || e[11] !== o || e[12] !== r || e[13] !== i.features.toolbarInline?.groups.length || e[14] !== n || e[15] !== l || e[16] !== m || e[17] !== p ? (f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: p,
        "data-toolbar-group-key": n.key,
        children: [
            n.type === "dropdown" && n.items.length ? s ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ue, {
                anchorElem: o,
                editor: r,
                group: n,
                Icon: s,
                maxActiveItems: n.maxActiveItems ?? 1,
                onActiveChange: m
            }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ue, {
                anchorElem: o,
                editor: r,
                group: n,
                maxActiveItems: n.maxActiveItems ?? 1,
                onActiveChange: m
            }) : null,
            n.type === "buttons" && n.items.length ? n.items.map((h)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(uh, {
                    anchorElem: o,
                    editor: r,
                    item: h
                }, h.key)) : null,
            l < i.features.toolbarInline?.groups.length - 1 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "divider"
            })
        ]
    }, n.key), e[10] = s, e[11] = o, e[12] = r, e[13] = i.features.toolbarInline?.groups.length, e[14] = n, e[15] = l, e[16] = m, e[17] = p, e[18] = f) : f = e[18], f;
}
function mh({ anchorElem: t, editor: e }) {
    let o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), { editorConfig: n } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if (o?.current) {
            let c = o.current.style.opacity === "0", u = o.current.style.pointerEvents === "none";
            c || (o.current.style.opacity = "0"), u || (o.current.style.pointerEvents = "none");
        }
    }, [
        o
    ]), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((c)=>{
        if (o?.current && (c.buttons === 1 || c.buttons === 3)) {
            let u = o.current.style.opacity === "0", a = o.current.style.pointerEvents === "none";
            if (!u || !a) {
                let m = c.clientX, p = c.clientY, f = document.elementFromPoint(m, p);
                o.current.contains(f) || l();
            }
        }
    }, [
        l
    ]), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        o?.current && (o.current.style.opacity !== "1" && (o.current.style.opacity = "1"), o.current.style.pointerEvents !== "auto" && (o.current.style.pointerEvents = "auto"));
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>(document.addEventListener("mousemove", i), document.addEventListener("mouseup", s), ()=>{
            document.removeEventListener("mousemove", i), document.removeEventListener("mouseup", s);
        }), [
        o,
        i,
        s
    ]);
    let d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        let c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])(), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDOMSelection"])(e._window);
        if (o.current === null) return;
        let a = t.querySelector(":scope > .link-editor"), m = a !== null && "style" in a && a?.style?.opacity === "1", p = e.getRootElement();
        if (c !== null && u !== null && !u.isCollapsed && p !== null && p.contains(u.anchorNode)) {
            let f = Ir(u, p), h = _o({
                alwaysDisplayOnTop: m,
                anchorElem: t,
                floatingElem: o.current,
                horizontalPosition: "center",
                targetRect: f
            });
            r.current && _o({
                anchorElem: o.current,
                anchorFlippedOffset: h,
                floatingElem: r.current,
                horizontalOffset: 5,
                horizontalPosition: "center",
                specialHandlingForCaret: !0,
                targetRect: f,
                verticalGap: 8
            });
        } else l();
    }, [
        e,
        l,
        t
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let c = t.parentElement, u = ()=>{
            e.getEditorState().read(()=>{
                d();
            });
        };
        return window.addEventListener("resize", u), c && c.addEventListener("scroll", u), ()=>{
            window.removeEventListener("resize", u), c && c.removeEventListener("scroll", u);
        };
    }, [
        e,
        d,
        t
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>(e.getEditorState().read(()=>{
            d();
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(e.registerUpdateListener(({ editorState: c })=>{
            c.read(()=>{
                d();
            });
        }), e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SELECTION_CHANGE_COMMAND"], ()=>(d(), !1), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]))), [
        e,
        d
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: "inline-toolbar-popup",
        ref: o,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                className: "caret",
                ref: r
            }),
            n?.features && n.features?.toolbarInline?.groups.map((c, u)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(dh, {
                    anchorElem: t,
                    editor: e,
                    group: c,
                    index: u
                }, c.key))
        ]
    });
}
function ph(t, e) {
    let o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12), [r, n] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), i;
    o[0] !== t ? (i = ()=>{
        t.getEditorState().read(()=>{
            if (t.isComposing()) return;
            let p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])(), f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDOMSelection"])(t._window), h = t.getRootElement();
            if (f !== null && (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(p) || h === null || !h.contains(f.anchorNode))) {
                n(!1);
                return;
            }
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(p)) return;
            if (p.getTextContent() !== "") {
                let w = p.getNodes(), E = !1;
                for (let N of w)if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(N)) {
                    n(!0), E = !0;
                    break;
                }
                E || n(!1);
            } else n(!1);
            let x = p.getTextContent().replace(/\n/g, "");
            if (!p.isCollapsed() && x === "") {
                n(!1);
                return;
            }
        });
    }, o[0] = t, o[1] = i) : i = o[1];
    let s = i, d, c;
    o[2] !== s ? (d = ()=>(document.addEventListener("selectionchange", s), document.addEventListener("mouseup", s), ()=>{
            document.removeEventListener("selectionchange", s), document.removeEventListener("mouseup", s);
        }), c = [
        s
    ], o[2] = s, o[3] = d, o[4] = c) : (d = o[3], c = o[4]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(d, c);
    let u, a;
    if (o[5] !== t || o[6] !== s ? (u = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(t.registerUpdateListener(()=>{
            s();
        }), t.registerRootListener(()=>{
            t.getRootElement() === null && n(!1);
        })), a = [
        t,
        s
    ], o[5] = t, o[6] = s, o[7] = u, o[8] = a) : (u = o[7], a = o[8]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(u, a), !r || !l) return null;
    let m;
    return o[9] !== e || o[10] !== t ? (m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(mh, {
        anchorElem: e,
        editor: t
    }), e), o[9] = e, o[10] = t, o[11] = m) : m = o[11], m;
}
var Ys = (t)=>{
    let { anchorElem: e } = t, [o] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])();
    return ph(o, e);
};
var fh = $({
    plugins: [
        {
            Component: Ys,
            position: "floatingAnchorElem"
        }
    ]
});
;
;
;
var vr = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        className: "icon",
        fill: "none",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            clipRule: "evenodd",
            d: "M5.33333 4.5C4.8731 4.5 4.5 4.8731 4.5 5.33333V7.5H9.5V4.5H5.33333ZM5.33333 3.5C4.32081 3.5 3.5 4.32081 3.5 5.33333V14.6667C3.5 15.6792 4.32081 16.5 5.33333 16.5H14.6667C15.6792 16.5 16.5 15.6792 16.5 14.6667V5.33333C16.5 4.32081 15.6792 3.5 14.6667 3.5H5.33333ZM10.5 4.5V7.5H15.5V5.33333C15.5 4.8731 15.1269 4.5 14.6667 4.5H10.5ZM15.5 8.5H10.5V11.5H15.5V8.5ZM15.5 12.5H10.5V15.5H14.6667C15.1269 15.5 15.5 15.1269 15.5 14.6667V12.5ZM9.5 15.5V12.5H4.5V14.6667C4.5 15.1269 4.8731 15.5 5.33333 15.5H9.5ZM4.5 11.5H9.5V8.5H4.5V11.5Z",
            fill: "currentColor",
            fillRule: "evenodd"
        })
    });
;
;
var ta = /^\|(.+)\|\s?$/, wh = /^(\| ?:?-*:? ?)+\|\s?$/, oa = ({ allTransformers: t })=>({
        type: "element",
        dependencies: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableNode"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRowNode"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellNode"]
        ],
        export: (e)=>{
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableNode"])(e)) return null;
            let o = [];
            for (let r of e.getChildren()){
                let n = [];
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableRowNode"])(r)) continue;
                let l = !1;
                for (let i of r.getChildren())(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableCellNode"])(i) && (n.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(t, i).replace(/\n/g, "\\n").trim()), i.__headerState === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].ROW && (l = !0));
                o.push(`| ${n.join(" | ")} |`), l && o.push(`| ${n.map((i)=>"---").join(" | ")} |`);
            }
            return o.join(`
`);
        },
        regExp: ta,
        replace: (e, o, r)=>{
            let n = r[0];
            if (!n) return;
            if (wh.test(n)) {
                let a = e.getPreviousSibling();
                if (!a || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableNode"])(a)) return;
                let m = a.getChildren(), p = m[m.length - 1];
                if (!p || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableRowNode"])(p)) return;
                p.getChildren().forEach((f)=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableCellNode"])(f) && f.setHeaderStyles(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].ROW, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].ROW);
                }), e.remove();
                return;
            }
            let l = ea(n, t);
            if (l == null) return;
            let i = [
                l
            ], s = e.getPreviousSibling(), d = l.length;
            for(; s && !(!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isParagraphNode"])(s) || s.getChildrenSize() !== 1);){
                let a = s.getFirstChild();
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(a)) break;
                let m = ea(a.getTextContent(), t);
                if (m == null) break;
                d = Math.max(d, m.length), i.unshift(m);
                let p = s.getPreviousSibling();
                s.remove(), s = p;
            }
            let c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTableNode"])();
            for (let a of i){
                let m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTableRowNode"])();
                c.append(m);
                for(let p = 0; p < d; p++)m.append(p < a.length ? a[p] : ra("", t));
            }
            let u = e.getPreviousSibling();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableNode"])(u) && Eh(u) === d ? (u.append(...c.getChildren()), e.remove()) : e.replace(c), c.selectEnd();
        }
    });
function Eh(t) {
    let e = t.getFirstChild();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableRowNode"])(e) ? e.getChildrenSize() : 0;
}
var ra = (t, e)=>{
    t = t.replace(/\\n/g, `
`);
    let o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createTableCellNode"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].NO_STATUS);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(t, e, o), o;
}, ea = (t, e)=>{
    let o = t.match(ta);
    return !o || !o[1] ? null : o[1].split("|").map((r)=>ra(r, e));
};
;
;
;
;
;
;
;
;
;
;
;
;
;
var na = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        fill: "none",
        height: "18",
        viewBox: "0 0 20 20",
        width: "18",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M5 11C5.55228 11 6 10.5523 6 10C6 9.44772 5.55228 9 5 9C4.44772 9 4 9.44772 4 10C4 10.5523 4.44772 11 5 11Z",
                fill: "currentColor"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M10 11C10.5523 11 11 10.5523 11 10C11 9.44772 10.5523 9 10 9C9.44772 9 9 9.44772 9 10C9 10.5523 9.44772 11 10 11Z",
                fill: "currentColor"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M15 11C15.5523 11 16 10.5523 16 10C16 9.44772 15.5523 9 15 9C14.4477 9 14 9.44772 14 10C14 10.5523 14.4477 11 15 11Z",
                fill: "currentColor"
            })
        ]
    });
function sa(t) {
    let e = t.getShape();
    return {
        columns: e.toX - e.fromX + 1,
        rows: e.toY - e.fromY + 1
    };
}
function Jh() {
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) && !t.isCollapsed() || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(t) && !t.anchor.is(t.focus) || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(t) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(t)) return !1;
    let [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeTriplet"])(t.anchor);
    return e.__colSpan > 1 || e.__rowSpan > 1;
}
function zh(t) {
    let e = t.getLastDescendant();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTextNode"])(e) ? e.select() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isElementNode"])(e) ? e.selectEnd() : e !== null && e.selectNext();
}
function Xh({ cellMerge: t, contextRef: e, onClose: o, setIsMenuOpen: r, tableCellNode: n }) {
    let [l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [s, d] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(n), [c, u] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        columns: 1,
        rows: 1
    }), [a, m] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [p, f] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), { y: h } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useScrollInfo"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>l.registerMutationListener(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellNode"], (T)=>{
            T.get(s.getKey()) === "updated" && l.getEditorState().read(()=>{
                d(s.getLatest());
            });
        }, {
            skipInitialization: !0
        }), [
        l,
        s
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        l.getEditorState().read(()=>{
            let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(T)) {
                let S = sa(T);
                u(sa(T)), m(S.columns > 1 || S.rows > 1);
            }
            f(Jh());
        });
    }, [
        l
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let T = e.current, S = i.current, I = l.getRootElement();
        if (T != null && S != null && I != null) {
            let A = I.getBoundingClientRect(), v = T.getBoundingClientRect();
            S.style.opacity = "1";
            let O = S.getBoundingClientRect(), D = 5, G = v.right + D;
            if (G + O.width > window.innerWidth || G + O.width > A.right) {
                let z = v.left - O.width - D;
                G = (z < 0 ? D : z) + window.pageXOffset;
            }
            S.style.left = `${G + window.pageXOffset}px`;
            let q = v.top;
            if (q + O.height > window.innerHeight) {
                let z = v.bottom - O.height;
                q = z < 0 ? D : z;
            }
            S.style.top = `${q}px`;
        }
    }, [
        e,
        i,
        l,
        h
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        function T(S) {
            i.current != null && e.current != null && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDOMNode"])(S.target) && !i.current.contains(S.target) && !e.current.contains(S.target) && r(!1);
        }
        return window.addEventListener("click", T), ()=>window.removeEventListener("click", T);
    }, [
        r,
        e
    ]);
    let x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        l.update(()=>{
            if (s.isAttached()) {
                let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(s), S = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTableElement"])(T, l.getElementByKey(T.getKey()));
                if (S === null) throw new Error("Expected to find tableElement in DOM");
                let I = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTableObserverFromTableElement"])(S);
                I !== null && I.$clearHighlight(), T.markDirty(), d(s.getLatest());
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$setSelection"])(null);
        });
    }, [
        l,
        s
    ]), w = ()=>{
        l.update(()=>{
            let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(T)) return;
            let I = T.getNodes().filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableCellNode"]), A = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$mergeCells"])(I);
            A && (zh(A), o());
        });
    }, E = ()=>{
        l.update(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$unmergeCell"])();
        });
    }, N = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((T)=>{
        l.update(()=>{
            for(let S = 0; S < c.rows; S++)(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$insertTableRowAtSelection"])(T);
            o();
        });
    }, [
        l,
        o,
        c.rows
    ]), _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((T)=>{
        l.update(()=>{
            for(let S = 0; S < c.columns; S++)(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$insertTableColumnAtSelection"])(T);
            o();
        });
    }, [
        l,
        o,
        c.columns
    ]), C = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        l.update(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$deleteTableRowAtSelection"])(), o();
        });
    }, [
        l,
        o
    ]), g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        l.update(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(s).remove(), x(), o();
        });
    }, [
        l,
        s,
        x,
        o
    ]), b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        l.update(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$deleteTableColumnAtSelection"])(), o();
        });
    }, [
        l,
        o
    ]), k = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        l.update(()=>{
            let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(s), S = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableRowIndexFromTableCellNode"])(s), [I] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$computeTableMapSkipCellCheck"])(T, null, null), A = new Set, v = s.getHeaderStyles() ^ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].ROW;
            if (I[S]) for(let O = 0; O < I[S].length; O++){
                let D = I[S][O];
                D?.cell && (A.has(D.cell) || (A.add(D.cell), D.cell.setHeaderStyles(v, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].ROW)));
            }
            x(), o();
        });
    }, [
        l,
        s,
        x,
        o
    ]), y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        l.update(()=>{
            let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(s), S = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableColumnIndexFromTableCellNode"])(s), [I] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$computeTableMapSkipCellCheck"])(T, null, null), A = new Set, v = s.getHeaderStyles() ^ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].COLUMN;
            if (I) for(let O = 0; O < I.length; O++){
                let D = I?.[O]?.[S];
                D?.cell && (A.has(D.cell) || (A.add(D.cell), D.cell.setHeaderStyles(v, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].COLUMN)));
            }
            x(), o();
        });
    }, [
        l,
        s,
        x,
        o
    ]), R = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        l.update(()=>{
            if (s.isAttached()) {
                let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(s);
                T && T.setRowStriping(!T.getRowStriping());
            }
            x(), o();
        });
    }, [
        l,
        s,
        x,
        o
    ]), M = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        l.update(()=>{
            if (s.isAttached()) {
                let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(s);
                T && T.setFrozenColumns(T.getFrozenColumns() === 0 ? 1 : 0);
            }
            x(), o();
        });
    }, [
        l,
        s,
        x,
        o
    ]), L = null;
    return t && (a ? L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
        className: "item",
        "data-test-id": "table-merge-cells",
        onClick: ()=>w(),
        type: "button",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            className: "text",
            children: "Merge cells"
        })
    }) : p && (L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
        className: "item",
        "data-test-id": "table-unmerge-cells",
        onClick: ()=>E(),
        type: "button",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            className: "text",
            children: "Unmerge cells"
        })
    }))), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        className: "table-action-menu-dropdown",
        onClick: (T)=>{
            T.stopPropagation();
        },
        ref: i,
        children: [
            L ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    L,
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("hr", {})
                ]
            }) : null,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-row-striping",
                onClick: ()=>R(),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                    className: "text",
                    children: "Toggle Row Striping"
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-freeze-first-column",
                onClick: ()=>M(),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                    className: "text",
                    children: "Toggle First Column Freeze"
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-insert-row-above",
                onClick: ()=>N(!1),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", {
                    className: "text",
                    children: [
                        "Insert ",
                        c.rows === 1 ? "row" : `${c.rows} rows`,
                        " above"
                    ]
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-insert-row-below",
                onClick: ()=>N(!0),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", {
                    className: "text",
                    children: [
                        "Insert ",
                        c.rows === 1 ? "row" : `${c.rows} rows`,
                        " below"
                    ]
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("hr", {}),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-insert-column-before",
                onClick: ()=>_(!1),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", {
                    className: "text",
                    children: [
                        "Insert ",
                        c.columns === 1 ? "column" : `${c.columns} columns`,
                        " ",
                        "left"
                    ]
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-insert-column-after",
                onClick: ()=>_(!0),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", {
                    className: "text",
                    children: [
                        "Insert ",
                        c.columns === 1 ? "column" : `${c.columns} columns`,
                        " ",
                        "right"
                    ]
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("hr", {}),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-delete-columns",
                onClick: ()=>b(),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                    className: "text",
                    children: "Delete column"
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-delete-rows",
                onClick: ()=>C(),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                    className: "text",
                    children: "Delete row"
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-delete",
                onClick: ()=>g(),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                    className: "text",
                    children: "Delete table"
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("hr", {}),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-row-header",
                onClick: ()=>k(),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", {
                    className: "text",
                    children: [
                        (s.__headerState & __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].ROW) === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].ROW ? "Remove" : "Add",
                        " ",
                        "row header"
                    ]
                })
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                className: "item",
                "data-test-id": "table-column-header",
                onClick: ()=>y(),
                type: "button",
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", {
                    className: "text",
                    children: [
                        (s.__headerState & __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].COLUMN) === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellHeaderStates"].COLUMN ? "Remove" : "Add",
                        " ",
                        "column header"
                    ]
                })
            })
        ]
    }), document.body);
}
function Zh({ anchorElem: t, cellMerge: e }) {
    let [o] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [l, i] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [s, d] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        let a = r.current, m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])(), p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDOMSelection"])(o._window), f = document.activeElement;
        function h() {
            a && (a.classList.remove("table-cell-action-button-container--active"), a.classList.add("table-cell-action-button-container--inactive")), d(null);
        }
        if (m == null || a == null) return h();
        let x = o.getRootElement(), w = null, E = null;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(m) && x !== null && p !== null && x.contains(p.anchorNode)) {
            let _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableCellNodeFromLexicalNode"])(m.anchor.getNode());
            if (_ == null || (E = o.getElementByKey(_.getKey()), E == null || !_.isAttached())) return h();
            let C = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(_), g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTableElement"])(C, o.getElementByKey(C.getKey()));
            if (g === null) throw new Error("TableActionMenu: Expected to find tableElement in DOM");
            w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTableObserverFromTableElement"])(g), d(_);
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableSelection"])(m)) {
            let _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableCellNodeFromLexicalNode"])(m.anchor.getNode());
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableCellNode"])(_)) throw new Error("TableSelection anchorNode must be a TableCellNode");
            let C = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(_), g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTableElement"])(C, o.getElementByKey(C.getKey()));
            if (g === null) throw new Error("TableActionMenu: Expected to find tableElement in DOM");
            w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTableObserverFromTableElement"])(g), E = o.getElementByKey(_.getKey());
        } else if (!f) return h();
        if (w === null || E === null) return h();
        let N = !w || !w.isSelecting;
        if (a.classList.toggle("table-cell-action-button-container--active", N), a.classList.toggle("table-cell-action-button-container--inactive", !N), N) {
            let _ = E.getBoundingClientRect(), C = t.getBoundingClientRect(), g = _.top - C.top, b = _.right - C.left;
            a.style.transform = `translate(${b}px, ${g}px)`;
        }
    }, [
        o,
        t
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let a, m = ()=>{
            a = void 0, o.getEditorState().read(c);
        }, p = ()=>(a === void 0 && (a = setTimeout(m, 0)), !1);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(o.registerUpdateListener(p), o.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SELECTION_CHANGE_COMMAND"], p, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_CRITICAL"]), o.registerRootListener((f, h)=>{
            h && h.removeEventListener("pointerup", p), f && (f.addEventListener("pointerup", p), p());
        }), ()=>clearTimeout(a));
    });
    let u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(s);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        u.current !== s && i(!1), u.current = s;
    }, [
        u,
        s
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "table-cell-action-button-container",
        ref: r,
        children: s != null && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                    className: "table-cell-action-button",
                    onClick: (a)=>{
                        a.stopPropagation(), i(!l);
                    },
                    ref: n,
                    type: "button",
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(na, {})
                }),
                l && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Xh, {
                    cellMerge: e,
                    contextRef: n,
                    onClose: ()=>i(!1),
                    setIsMenuOpen: i,
                    tableCellNode: s
                })
            ]
        })
    });
}
var da = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3), { anchorElem: o } = t, r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), n;
    return e[0] !== o || e[1] !== r ? (n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(r ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Zh, {
        anchorElem: o ?? document.body,
        cellMerge: !0
    }) : null, o ?? document.body), e[0] = o, e[1] = r, e[2] = n) : n = e[2], n;
};
;
;
;
;
;
;
;
;
;
;
var cg = 33, ga = 92;
function ug({ editor: t }) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [n, l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [d, c] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [u, a] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [m, p] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [f, h] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        a(null), e.current = null, h(null), s.current = null, r.current = null;
    }, []), w = (M)=>(M.buttons & 1) === 1;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let M = new Set;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(t.registerMutationListener(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableNode"], (L)=>{
            for (let [T, S] of L)S === "destroyed" ? M.delete(T) : M.add(T);
            l(M.size > 0);
        }), t.registerNodeTransform(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableNode"], (L)=>{
            if (L.getColWidths()) return L;
            let T = L.getColumnCount(), S = ga;
            return L.setColWidths(Array(T).fill(S)), L;
        }));
    }, [
        t
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!n) return;
        let M = (I)=>{
            let A = I.target;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(A)) {
                if (f) {
                    c({
                        x: I.clientX,
                        y: I.clientY
                    });
                    return;
                }
                if (p(w(I)), !(o.current && o.current.contains(A)) && e.current !== A) {
                    e.current = A;
                    let v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDOMCellFromTarget"])(A);
                    v && u !== v ? t.getEditorState().read(()=>{
                        let O = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNearestNodeFromDOMNode"])(v.elem);
                        if (!O) throw new Error("TableCellResizer: Table cell node not found.");
                        let D = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(O), G = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTableElement"])(D, t.getElementByKey(D.getKey()));
                        if (!G) throw new Error("TableCellResizer: Table element not found.");
                        e.current = A, r.current = G.getBoundingClientRect(), a(v);
                    }, {
                        editor: t
                    }) : v == null && x();
                }
            }
        }, L = (I)=>{
            p(!0);
        }, T = (I)=>{
            p(!1);
        }, S = t.registerRootListener((I, A)=>{
            A?.removeEventListener("mousemove", M), A?.removeEventListener("mousedown", L), A?.removeEventListener("mouseup", T), I?.addEventListener("mousemove", M), I?.addEventListener("mousedown", L), I?.addEventListener("mouseup", T);
        });
        return ()=>{
            S();
        };
    }, [
        u,
        f,
        t,
        n,
        x
    ]);
    let E = (M)=>M === "bottom", N = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((M)=>{
        if (!u) throw new Error("TableCellResizer: Expected active cell.");
        t.update(()=>{
            let L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNearestNodeFromDOMNode"])(u.elem);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableCellNode"])(L)) throw new Error("TableCellResizer: Table cell node not found.");
            let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(L), S = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableRowIndexFromTableCellNode"])(L), I = T.getChildren(), v = L.getColSpan() === T.getColumnCount() ? S : S + L.getRowSpan() - 1;
            if (v >= I.length || v < 0) throw new Error("Expected table cell to be inside of table row.");
            let O = I[v];
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableRowNode"])(O)) throw new Error("Expected table row");
            let D = O.getHeight();
            if (D === void 0) {
                let q = O.getChildren();
                D = Math.min(...q.map((z)=>_(z, t) ?? 1 / 0));
            }
            let G = Math.max(D + M, cg);
            O.setHeight(G);
        }, {
            tag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SKIP_SCROLL_INTO_VIEW_TAG"]
        });
    }, [
        u,
        t
    ]), _ = (M, L)=>L.getElementByKey(M.getKey())?.clientHeight, C = (M, L)=>{
        let T;
        return L.forEach((S)=>{
            S.forEach((I, A)=>{
                I.cell === M && (T = A);
            });
        }), T;
    }, g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((M)=>{
        if (!u) throw new Error("TableCellResizer: Expected active cell.");
        t.update(()=>{
            let L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNearestNodeFromDOMNode"])(u.elem);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableCellNode"])(L)) throw new Error("TableCellResizer: Table cell node not found.");
            let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableNodeFromLexicalNodeOrThrow"])(L), [S] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$computeTableMapSkipCellCheck"])(T, null, null), I = C(L, S);
            if (I === void 0) throw new Error("TableCellResizer: Table column not found.");
            let A = T.getColWidths();
            if (!A) return;
            let v = A[I];
            if (v === void 0) return;
            let O = [
                ...A
            ], D = Math.max(v + M, ga);
            O[I] = D, T.setColWidths(O);
        }, {
            tag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SKIP_SCROLL_INTO_VIEW_TAG"]
        });
    }, [
        u,
        t
    ]), b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((M)=>{
        let L = (T)=>{
            if (T.preventDefault(), T.stopPropagation(), !u) throw new Error("TableCellResizer: Expected active cell.");
            if (s.current) {
                let { x: S, y: I } = s.current;
                if (u === null) return;
                let A = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["calculateZoomLevel"])(T.target);
                if (E(M)) {
                    let v = (T.clientY - I) / A;
                    N(v);
                } else {
                    let v = (T.clientX - S) / A;
                    g(v);
                }
                x(), document.removeEventListener("mouseup", L);
            }
        };
        return L;
    }, [
        u,
        x,
        g,
        N
    ]), k = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((M)=>(L)=>{
            if (L.preventDefault(), L.stopPropagation(), !u) throw new Error("TableCellResizer: Expected active cell.");
            s.current = {
                x: L.clientX,
                y: L.clientY
            }, c(s.current), h(M), document.addEventListener("mouseup", b(M));
        }, [
        u,
        b
    ]), [y, R] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        bottom: null,
        left: null,
        right: null,
        top: null
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (u) {
            let { height: M, left: L, top: T, width: S } = u.elem.getBoundingClientRect(), I = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["calculateZoomLevel"])(u.elem), A = 10, v = {
                bottom: {
                    backgroundColor: "none",
                    cursor: "row-resize",
                    height: `${A}px`,
                    left: `${window.scrollX + L}px`,
                    top: `${window.scrollY + T + M - A / 2}px`,
                    width: `${S}px`
                },
                right: {
                    backgroundColor: "none",
                    cursor: "col-resize",
                    height: `${M}px`,
                    left: `${window.scrollX + L + S - A / 2}px`,
                    top: `${window.scrollY + T}px`,
                    width: `${A}px`
                }
            }, O = r.current;
            f && d && O && (E(f) ? (v[f].left = `${window.scrollX + O.left}px`, v[f].top = `${window.scrollY + d.y / I}px`, v[f].height = "3px", v[f].width = `${O.width}px`) : (v[f].top = `${window.scrollY + O.top}px`, v[f].left = `${window.scrollX + d.x / I}px`, v[f].width = "3px", v[f].height = `${O.height}px`), v[f].backgroundColor = "#adf"), R(v);
        } else R({
            bottom: null,
            left: null,
            right: null,
            top: null
        });
    }, [
        u,
        f,
        d
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref: o,
        children: u != null && !m && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                    className: `${i.editorConfig.lexical.theme.tableCellResizer} TableCellResizer__ui`,
                    onMouseDown: k("right"),
                    style: y.right || void 0
                }),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                    className: `${i.editorConfig.lexical.theme.tableCellResizer} TableCellResizer__ui`,
                    onMouseDown: k("bottom"),
                    style: y.bottom || void 0
                })
            ]
        })
    });
}
var Ca = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3), [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), r;
    return t[0] !== e || t[1] !== o ? (r = o ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ug, {
        editor: e
    }), document.body) : null, t[0] = e, t[1] = o, t[2] = r) : r = t[2], r;
};
;
;
;
;
;
;
;
;
;
;
;
;
var dg = "Expected a function", mg = Math.max, pg = Math.min;
function fg(t, e, o) {
    let r, n, l = 0, i, s = !1, d = !1, c, u, a, m = !0;
    if (typeof t != "function") throw new TypeError(dg);
    e = e || 0, typeof o == "object" && (s = !!o.leading, d = "maxWait" in o, c = d ? mg(o.maxWait || 0, e) : c, m = "trailing" in o ? !!o.trailing : m);
    function p(g) {
        let b = r, k = i;
        return r = i = void 0, l = g, u = t.apply(k, b), u;
    }
    function f(g) {
        return l = g, a = setTimeout(w, e), s ? p(g) : u;
    }
    function h(g) {
        let b = g - n, k = g - l, y = e - b;
        return d ? pg(y, c - k) : y;
    }
    function x(g) {
        let b = g - n, k = g - l;
        return n === void 0 || b >= e || b < 0 || d && k >= c;
    }
    function w() {
        let g = Date.now();
        if (x(g)) return E(g);
        a = setTimeout(w, h(g));
    }
    function E(g) {
        return a = void 0, m && r ? p(g) : (r = i = void 0, u);
    }
    function N() {
        a !== void 0 && clearTimeout(a), l = 0, r = n = i = a = void 0;
    }
    function _() {
        return a === void 0 ? u : E(Date.now());
    }
    function C() {
        let g = Date.now(), b = x(g);
        if (r = arguments, i = this, n = g, b) {
            if (a === void 0) return f(n);
            if (d) return clearTimeout(a), a = setTimeout(w, e), p(n);
        }
        return a === void 0 && (a = setTimeout(w, e)), u;
    }
    return C.cancel = N, C.flush = _, C;
}
var ba = fg;
function ka(t, e, o) {
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), l, i;
    r[0] !== t || r[1] !== o || r[2] !== e ? (l = ()=>(n.current = ba(t, e, {
            maxWait: o
        }), ()=>{
            n.current?.cancel();
        }), i = [
        t,
        e,
        o
    ], r[0] = t, r[1] = o, r[2] = e, r[3] = l, r[4] = i) : (l = r[3], i = r[4]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(l, i);
    let s;
    return r[5] === Symbol.for("react.memo_cache_sentinel") ? (s = (...c)=>{
        let u = c;
        n.current && n.current(...u);
    }, r[5] = s) : s = r[5], s;
}
var Sa = 20;
function Ag({ anchorElem: t }) {
    let [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), [n, l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [i, s] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [d, c] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [u, a] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({}), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Set), p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), f = ka((w)=>{
        let { isOutside: E, tableDOMNode: N } = Og(w, r.editorConfig?.lexical);
        if (E) {
            l(!1), s(!1);
            return;
        }
        if (!N) return;
        p.current = N;
        let _ = null, C = null, g = null;
        if (e.getEditorState().read(()=>{
            let v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNearestNodeFromDOMNode"])(N);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableCellNode"])(v)) {
                let O = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$findMatchingParent"])(v, (D)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableNode"])(D));
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isTableNode"])(O)) return;
                if (g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTableElement"])(O, e.getElementByKey(O.getKey())), g) {
                    let D = O.getChildrenSize(), G = O.getChildAtIndex(0)?.getChildrenSize(), q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableRowIndexFromTableCellNode"])(v), z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableColumnIndexFromTableCellNode"])(v);
                    q === D - 1 ? _ = v : z === G - 1 && (C = v);
                }
            }
        }, {
            editor: e
        }), !g) return;
        let b = g.parentElement;
        if (!b) return;
        let { bottom: k, height: y, left: R, right: M, width: L, y: T } = g.getBoundingClientRect(), S = !1;
        b && b.classList.contains("LexicalEditorTheme__tableScrollableWrapper") && (S = b.scrollWidth > b.clientWidth);
        let { left: I, y: A } = t.getBoundingClientRect();
        _ ? (s(!1), l(!0), a({
            height: Sa,
            left: S && b ? b.offsetLeft : R - I,
            top: k - A + 5,
            width: S && b ? b.offsetWidth : L
        })) : C && (s(!0), l(!1), a({
            height: y,
            left: M - I + 5,
            top: T - A,
            width: Sa
        }));
    }, 50, 250), h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>new ResizeObserver(()=>{
            l(!1), s(!1);
        }), []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (d) return document.addEventListener("mousemove", f), ()=>{
            l(!1), s(!1), document.removeEventListener("mousemove", f);
        };
    }, [
        d,
        f
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(e.registerMutationListener(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableNode"], (w)=>{
            e.getEditorState().read(()=>{
                let E = !1;
                for (let [N, _] of w)switch(_){
                    case "created":
                        {
                            m.current.add(N), E = !0;
                            break;
                        }
                    case "destroyed":
                        {
                            m.current.delete(N), E = !0;
                            break;
                        }
                    default:
                        break;
                }
                if (E) {
                    h.disconnect();
                    for (let N of m.current){
                        let { tableElement: _ } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getTableAndElementByKey"])(N);
                        h.observe(_);
                    }
                    c(m.current.size > 0);
                }
            }, {
                editor: e
            });
        }, {
            skipInitialization: !1
        })), [
        e,
        h
    ]);
    let x = (w)=>{
        e.update(()=>{
            p.current && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNearestNodeFromDOMNode"])(p.current)?.selectEnd(), w ? ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$insertTableRowAtSelection"])(), l(!1)) : ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$insertTableColumnAtSelection"])(), s(!1)));
        });
    };
    return o ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            n && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                "aria-label": "Add Row",
                className: r.editorConfig.lexical.theme.tableAddRows,
                onClick: ()=>x(!0),
                style: {
                    ...u
                },
                type: "button"
            }),
            i && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
                "aria-label": "Add Column",
                className: r.editorConfig.lexical.theme.tableAddColumns,
                onClick: ()=>x(!1),
                style: {
                    ...u
                },
                type: "button"
            })
        ]
    }) : null;
}
function Og(t, e) {
    let o = t.target;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(o)) {
        let r = o.closest(`td.${e.theme.tableCell}, th.${e.theme.tableCell}`);
        return {
            isOutside: !(r || o.closest(`button.${e.theme.tableAddRows}`) || o.closest(`button.${e.theme.tableAddColumns}`) || o.closest(`div.${e.theme.tableCellResizer}`)),
            tableDOMNode: r
        };
    } else return {
        isOutside: !0,
        tableDOMNode: null
    };
}
function La(t) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), { anchorElem: o } = t, r = o === void 0 ? document.body : o;
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])()) return null;
    let l;
    return e[0] !== r ? (l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ag, {
        anchorElem: r
    }), r), e[0] = r, e[1] = l) : l = e[1], l;
}
;
;
;
;
;
;
;
;
;
;
var Io = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("OPEN_EMBED_DRAWER_COMMAND"), Ra = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    cellEditorConfig: null,
    cellEditorPlugins: null,
    set: ()=>{}
});
function Ia({ children: t }) {
    let [e, o] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        cellEditorConfig: null,
        cellEditorPlugins: null
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ra, {
        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
                cellEditorConfig: e.cellEditorConfig,
                cellEditorPlugins: e.cellEditorPlugins,
                set: (r, n)=>{
                    o({
                        cellEditorConfig: r,
                        cellEditorPlugins: n
                    });
                }
            }), [
            e.cellEditorConfig,
            e.cellEditorPlugins
        ]),
        children: t
    });
}
var va = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16), [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["use"])(Ra), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEditDepth"])(), { fieldProps: n, uuid: l } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"])(), { schemaPath: i } = n, s = "lexical-table-create-" + l, d;
    t[0] !== r || t[1] !== s ? (d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["formatDrawerSlug"])({
        slug: s,
        depth: r
    }), t[0] = r, t[1] = s, t[2] = d) : d = t[2];
    let c = d, { toggleDrawer: u } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$INBEEENE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(c, !0), a;
    t[3] !== e || t[4] !== u ? (a = ()=>{
        if (!e.hasNodes([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableNode"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRowNode"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellNode"]
        ])) throw new Error("TablePlugin: TableNode, TableRowNode, or TableCellNode is not registered on editor");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(e.registerCommand(Io, ()=>{
            let h = null;
            return e.getEditorState().read(()=>{
                let x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])();
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(x) && (h = x);
            }), h && u(), !0;
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]));
    }, t[3] = e, t[4] = u, t[5] = a) : a = t[5];
    let m;
    t[6] !== o || t[7] !== e || t[8] !== u ? (m = [
        o,
        e,
        u
    ], t[6] = o, t[7] = e, t[8] = u, t[9] = m) : m = t[9], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(a, m);
    let p;
    t[10] !== e ? (p = (h, x)=>{
        !x.columns || !x.rows || e.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INSERT_TABLE_COMMAND"], {
            columns: String(x.columns),
            rows: String(x.rows)
        });
    }, t[10] = e, t[11] = p) : p = t[11];
    let f;
    return t[12] !== c || t[13] !== i || t[14] !== p ? (f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$O6XRT2H3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"], {
                drawerSlug: c,
                drawerTitle: "Create Table",
                featureKey: "experimental_table",
                handleDrawerSubmit: p,
                schemaPath: i,
                schemaPathSuffix: "fields"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalTablePlugin$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TablePlugin"], {
                hasCellBackgroundColor: !1,
                hasCellMerge: !0,
                hasHorizontalScroll: !0
            })
        ]
    }), t[12] = c, t[13] = i, t[14] = p, t[15] = f) : f = t[15], f;
};
var ix = $({
    markdownTransformers: [
        oa
    ],
    nodes: [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableCellNode"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$table$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$table$2f$LexicalTable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableRowNode"]
    ],
    plugins: [
        {
            Component: va,
            position: "normal"
        },
        {
            Component: Ca,
            position: "normal"
        },
        {
            Component: da,
            position: "floatingAnchorElem"
        },
        {
            Component: La,
            position: "floatingAnchorElem"
        }
    ],
    providers: [
        Ia
    ],
    slashMenu: {
        groups: [
            Z([
                {
                    Icon: vr,
                    key: "table",
                    keywords: [
                        "table"
                    ],
                    label: "Table",
                    onSelect: ({ editor: t })=>{
                        t.dispatchCommand(Io, {});
                    }
                }
            ])
        ]
    },
    toolbarFixed: {
        groups: [
            be([
                {
                    ChildComponent: vr,
                    key: "table",
                    label: "Table",
                    onSelect: ({ editor: t })=>{
                        t.dispatchCommand(Io, {});
                    }
                }
            ])
        ]
    }
});
;
;
;
var Vr = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        "aria-hidden": "true",
        className: "icon",
        fill: "none",
        focusable: "false",
        height: "20",
        viewBox: "0 0 20 20",
        width: "20",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M14.6667 4H5.33333C4.59695 4 4 4.59695 4 5.33333V14.6667C4 15.403 4.59695 16 5.33333 16H14.6667C15.403 16 16 15.403 16 14.6667V5.33333C16 4.59695 15.403 4 14.6667 4Z",
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M7.99984 9.33366C8.73622 9.33366 9.33317 8.73671 9.33317 8.00033C9.33317 7.26395 8.73622 6.66699 7.99984 6.66699C7.26346 6.66699 6.6665 7.26395 6.6665 8.00033C6.6665 8.73671 7.26346 9.33366 7.99984 9.33366Z",
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M16 11.9995L13.9427 9.94214C13.6926 9.69218 13.3536 9.55176 13 9.55176C12.6464 9.55176 12.3074 9.69218 12.0573 9.94214L6 15.9995",
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
;
;
;
;
;
function vo(t, e) {
    if (t.hasAttribute("data-lexical-pending-upload-form-id")) {
        let r = t.getAttribute("data-lexical-pending-upload-form-id");
        if (r != null) return {
            node: e({
                data: {
                    pending: {
                        formID: r,
                        src: t.getAttribute("src") || ""
                    }
                }
            })
        };
    }
    if (t.hasAttribute("data-lexical-upload-relation-to") && t.hasAttribute("data-lexical-upload-id")) {
        let r = t.getAttribute("data-lexical-upload-id"), n = t.getAttribute("data-lexical-upload-relation-to");
        if (r != null && n != null) return {
            node: e({
                data: {
                    fields: {},
                    relationTo: n,
                    value: r
                }
            })
        };
    }
    return {
        node: e({
            data: {
                pending: {
                    formID: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString(),
                    src: t.getAttribute("src") || ""
                }
            }
        })
    };
}
;
;
;
;
var Ht = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalDecoratorBlockNode$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecoratorBlockNode"] {
    __data;
    constructor({ data: e, format: o, key: r }){
        super(o, r), this.__data = e;
    }
    static clone(e) {
        return new this({
            data: e.__data,
            format: e.__format,
            key: e.__key
        });
    }
    static getType() {
        return "upload";
    }
    static importDOM() {
        return {
            img: (e)=>({
                    conversion: (o)=>vo(o, Ma),
                    priority: 0
                })
        };
    }
    static importJSON(e) {
        e.version === 1 && e?.value?.id && (e.value = e.value.id), e.version === 2 && !e?.id && (e.id = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString(), e.version = 3);
        let o = {
            id: e.id,
            fields: e.fields,
            pending: e.pending,
            relationTo: e.relationTo,
            value: e.value
        }, r = Ma({
            data: o
        });
        return r.setFormat(e.format), r;
    }
    static isInline() {
        return !1;
    }
    createDOM(e) {
        let o = document.createElement("div");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addClassNamesToElement"])(o, e?.theme?.upload), o;
    }
    decorate() {
        return null;
    }
    exportDOM() {
        let e = document.createElement("img"), o = this.__data;
        return o.pending ? (e.setAttribute("data-lexical-pending-upload-form-id", String(o?.pending?.formID)), e.setAttribute("src", o?.pending?.src || "")) : (e.setAttribute("data-lexical-upload-id", String(o?.value)), e.setAttribute("data-lexical-upload-relation-to", o?.relationTo)), {
            element: e
        };
    }
    exportJSON() {
        return {
            ...super.exportJSON(),
            ...this.getData(),
            type: "upload",
            version: 3
        };
    }
    getData() {
        return this.getLatest().__data;
    }
    setData(e) {
        let o = this.getWritable();
        o.__data = e;
    }
    updateDOM() {
        return !1;
    }
};
function Ma({ data: t }) {
    return t?.id || (t.id = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString()), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new Ht({
        data: t
    }));
}
;
;
var Aa = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: "lexical-upload",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__f__as__ShimmerEffect$3e$__["ShimmerEffect"], {
            height: "95px",
            width: "203px"
        })
    });
var fx = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"](()=>__turbopack_context__.A("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/component-YQ22OGQW.js [app-client] (ecmascript, async loader)").then((t)=>({
            default: t.UploadComponent
        }))), me = class extends Ht {
    static clone(e) {
        return super.clone(e);
    }
    static getType() {
        return super.getType();
    }
    static importDOM() {
        return {
            img: (e)=>({
                    conversion: (o)=>vo(o, pe),
                    priority: 0
                })
        };
    }
    static importJSON(e) {
        e.version === 1 && e?.value?.id && (e.value = e.value.id), e.version === 2 && !e?.id && (e.id = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString(), e.version = 3);
        let o = {
            id: e.id,
            fields: e.fields,
            pending: e.pending,
            relationTo: e.relationTo,
            value: e.value
        }, r = pe({
            data: o
        });
        return r.setFormat(e.format), r;
    }
    decorate(e, o) {
        return this.__data.pending ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Aa, {}) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(fx, {
            className: o?.theme?.upload ?? "LexicalEditorTheme__upload",
            data: this.__data,
            format: this.__format,
            nodeKey: this.getKey()
        });
    }
    exportJSON() {
        return super.exportJSON();
    }
};
function pe({ data: t }) {
    return t?.id || (t.id = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString()), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$applyNodeReplacement"])(new me({
        data: t
    }));
}
function ct(t) {
    return t instanceof me;
}
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var Cx = ({ editor: t, relationTo: e, replaceNodeKey: o, value: r })=>{
    o ? t.update(()=>{
        let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getNodeByKey"])(o);
        n && n.replace(pe({
            data: {
                fields: null,
                relationTo: e,
                value: r
            }
        }));
    }) : t.dispatchCommand(Jr, {
        fields: null,
        relationTo: e,
        value: r
    });
}, bx = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13), { enabledCollectionSlugs: o } = t, [r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), [n, l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), i;
    e[0] !== o ? (i = {
        collectionSlugs: o,
        uploads: !0
    }, e[0] = o, e[1] = i) : i = e[1];
    let { closeListDrawer: s, ListDrawer: d, openListDrawer: c } = Ot(i), u, a;
    e[2] !== r || e[3] !== c ? (u = ()=>r.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$O6XRT2H3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"], (h)=>(l(h?.replace ? h?.replace.nodeKey : null), c(), !0), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), a = [
        r,
        c
    ], e[2] = r, e[3] = c, e[4] = u, e[5] = a) : (u = e[4], a = e[5]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(u, a);
    let m;
    e[6] !== s || e[7] !== r || e[8] !== n ? (m = (h)=>{
        let { collectionSlug: x, doc: w } = h;
        s(), Cx({
            editor: r,
            relationTo: x,
            replaceNodeKey: n,
            value: w.id
        });
    }, e[6] = s, e[7] = r, e[8] = n, e[9] = m) : m = e[9];
    let p = m, f;
    return e[10] !== d || e[11] !== p ? (f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(d, {
        onSelect: p
    }), e[10] = d, e[11] = p, e[12] = f) : f = e[12], f;
}, kx = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3), [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), o, r;
    return t[0] !== e ? (o = ()=>e.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$O6XRT2H3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"], _x, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), r = [
        e
    ], t[0] = e, t[1] = o, t[2] = r) : (o = t[1], r = t[2]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(o, r), null;
}, Wa = ({ enabledCollectionSlugs: t })=>t?.length ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(bx, {
        enabledCollectionSlugs: t
    }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(kx, {});
function _x() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toast"].error("No upload collections enabled"), !0;
}
function Fx(t) {
    let e = t.target;
    return !!((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(e) && !e.closest("code, span.editor-image") && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(e.parentElement) && e.parentElement.closest("div.ContentEditable__root"));
}
function Px(t) {
    let e, o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDOMSelectionFromTarget"])(t.target);
    if (document.caretRangeFromPoint) e = document.caretRangeFromPoint(t.clientX, t.clientY);
    else if (t.rangeParent && o !== null) o.collapse(t.rangeParent, t.rangeOffset || 0), e = o.getRangeAt(0);
    else throw Error("Cannot get the selection when dragging");
    return e;
}
var Jr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCommand"])("INSERT_UPLOAD_COMMAND"), Za = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21), { clientProps: o } = t, [r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$LexicalComposerContext$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalComposerContext"])(), n = o?.disabledCollections, l = o?.enabledCollections, i;
    e[0] !== n || e[1] !== l ? (i = {
        collectionSlugsBlacklist: n,
        collectionSlugsWhitelist: l,
        uploads: !0
    }, e[0] = n, e[1] = l, e[2] = i) : i = e[2];
    let { enabledCollectionSlugs: s } = Co(i), { drawerSlug: d, setCollectionSlug: c, setInitialForms: u, setOnCancel: a, setOnSuccess: m, setSelectableCollections: p } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useBulkUpload"])(), { isModalOpen: f, openModal: h } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useModal"])(), x;
    e[3] !== d || e[4] !== r || e[5] !== s || e[6] !== f || e[7] !== h || e[8] !== c || e[9] !== u || e[10] !== a || e[11] !== m || e[12] !== p ? (x = (C)=>{
        let { files: g } = C;
        if (g?.length !== 0 && (u((b)=>[
                ...b ?? [],
                ...g.map(Bx)
            ]), !f(d))) {
            if (!s.length || !s[0]) return;
            c(s[0]), p(s), a(()=>{
                r.update(jx);
            }), m((b)=>{
                let k = new Map(b.map(Hx));
                r.update(()=>{
                    for (let y of (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$dfsIterator"])()){
                        let R = y.node;
                        if (ct(R)) {
                            let M = R.getData();
                            if (M?.pending) {
                                let L = k.get(M.pending?.formID);
                                L && R.replace(pe({
                                    data: {
                                        id: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString(),
                                        fields: {},
                                        relationTo: L.collectionSlug,
                                        value: L.doc.id
                                    }
                                }));
                            }
                        }
                    }
                });
            }), h(d);
        }
    }, e[3] = d, e[4] = r, e[5] = s, e[6] = f, e[7] = h, e[8] = c, e[9] = u, e[10] = a, e[11] = m, e[12] = p, e[13] = x) : x = e[13];
    let w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEffectEvent"])(x), E;
    e[14] !== r || e[15] !== w ? (E = ()=>{
        if (!r.hasNodes([
            me
        ])) throw new Error("UploadPlugin: UploadNode not registered on editor");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeRegister"])(r.registerNodeTransform(me, (C)=>{
            let g = C.getData();
            if (!g?.pending) return;
            (async function() {
                let y = null, R = g?.pending?.src, M = g?.pending?.formID;
                if (R?.startsWith("data:")) {
                    let L = R.match(/data:(image\/[a-zA-Z]+);base64,/), T = L ? L[1] : "image/png", S = R.replace(/^data:image\/[a-zA-Z]+;base64,/, ""), I = atob(S), A = new Array(I.length);
                    for(let D = 0; D < I.length; D++)A[D] = I.charCodeAt(D);
                    let v = new Uint8Array(A);
                    y = {
                        alt: void 0,
                        file: new File([
                            v
                        ], "pasted-image." + T?.split("/", 2)[1], {
                            type: T
                        }),
                        formID: M
                    };
                } else if (R?.startsWith("http") || R?.startsWith("https")) {
                    let T = await (await fetch(R)).blob(), S = R.split("/").pop() || "pasted-image" + T.type.split("/", 2)[1];
                    y = {
                        alt: void 0,
                        file: new File([
                            T
                        ], S, {
                            type: T.type
                        }),
                        formID: M
                    };
                }
                y && w({
                    files: [
                        y
                    ]
                });
            })();
        }), r.registerCommand(Jr, (C)=>(r.update(()=>{
                let g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])() || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getPreviousSelection"])();
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(g)) {
                    let b = pe({
                        data: {
                            id: C.id,
                            fields: C.fields,
                            relationTo: C.relationTo,
                            value: C.value
                        }
                    }), { focus: k } = g, y = k.getNode();
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(b), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isParagraphNode"])(y) && !y.__first && y.remove();
                }
            }), !0), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_EDITOR"]), r.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PASTE_COMMAND"], (C)=>{
            if (!(C instanceof ClipboardEvent)) return !1;
            let g = C.clipboardData;
            if (!g?.types?.length || g?.types?.includes("text/html")) return !1;
            let b = [];
            return g?.files?.length && Array.from(g.files).forEach((k)=>{
                b.push({
                    alt: "",
                    file: k,
                    formID: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString()
                });
            }), b.length ? (r.update(()=>{
                let k = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getSelection"])() || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$getPreviousSelection"])();
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isRangeSelection"])(k)) for (let y of b){
                    let R = pe({
                        data: {
                            pending: {
                                formID: y.formID,
                                src: URL.createObjectURL(y.file)
                            }
                        }
                    }), { focus: M } = k, L = M.getNode();
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(R), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isParagraphNode"])(L) && !L.__first && L.remove();
                }
            }), w({
                files: b
            }), !0) : !1;
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]), r.registerCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROP_COMMAND"], (C)=>{
            if (!(C instanceof DragEvent)) return !1;
            let g = C.dataTransfer;
            if (!g?.types?.length) return !1;
            let b = [];
            return g?.files?.length && Array.from(g.files).forEach((k)=>{
                b.push({
                    alt: "",
                    file: k,
                    formID: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$bson$2d$objectid$40$2$2e$0$2e$4$2f$node_modules$2f$bson$2d$objectid$2f$objectid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].default().toHexString()
                });
            }), b.length ? (C.preventDefault(), C.stopPropagation(), r.update(()=>{
                if (Fx(C)) {
                    let k = Px(C), y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$createRangeSelection"])();
                    k != null && y.applyDOMRange(k), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$setSelection"])(y);
                    for (let R of b){
                        let M = pe({
                            data: {
                                pending: {
                                    formID: R.formID,
                                    src: URL.createObjectURL(R.file)
                                }
                            }
                        }), { focus: L } = y, T = L.getNode();
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$insertNodeToNearestRoot"])(M), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isParagraphNode"])(T) && !T.__first && T.remove();
                    }
                }
            }), w({
                files: b
            }), !0) : !1;
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMAND_PRIORITY_LOW"]));
    }, e[14] = r, e[15] = w, e[16] = E) : E = e[16];
    let N;
    e[17] !== r ? (N = [
        r
    ], e[17] = r, e[18] = N) : N = e[18], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(E, N);
    let _;
    return e[19] !== s ? (_ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Wa, {
        enabledCollectionSlugs: s
    }), e[19] = s, e[20] = _) : _ = e[20], _;
};
function Bx(t) {
    return {
        file: t.file,
        formID: t.formID
    };
}
function jx() {
    for (let t of (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$utils$40$0$2e$35$2e$0$2f$node_modules$2f40$lexical$2f$utils$2f$LexicalUtils$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$dfsIterator"])()){
        let e = t.node;
        ct(e) && e.getData()?.pending && e.remove();
    }
}
function Hx(t) {
    return [
        t.formID,
        t
    ];
}
var Wx = $({
    nodes: [
        me
    ],
    plugins: [
        {
            Component: Za,
            position: "normal"
        }
    ],
    slashMenu: {
        groups: [
            Z([
                {
                    Icon: Vr,
                    key: "upload",
                    keywords: [
                        "upload",
                        "image",
                        "file",
                        "img",
                        "picture",
                        "photo",
                        "media"
                    ],
                    label: ({ i18n: t })=>t.t("lexical:upload:label"),
                    onSelect: ({ editor: t })=>{
                        t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$O6XRT2H3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"], {
                            replace: !1
                        });
                    }
                }
            ])
        ]
    },
    toolbarFixed: {
        groups: [
            be([
                {
                    ChildComponent: Vr,
                    isActive: ({ selection: t })=>{
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lexical$40$0$2e$35$2e$0$2f$node_modules$2f$lexical$2f$Lexical$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$isNodeSelection"])(t) || !t.getNodes().length) return !1;
                        let e = t.getNodes()[0];
                        return ct(e);
                    },
                    key: "upload",
                    label: ({ i18n: t })=>t.t("lexical:upload:label"),
                    onSelect: ({ editor: t })=>{
                        t.dispatchCommand(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$O6XRT2H3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"], {
                            replace: !1
                        });
                    }
                }
            ])
        ]
    }
});
;
;
;
;
var Ya = {
    block: "LexicalEditorTheme__block",
    blockCursor: "LexicalEditorTheme__blockCursor",
    characterLimit: "LexicalEditorTheme__characterLimit",
    code: "LexicalEditorTheme__code",
    inlineBlock: "LexicalEditorTheme__inlineBlock",
    heading: {
        h1: "LexicalEditorTheme__h1",
        h2: "LexicalEditorTheme__h2",
        h3: "LexicalEditorTheme__h3",
        h4: "LexicalEditorTheme__h4",
        h5: "LexicalEditorTheme__h5",
        h6: "LexicalEditorTheme__h6"
    },
    hr: "LexicalEditorTheme__hr",
    hrSelected: "LexicalEditorTheme__hrSelected",
    indent: "LexicalEditorTheme__indent",
    link: "LexicalEditorTheme__link",
    list: {
        checklist: "LexicalEditorTheme__checklist",
        listitem: "LexicalEditorTheme__listItem",
        listitemChecked: "LexicalEditorTheme__listItemChecked",
        listitemUnchecked: "LexicalEditorTheme__listItemUnchecked",
        nested: {
            listitem: "LexicalEditorTheme__nestedListItem"
        },
        olDepth: [
            "LexicalEditorTheme__ol1",
            "LexicalEditorTheme__ol2",
            "LexicalEditorTheme__ol3",
            "LexicalEditorTheme__ol4",
            "LexicalEditorTheme__ol5"
        ],
        ul: "LexicalEditorTheme__ul"
    },
    ltr: "LexicalEditorTheme__ltr",
    mark: "LexicalEditorTheme__mark",
    markOverlap: "LexicalEditorTheme__markOverlap",
    paragraph: "LexicalEditorTheme__paragraph",
    placeholder: "LexicalEditorTheme__placeholder",
    quote: "LexicalEditorTheme__quote",
    relationship: "LexicalEditorTheme__relationship",
    rtl: "LexicalEditorTheme__rtl",
    tab: "LexicalEditorTheme__tabNode",
    table: "LexicalEditorTheme__table",
    tableAddColumns: "LexicalEditorTheme__tableAddColumns",
    tableAddRows: "LexicalEditorTheme__tableAddRows",
    tableAlignment: {
        center: "LexicalEditorTheme__tableAlignmentCenter",
        right: "LexicalEditorTheme__tableAlignmentRight"
    },
    tableCell: "LexicalEditorTheme__tableCell",
    tableCellActionButton: "LexicalEditorTheme__tableCellActionButton",
    tableCellActionButtonContainer: "LexicalEditorTheme__tableCellActionButtonContainer",
    tableCellHeader: "LexicalEditorTheme__tableCellHeader",
    tableCellResizer: "LexicalEditorTheme__tableCellResizer",
    tableCellSelected: "LexicalEditorTheme__tableCellSelected",
    tableFrozenColumn: "LexicalEditorTheme__tableFrozenColumn",
    tableRowStriping: "LexicalEditorTheme__tableRowStriping",
    tableScrollableWrapper: "LexicalEditorTheme__tableScrollableWrapper",
    tableSelected: "LexicalEditorTheme__tableSelected",
    tableSelection: "LexicalEditorTheme__tableSelection",
    text: {
        bold: "LexicalEditorTheme__textBold",
        code: "LexicalEditorTheme__textCode",
        italic: "LexicalEditorTheme__textItalic",
        strikethrough: "LexicalEditorTheme__textStrikethrough",
        subscript: "LexicalEditorTheme__textSubscript",
        superscript: "LexicalEditorTheme__textSuperscript",
        underline: "LexicalEditorTheme__textUnderline",
        underlineStrikethrough: "LexicalEditorTheme__textUnderlineStrikethrough"
    },
    upload: "LexicalEditorTheme__upload"
};
var Yr = {
    namespace: "lexical",
    theme: Ya
};
function qa({ config: t, featureClientImportMap: e, featureClientSchemaMap: o, field: r, schemaPath: n, unSanitizedEditorConfig: l }) {
    let i = new Map;
    for (let c of l.features){
        if (!c?.clientFeatureProps?.featureKey || c?.clientFeatureProps?.order === void 0 || c?.clientFeatureProps?.order === null) throw new Error("A Feature you have installed does not return the client props as clientFeatureProps. Please make sure to always return those props, even if they are null, as other important props like order and featureKey are later on injected.");
        i.set(c.clientFeatureProps.featureKey, c);
    }
    l.features = l.features.sort((c, u)=>c.clientFeatureProps.order - u.clientFeatureProps.order);
    let s = new Map, d = 0;
    for (let c of l.features){
        let u = typeof c.feature == "function" ? c.feature({
            config: t,
            featureClientImportMap: e,
            featureClientSchemaMap: o,
            featureProviderMap: i,
            field: r,
            resolvedFeatures: s,
            schemaPath: n,
            unSanitizedEditorConfig: l
        }) : c.feature;
        u.key = c.clientFeatureProps.featureKey, u.order = d, s.set(c.clientFeatureProps.featureKey, u), d++;
    }
    return s;
}
;
var Qa = (t)=>{
    let e = {
        enabledFeatures: [],
        enabledFormats: [],
        markdownTransformers: [],
        nodes: [],
        plugins: [],
        providers: [],
        slashMenu: {
            dynamicGroups: [],
            groups: []
        },
        toolbarFixed: {
            groups: []
        },
        toolbarInline: {
            groups: []
        }
    }, o = {};
    if (t.forEach((r)=>{
        r.key === "toolbarFixed" && r.sanitizedClientFeatureProps?.customGroups && (o = {
            ...o,
            ...r.sanitizedClientFeatureProps.customGroups
        });
    }), !t?.size) return e;
    t.forEach((r)=>{
        if (r.providers?.length && (e.providers = e.providers.concat(r.providers)), r.enableFormats?.length && e.enabledFormats.push(...r.enableFormats), r.nodes?.length) for (let n of r.nodes)e.nodes.push(n);
        if (r.plugins?.length && r.plugins.forEach((n, l)=>{
            e.plugins?.push({
                clientProps: r.sanitizedClientFeatureProps,
                Component: n.Component,
                key: r.key + l,
                position: n.position
            });
        }), r.toolbarInline?.groups?.length) for (let n of r.toolbarInline.groups){
            let l = e.toolbarInline.groups.find((i)=>i.key === n.key);
            l ? e.toolbarInline.groups = e.toolbarInline.groups.filter((i)=>i.key !== n.key) : l = {
                ...n,
                items: []
            }, n?.items?.length && (l.items = l.items.concat(n.items)), e.toolbarInline?.groups.push(l);
        }
        if (r.toolbarFixed?.groups?.length) for (let n of r.toolbarFixed.groups){
            let l = e.toolbarFixed.groups.find((i)=>i.key === n.key);
            l ? e.toolbarFixed.groups = e.toolbarFixed.groups.filter((i)=>i.key !== n.key) : l = {
                ...n,
                items: []
            }, n?.items?.length && (l.items = l.items.concat(n.items)), e.toolbarFixed?.groups.push(l);
        }
        if (r.slashMenu?.groups) {
            r.slashMenu.dynamicGroups?.length && (e.slashMenu.dynamicGroups = e.slashMenu.dynamicGroups.concat(r.slashMenu.dynamicGroups));
            for (let n of r.slashMenu.groups){
                let l = e.slashMenu.groups.find((i)=>i.key === n.key);
                l ? e.slashMenu.groups = e.slashMenu.groups.filter((i)=>i.key !== n.key) : l = {
                    ...n,
                    items: []
                }, n?.items?.length && (l.items = l.items.concat(n.items)), e.slashMenu.groups.push(l);
            }
        }
        if (r.markdownTransformers?.length) for (let n of r.markdownTransformers)typeof n == "function" ? e.markdownTransformers.push(n({
            allNodes: e.nodes,
            allTransformers: e.markdownTransformers
        })) : e.markdownTransformers.push(n);
        e.enabledFeatures.push(r.key);
    }), Object.keys(o).length > 0 && (e.toolbarFixed.groups = e.toolbarFixed.groups.map((r)=>{
        let n = o[r.key];
        return n ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$deepmerge$40$4$2e$3$2e$1$2f$node_modules$2f$deepmerge$2f$dist$2f$cjs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__deepMerge$3e$__["deepMerge"])(r, n) : r;
    })), e.toolbarInline.groups.sort((r, n)=>r.order && n.order ? r.order - n.order : r.order ? -1 : n.order ? 1 : 0), e.toolbarFixed.groups.sort((r, n)=>r.order && n.order ? r.order - n.order : r.order ? -1 : n.order ? 1 : 0);
    for (let r of e.toolbarInline.groups)r.items.sort((n, l)=>n.order && l.order ? n.order - l.order : n.order ? -1 : l.order ? 1 : 0);
    for (let r of e.toolbarFixed.groups)r.items.sort((n, l)=>n.order && l.order ? n.order - l.order : n.order ? -1 : l.order ? 1 : 0);
    return e;
};
function qr(t, e, o) {
    return {
        admin: o,
        features: Qa(t),
        lexical: e,
        resolvedFeatureMap: t
    };
}
var qx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/Field-2A2VQXKP.js [app-client] (ecmascript, async loader)").then((t)=>({
            default: t.RichText
        }))), Qx = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18), { admin: o, clientFeatures: r, featureClientImportMap: n, featureClientSchemaMap: l, field: i, lexicalEditorConfig: s, schemaPath: d } = t, c;
    e[0] !== o ? (c = o === void 0 ? {} : o, e[0] = o, e[1] = c) : c = e[1];
    let u = c, a;
    e[2] !== n ? (a = n === void 0 ? {} : n, e[2] = n, e[3] = a) : a = e[3];
    let m = a, p = s === void 0 ? Yr : s, { config: f } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c__as__useConfig$3e$__["useConfig"])(), [h, x] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), w, E;
    e[4] !== u || e[5] !== r || e[6] !== f || e[7] !== m || e[8] !== l || e[9] !== i || e[10] !== h || e[11] !== p || e[12] !== d ? (w = ()=>{
        if (h) return;
        let _ = [];
        for (let g of Object.values(r))g.clientFeatureProvider && _.push(g.clientFeatureProvider(g.clientFeatureProps));
        let C = qa({
            config: f,
            featureClientImportMap: m,
            featureClientSchemaMap: l,
            field: i,
            schemaPath: d ?? i.name,
            unSanitizedEditorConfig: {
                features: _,
                lexical: p
            }
        });
        x(qr(C, p, u));
    }, E = [
        u,
        r,
        f,
        m,
        l,
        i,
        h,
        p,
        d
    ], e[4] = u, e[5] = r, e[6] = f, e[7] = m, e[8] = l, e[9] = i, e[10] = h, e[11] = p, e[12] = d, e[13] = w, e[14] = E) : (w = e[13], E = e[14]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(w, E);
    let N;
    return e[15] !== h || e[16] !== t ? (N = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__f__as__ShimmerEffect$3e$__["ShimmerEffect"], {
            height: "35vh"
        }),
        children: h && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(qx, {
            ...t,
            editorConfig: h
        })
    }), e[15] = h, e[16] = t, e[17] = N) : N = e[17], N;
};
function eC(t) {
    return t instanceof HTMLElement;
}
function tC(...t) {
    return t.filter(Boolean).join(" ");
}
var Mo = new WeakMap;
function ec(t) {
    let e = t.changedTouches[0];
    return e === void 0 ? null : [
        e.clientX,
        e.clientY
    ];
}
function Do(t, e) {
    let o = Mo.get(t);
    if (o === void 0) {
        let r = new Set, n = (i)=>{
            o !== void 0 && (o.start = ec(i));
        }, l = (i)=>{
            if (o === void 0) return;
            let { start: s } = o;
            if (s === null) return;
            let d = ec(i);
            for (let c of r)d !== null && c([
                d[0] - s[0],
                d[1] - s[1]
            ], i);
        };
        t.addEventListener("touchstart", n), t.addEventListener("touchend", l), o = {
            handleTouchend: l,
            handleTouchstart: n,
            listeners: r,
            start: null
        }, Mo.set(t, o);
    }
    return o.listeners.add(e), ()=>{
        oC(t, e);
    };
}
function oC(t, e) {
    let o = Mo.get(t);
    if (o === void 0) return;
    let { listeners: r } = o;
    r.delete(e), r.size === 0 && (Mo.delete(t), t.removeEventListener("touchstart", o.handleTouchstart), t.removeEventListener("touchend", o.handleTouchend));
}
function rC(t, e) {
    return Do(t, (o, r)=>{
        let [n, l] = o;
        n < 0 && -n > Math.abs(l) && e(n, r);
    });
}
function nC(t, e) {
    return Do(t, (o, r)=>{
        let [n, l] = o;
        n > 0 && n > Math.abs(l) && e(n, r);
    });
}
function lC(t, e) {
    return Do(t, (o, r)=>{
        let [n, l] = o;
        l < 0 && -l > Math.abs(n) && e(n, r);
    });
}
function iC(t, e) {
    return Do(t, (o, r)=>{
        let [n, l] = o;
        l > 0 && l > Math.abs(n) && e(n, r);
    });
}
;
;
;
var cC = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), { EditButton: e } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(), o;
    return t[0] !== e ? (o = e ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(e, {}) : null, t[0] = e, t[1] = o) : o = t[1], o;
};
;
;
;
var mC = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), { RemoveButton: e } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(), o;
    return t[0] !== e ? (o = e ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(e, {}) : null, t[0] = e, t[1] = o) : o = t[1], o;
};
;
;
;
var hC = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), { Label: e } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(), o;
    return t[0] !== e ? (o = e ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(e, {}) : null, t[0] = e, t[1] = o) : o = t[1], o;
};
;
;
;
var CC = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3), { children: o } = t, { InlineBlockContainer: r } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(), n;
    return e[0] !== r || e[1] !== o ? (n = r ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(r, {
        children: o
    }) : null, e[0] = r, e[1] = o, e[2] = n) : n = e[2], n;
};
;
;
var kC = (t)=>{
    let { children: e, ...o } = t, { BlockCollapsible: r } = Ce();
    return r ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(r, {
        ...o,
        children: e
    }) : null;
};
;
;
;
var wC = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), { EditButton: e } = Ce(), o;
    return t[0] !== e ? (o = e ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(e, {}) : null, t[0] = e, t[1] = o) : o = t[1], o;
};
;
;
;
var NC = ()=>{
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), { RemoveButton: e } = Ce(), o;
    return t[0] !== e ? (o = e ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(e, {}) : null, t[0] = e, t[1] = o) : o = t[1], o;
};
;
var yC = ({ apiURL: t, depth: e, draft: o, locale: r })=>async ({ id: l, collectionSlug: i, select: s })=>{
        let d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$qs$2d$esm$40$7$2e$0$2e$2$2f$node_modules$2f$qs$2d$esm$2f$lib$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])({
            depth: e ?? 0,
            draft: o ?? !1,
            locale: r,
            select: s
        }, {
            addQueryPrefix: !0
        });
        return await fetch(`${t}/${i}/${l}${d}`, {
            credentials: "include",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json"
            },
            method: "GET"
        }).then((u)=>u.json());
    };
var tc = {
    customEndRegex: {
        optional: !0,
        regExp: /[ \t]*```$/
    },
    customStartRegex: /^[ \t]*```(\w+)?/,
    doNotTrimChildren: !0,
    export: ({ fields: t })=>!t.code.includes(`
`) && !t.language?.length ? "```" + t.code + "```" : "```" + (t.language || "") + (t.code ? `
` + t.code : "") + "\n```",
    import: ({ children: t, closeMatch: e, openMatch: o })=>{
        let r = o?.[1];
        return t.startsWith(`
`) && (t = t.slice(1)), t.endsWith(`
`) && (t = t.slice(0, -1)), !!e && !t.includes(`
`) && o?.input?.trim() !== "```" + r ? {
            code: r + (t?.length ? t : ""),
            language: ""
        } : {
            code: t,
            language: r
        };
    }
};
;
;
;
var $o = {
    abap: "ABAP",
    apex: "Apex",
    azcli: "Azure CLI",
    bat: "Batch",
    bicep: "Bicep",
    cameligo: "CameLIGO",
    clojure: "Clojure",
    coffee: "CoffeeScript",
    cpp: "C++",
    csharp: "C#",
    csp: "CSP",
    css: "CSS",
    cypher: "Cypher",
    dart: "Dart",
    dockerfile: "Dockerfile",
    ecl: "ECL",
    elixir: "Elixir",
    flow9: "Flow9",
    freemarker2: "FreeMarker 2",
    fsharp: "F#",
    go: "Go",
    graphql: "GraphQL",
    handlebars: "Handlebars",
    hcl: "HCL",
    html: "HTML",
    ini: "INI",
    java: "Java",
    javascript: "JavaScript",
    julia: "Julia",
    kotlin: "Kotlin",
    less: "Less",
    lexon: "Lexon",
    liquid: "Liquid",
    lua: "Lua",
    m3: "M3",
    markdown: "Markdown",
    mdx: "MDX",
    mips: "MIPS",
    msdax: "DAX",
    mysql: "MySQL",
    "objective-c": "Objective-C",
    pascal: "Pascal",
    pascaligo: "PascaLIGO",
    perl: "Perl",
    pgsql: "PostgreSQL",
    php: "PHP",
    pla: "PLA",
    plaintext: "Plain Text",
    postiats: "Postiats",
    powerquery: "Power Query",
    powershell: "PowerShell",
    protobuf: "Protobuf",
    pug: "Pug",
    python: "Python",
    qsharp: "Q#",
    r: "R",
    razor: "Razor",
    redis: "Redis",
    redshift: "Amazon Redshift",
    restructuredtext: "reStructuredText",
    ruby: "Ruby",
    rust: "Rust",
    sb: "Small Basic",
    scala: "Scala",
    scheme: "Scheme",
    scss: "SCSS",
    shell: "Shell",
    solidity: "Solidity",
    sophia: "Sophia",
    sparql: "SPARQL",
    sql: "SQL",
    st: "Structured Text",
    swift: "Swift",
    systemverilog: "SystemVerilog",
    tcl: "Tcl",
    twig: "Twig",
    typescript: "TypeScript",
    typespec: "TypeSpec",
    vb: "Visual Basic",
    wgsl: "WGSL",
    xml: "XML",
    yaml: "YAML"
};
var $C = ({ autoComplete: t, field: e, forceRender: o, languages: r = $o, path: n, permissions: l, readOnly: i, renderedBlocks: s, schemaPath: d, typescript: c, validate: u })=>{
    let a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFormFields"])(([w])=>w.language), m = a?.value || a?.initialValue || "typescript", p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), f = r[m], h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            ...e,
            type: "code",
            admin: {
                ...e.admin,
                editorOptions: {},
                editorProps: {
                    defaultPath: m === "ts" ? `file-${e.name}-${p}.tsx` : void 0
                },
                language: m
            }
        }), [
        e,
        m,
        p
    ]), x = `${e.name}-${m}-${f}`;
    return h && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CodeField"], {
        autoComplete: t,
        field: h,
        forceRender: o,
        onMount: (w, E)=>{
            E.editor.defineTheme("vs-dark", {
                base: "vs-dark",
                colors: {
                    "editor.background": "#222222"
                },
                inherit: !0,
                rules: []
            }), E.editor.defineTheme("vs", {
                base: "vs",
                colors: {
                    "editor.background": "#f5f5f5"
                },
                inherit: !0,
                rules: []
            }), E.languages.typescript.typescriptDefaults.setCompilerOptions({
                allowNonTsExtensions: !0,
                allowJs: !0,
                allowSyntheticDefaultImports: !0,
                esModuleInterop: !0,
                jsx: E.languages.typescript.JsxEmit.React,
                moduleResolution: E.languages.typescript.ModuleResolutionKind.NodeJs,
                noEmit: !0,
                paths: c?.paths,
                reactNamespace: "React",
                target: E.languages.typescript.ScriptTarget[c?.target ?? "ESNext"],
                typeRoots: c?.typeRoots ?? [
                    "node_modules/@types"
                ]
            }), E.languages.typescript.typescriptDefaults.setDiagnosticsOptions({
                noSemanticValidation: !c?.enableSemanticValidation,
                noSyntaxValidation: !1
            }), (async ()=>{
                c?.fetchTypes && Array.isArray(c.fetchTypes) && c.fetchTypes.length > 0 && await Promise.all(c.fetchTypes.map(async (_)=>{
                    let g = await (await fetch(_.url)).text();
                    E.languages.typescript.typescriptDefaults.addExtraLib(g, _.filePath);
                }));
            })();
        },
        path: n,
        permissions: l,
        readOnly: i,
        renderedBlocks: s,
        schemaPath: d,
        validate: u
    }, x);
};
;
;
;
;
;
;
var rc = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        fill: "none",
        height: "12",
        viewBox: "0 0 15 12",
        width: "15",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M11.3738 8.62598L14.0404 5.95931L11.3738 3.29264M3.37376 3.29264L0.707092 5.95931L3.37376 8.62598M9.04043 0.625977L5.70709 11.2926",
            stroke: "currentColor",
            strokeLinecap: "square"
        })
    });
;
;
;
;
;
var Ao = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        fill: "none",
        height: "15",
        viewBox: "0 0 15 15",
        width: "15",
        xmlns: "http://www.w3.org/2000/svg",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M7.16667 13.8333V9.83333M7.16667 9.83333L9.16667 11.8333M7.16667 9.83333L5.16667 11.8333M7.16667 4.5V0.5M7.16667 4.5L9.16667 2.5M7.16667 4.5L5.16667 2.5M1.83333 7.16667H0.5M5.83333 7.16667H4.5M9.83333 7.16667H8.5M13.8333 7.16667H12.5",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round"
        })
    });
var AC = "code-block-collapse-button", ic = ()=>{
    let { toggle: t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useCollapsible"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", {
        className: AC,
        onClick: t,
        type: "button",
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ao, {})
    });
};
;
;
;
var PC = "code-block-floating-collapse-button", ac = ()=>{
    let { isCollapsed: t, toggle: e } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useCollapsible"])(), { t: o } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__["useTranslation"])();
    return t ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("button", {
        className: PC,
        onClick: e,
        type: "button",
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                children: o("general:collapse")
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Ao, {})
        ]
    }) : null;
};
var We = "payload-richtext-code-block", ZC = (t)=>{
    let { languages: e } = t, o = e || $o, { BlockCollapsible: r, formSchema: n, RemoveButton: l } = Ce(), { setModified: i } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useForm"])(), { t: s } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$7V3NHDV6$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__useTranslation$3e$__["useTranslation"])(), { codeField: d } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFormFields"])(([f])=>({
            codeField: f?.code
        })), { selectedLanguageField: c, setSelectedLanguage: u } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFormFields"])(([f, h])=>({
            selectedLanguageField: f?.language,
            setSelectedLanguage: (x)=>{
                h({
                    type: "UPDATE",
                    path: "language",
                    value: x
                }), i(!0);
            }
        })), a = o[c?.value], m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lexical$2b$react$40$0$2e$35$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_yjs$40$13$2e$6$2e$29$2f$node_modules$2f40$lexical$2f$react$2f$useLexicalEditable$2e$dev$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLexicalEditable"])(), p = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "ZC.useMemo[p]": ()=>Object.entries(o).map({
                "ZC.useMemo[p]": ([f, h])=>({
                        name: `${f} ${h}`,
                        Component: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PopupList"].Button, {
                            active: !1,
                            disabled: !1,
                            onClick: {
                                "ZC.useMemo[p]": ()=>{
                                    u(f);
                                }
                            }["ZC.useMemo[p]"],
                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                                className: `${We}__language-code`,
                                "data-language": f,
                                children: h
                            })
                        })
                    })
            }["ZC.useMemo[p]"])
    }["ZC.useMemo[p]"], [
        o,
        u
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(r, {
        Actions: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
            className: `${We}__actions`,
            children: [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Combobox"], {
                    button: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                        className: `${We}__language-selector-button`,
                        "data-selected-language": c?.value,
                        children: [
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                                children: a
                            }),
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ChevronIcon"], {
                                className: `${We}__chevron`
                            })
                        ]
                    }),
                    buttonType: "custom",
                    className: `${We}__language-selector`,
                    disabled: !m,
                    entries: p,
                    horizontalAlign: "right",
                    minEntriesForSearch: 8,
                    searchPlaceholder: s("fields:searchForLanguage"),
                    showScrollbar: !0,
                    size: "large"
                }),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CopyToClipboard"], {
                    value: d?.value ?? ""
                }),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ic, {}),
                m && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(l, {})
            ]
        }),
        className: We,
        collapsibleProps: {
            AfterCollapsible: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ac, {}),
            disableHeaderToggle: !0,
            disableToggleIndicator: !0
        },
        Pill: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            className: `${We}__pill`,
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(rc, {})
        }),
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RenderFields"], {
            fields: n,
            forceRender: !0,
            parentIndexPath: "",
            parentPath: "",
            parentSchemaPath: "",
            permissions: !0,
            readOnly: !m
        })
    });
};
;
;
;
;
var n2 = (t)=>{
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9), { field: o, initialValue: r, Loading: n, path: l, schemaPath: i, setValue: s, value: d } = t, [c, u] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null), a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useServerFunctions"])(), { _internal_renderField: m } = a, [p, f] = i.split(".", 2), h = l ?? (o && "name" in o ? o?.name : "") ?? "", x;
    e[0] !== m || e[1] !== o || e[2] !== r || e[3] !== l || e[4] !== i ? (x = ()=>{
        (async function() {
            let { Field: y } = await m({
                field: {
                    ...o || {},
                    type: "richText",
                    admin: {
                        ...o?.admin || {},
                        hidden: !1
                    }
                },
                initialValue: r ?? void 0,
                path: l,
                schemaPath: i
            });
            u(y);
        })();
    }, e[0] = m, e[1] = o, e[2] = r, e[3] = l, e[4] = i, e[5] = x) : x = e[5];
    let w = x, E = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1), N, _;
    if (e[6] !== w ? (N = ()=>{
        E.current || (E.current = !0, w());
    }, _ = [
        w
    ], e[6] = w, e[7] = N, e[8] = _) : (N = e[7], _ = e[8]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(N, _), !c) return typeof n < "u" ? n : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$chunk$2d$53XJ3K67$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__f__as__ShimmerEffect$3e$__["ShimmerEffect"], {});
    let C = {
        ...a,
        getFormState: async (b)=>a.getFormState({
                ...b,
                collectionSlug: p === "collection" ? f : void 0,
                globalSlug: p === "global" ? f : void 0
            })
    };
    if (typeof d > "u" && !s) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ServerFunctionsContext"], {
        value: {
            ...C
        },
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FieldPathContext"], {
            value: h,
            children: c
        }, h)
    });
    let g = {
        disabled: !1,
        formInitializing: !1,
        formProcessing: !1,
        formSubmitted: !1,
        initialValue: d,
        path: h,
        setValue: s ?? l2,
        showError: !1,
        value: d
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ServerFunctionsContext"], {
        value: {
            ...C
        },
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FieldPathContext"], {
            value: h,
            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_$40$playwright$2b$test$40$1$2e$56$2e$1_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$react$40$19$2e$2$2e$3_sass$40$1$2e$77$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$ui$40$3$2e$70$2e$0_$40$types$2b$react$40$19$2e$2$2e$1_monaco$2d$editor$40$0$2e$55$2e$1_next$40$16$2e$1$2e$1_$40$babel$2b$core$40$7$2e$28$2e$5_wljpfz4j2jdp7c5zdolenvksbi$2f$node_modules$2f40$payloadcms$2f$ui$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FieldContext"], {
                value: g,
                children: c
            })
        }, h)
    });
};
function l2() {}
function pc({ nodes: t, text: e }) {
    let o = {
        root: {
            type: "root",
            children: [],
            direction: "ltr",
            format: "",
            indent: 0,
            version: 1
        }
    };
    return e && o.root.children.push({
        type: "paragraph",
        children: [
            {
                type: "text",
                detail: 0,
                format: 0,
                mode: "normal",
                style: "",
                text: e,
                version: 1
            }
        ],
        direction: "ltr",
        format: "",
        indent: 0,
        textFormat: 0,
        textStyle: "",
        version: 1
    }), t?.length && o.root.children.push(...t), o;
}
var i2 = pc;
;
 //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "$createAutoLinkNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$createAutoLinkNode"],
    "$createBlockNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$createBlockNode"],
    "$createHorizontalRuleNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$createHorizontalRuleNode"],
    "$createInlineBlockNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"],
    "$createLinkNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$createLinkNode"],
    "$createRelationshipNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$createRelationshipNode"],
    "$createUploadNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$createUploadNode"],
    "$isAutoLinkNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isAutoLinkNode"],
    "$isBlockNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isBlockNode"],
    "$isHorizontalRuleNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isHorizontalRuleNode"],
    "$isInlineBlockNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["e"],
    "$isLinkNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isLinkNode"],
    "$isRelationshipNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isRelationshipNode"],
    "$isUploadNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$isUploadNode"],
    "AlignFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AlignFeatureClient"],
    "AutoLinkNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AutoLinkNode"],
    "BlockCollapsible",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BlockCollapsible"],
    "BlockEditButton",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BlockEditButton"],
    "BlockNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BlockNode"],
    "BlockRemoveButton",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BlockRemoveButton"],
    "BlockquoteFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BlockquoteFeatureClient"],
    "BlocksFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BlocksFeatureClient"],
    "BoldFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BoldFeatureClient"],
    "CAN_USE_DOM",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"],
    "ChecklistFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ChecklistFeatureClient"],
    "CodeBlockBlockComponent",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CodeBlockBlockComponent"],
    "CodeComponent",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CodeComponent"],
    "DETAIL_TYPE_TO_DETAIL",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DETAIL_TYPE_TO_DETAIL"],
    "DOUBLE_LINE_BREAK",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DOUBLE_LINE_BREAK"],
    "DebugJsxConverterFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DebugJsxConverterFeatureClient"],
    "ELEMENT_FORMAT_TO_TYPE",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ELEMENT_FORMAT_TO_TYPE"],
    "ELEMENT_TYPE_TO_FORMAT",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ELEMENT_TYPE_TO_FORMAT"],
    "ENABLE_SLASH_MENU_COMMAND",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["i"],
    "EditorConfigProvider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"],
    "FieldsDrawer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$O6XRT2H3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"],
    "FixedToolbarFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FixedToolbarFeatureClient"],
    "HeadingFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HeadingFeatureClient"],
    "HorizontalRuleFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HorizontalRuleFeatureClient"],
    "HorizontalRuleNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HorizontalRuleNode"],
    "INSERT_BLOCK_COMMAND",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["INSERT_BLOCK_COMMAND"],
    "INSERT_INLINE_BLOCK_COMMAND",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["INSERT_INLINE_BLOCK_COMMAND"],
    "IS_ALL_FORMATTING",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["IS_ALL_FORMATTING"],
    "IndentFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["IndentFeatureClient"],
    "InlineBlockContainer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["InlineBlockContainer"],
    "InlineBlockEditButton",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["InlineBlockEditButton"],
    "InlineBlockLabel",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["InlineBlockLabel"],
    "InlineBlockNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"],
    "InlineBlockRemoveButton",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["InlineBlockRemoveButton"],
    "InlineCodeFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["InlineCodeFeatureClient"],
    "InlineToolbarFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["InlineToolbarFeatureClient"],
    "ItalicFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ItalicFeatureClient"],
    "LTR_REGEX",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LTR_REGEX"],
    "LexicalPluginToLexicalFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LexicalPluginToLexicalFeatureClient"],
    "LinkFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LinkFeatureClient"],
    "LinkNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LinkNode"],
    "NON_BREAKING_SPACE",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["NON_BREAKING_SPACE"],
    "NodeFormat",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["NodeFormat"],
    "OrderedListFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["OrderedListFeatureClient"],
    "ParagraphFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ParagraphFeatureClient"],
    "Point",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["f"],
    "RTL_REGEX",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RTL_REGEX"],
    "Rect",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["k"],
    "RelationshipFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RelationshipFeatureClient"],
    "RelationshipNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RelationshipNode"],
    "RenderLexical",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RenderLexical"],
    "RichTextField",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RichTextField"],
    "SlateToLexicalFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["SlateToLexicalFeatureClient"],
    "StrikethroughFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["StrikethroughFeatureClient"],
    "SubscriptFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["SubscriptFeatureClient"],
    "SuperscriptFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["SuperscriptFeatureClient"],
    "TEXT_MODE_TO_TYPE",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TEXT_MODE_TO_TYPE"],
    "TEXT_TYPE_TO_FORMAT",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TEXT_TYPE_TO_FORMAT"],
    "TEXT_TYPE_TO_MODE",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TEXT_TYPE_TO_MODE"],
    "TOGGLE_LINK_COMMAND",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TOGGLE_LINK_COMMAND"],
    "TableFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TableFeatureClient"],
    "TestRecorderFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TestRecorderFeatureClient"],
    "TextStateFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TextStateFeatureClient"],
    "ToolbarButton",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ToolbarButton"],
    "ToolbarDropdown",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ToolbarDropdown"],
    "TreeViewFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TreeViewFeatureClient"],
    "UnderlineFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["UnderlineFeatureClient"],
    "UnorderedListFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["UnorderedListFeatureClient"],
    "UploadFeatureClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["UploadFeatureClient"],
    "UploadNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["UploadNode"],
    "addSwipeDownListener",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addSwipeDownListener"],
    "addSwipeLeftListener",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addSwipeLeftListener"],
    "addSwipeRightListener",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addSwipeRightListener"],
    "addSwipeUpListener",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addSwipeUpListener"],
    "buildDefaultEditorState",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildDefaultEditorState"],
    "buildEditorState",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildEditorState"],
    "codeConverterClient",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["codeConverterClient"],
    "createBlockNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createBlockNode"],
    "createClientFeature",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClientFeature"],
    "defaultColors",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["defaultColors"],
    "defaultEditorLexicalConfig",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["defaultEditorLexicalConfig"],
    "getDOMRangeRect",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getDOMRangeRect"],
    "getEnabledNodes",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["l"],
    "getRestPopulateFn",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getRestPopulateFn"],
    "getSelectedNode",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getSelectedNode"],
    "isHTMLElement",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isHTMLElement"],
    "isPoint",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["g"],
    "joinClasses",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["joinClasses"],
    "sanitizeClientEditorConfig",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["sanitizeClientEditorConfig"],
    "sanitizeClientFeatures",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["sanitizeClientFeatures"],
    "setFloatingElemPosition",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["setFloatingElemPosition"],
    "setFloatingElemPositionForLinkEditor",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["setFloatingElemPositionForLinkEditor"],
    "slashMenuBasicGroupWithItems",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["slashMenuBasicGroupWithItems"],
    "toolbarAddDropdownGroupWithItems",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toolbarAddDropdownGroupWithItems"],
    "toolbarFeatureButtonsGroupWithItems",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toolbarFeatureButtonsGroupWithItems"],
    "toolbarFormatGroupWithItems",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toolbarFormatGroupWithItems"],
    "toolbarTextDropdownGroupWithItems",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toolbarTextDropdownGroupWithItems"],
    "useBlockComponentContext",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useBlockComponentContext"],
    "useEditorConfigContext",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["b"],
    "useInlineBlockComponentContext",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"],
    "useLexicalDocumentDrawer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$F26IQ5RE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"],
    "useLexicalDrawer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$INBEEENE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"],
    "useLexicalListDrawer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useLexicalListDrawer"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$TRHFMZ3F$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-TRHFMZ3F.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$O6XRT2H3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-O6XRT2H3.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$INBEEENE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-INBEEENE.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$F26IQ5RE$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-F26IQ5RE.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$AFXLIYGL$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-AFXLIYGL.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$payloadcms$2b$richtext$2d$lexical$40$3$2e$70$2e$0_$40$faceless$2d$ui$2b$modal$40$3$2e$0$2e$0_react$2d$dom$40$19$2e$2$2e$3_react$40$19$2e$2$2e$3_$5f$r_zjj4xqdljmzec4hon3ih4x7k2m$2f$node_modules$2f40$payloadcms$2f$richtext$2d$lexical$2f$dist$2f$exports$2f$client$2f$chunk$2d$BZZVLW4U$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@payloadcms+richtext-lexical@3.70.0_@faceless-ui+modal@3.0.0_react-dom@19.2.3_react@19.2.3__r_zjj4xqdljmzec4hon3ih4x7k2m/node_modules/@payloadcms/richtext-lexical/dist/exports/client/chunk-BZZVLW4U.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=daa92_%40payloadcms_richtext-lexical_dist_exports_client_b59a6a14._.js.map