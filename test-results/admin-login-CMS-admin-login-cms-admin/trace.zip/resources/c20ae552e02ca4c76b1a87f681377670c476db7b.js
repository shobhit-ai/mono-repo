(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_6f17997d._.css",
  "static/chunks/node_modules__pnpm_72435bc5._.js",
  "static/chunks/7639e_@payloadcms_ui_dist_exports_client_chunk-7V3NHDV6_fbe7de5c.js",
  "static/chunks/7639e_@payloadcms_ui_dist_exports_client_index_6ff841d2.js",
  "static/chunks/7639e_@payloadcms_ui_dist_exports_client_index_1a0927e1.js",
  "static/chunks/7639e_@payloadcms_ui_dist_exports_client_f28f4deb._.js",
  "static/chunks/7639e_@payloadcms_ui_dist_exports_shared_index_ae488ca7.js",
  "static/chunks/7639e_@payloadcms_ui_dist_044af8b6._.js",
  "static/chunks/50d1e_date-fns_1cbaca25._.js",
  "static/chunks/bedd4_@floating-ui_react_dist_309af574._.js",
  "static/chunks/baa60_@dnd-kit_core_dist_core_esm_4c904352.js",
  "static/chunks/952fe_ajv_dist_b66023e7._.js",
  "static/chunks/dc7bc_@payloadcms_next_dist_0f1f9234._.js",
  "static/chunks/ddef9_lexical_Lexical_dev_mjs_785ee13d._.js",
  "static/chunks/daa92_@payloadcms_richtext-lexical_dist_exports_client_b59a6a14._.js",
  "static/chunks/8c142_jsox_lib_jsox_mjs_e5e9572d._.js",
  "static/chunks/6cbcb_@lexical_table_LexicalTable_dev_mjs_3af90ae7._.js",
  "static/chunks/node_modules__pnpm_03f64cb4._.js"
],
    source: "dynamic"
});
