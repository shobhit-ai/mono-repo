(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_3e6d2d51._.js",
  "static/chunks/69e49_next_dist_compiled_react-dom_0ac616a3._.js",
  "static/chunks/69e49_next_dist_compiled_react-server-dom-turbopack_d83b04a5._.js",
  "static/chunks/69e49_next_dist_compiled_next-devtools_index_c0404d91.js",
  "static/chunks/69e49_next_dist_compiled_8bf4827e._.js",
  "static/chunks/69e49_next_dist_client_deb70bc2._.js",
  "static/chunks/69e49_next_dist_a3807e2a._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
